@echo off
:: Run this once to copy your SJC campus photo into the assets folder.
:: Usage: drag your campus image onto this .bat file,
::        OR edit the SOURCE line below to point to your image file.

set SOURCE=%1

if "%SOURCE%"=="" (
    echo Usage: Drag your campus image JPG/PNG onto this file.
    echo   OR edit SOURCE in this script manually.
    echo.
    echo Expected location after install:
    echo   src\sss\assets\sjc_campus.jpg
    pause
    exit /b 1
)

if not exist "src\sss\assets" mkdir "src\sss\assets"
copy /Y "%SOURCE%" "src\sss\assets\sjc_campus.jpg"
echo.
echo Image installed to src\sss\assets\sjc_campus.jpg
echo Run build.bat then run.bat to see the new background.
pause
