package sss;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class NotificationManagementPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTable table;

    // Compose fields
    private JComboBox<String> sourceBox;
    private JTextArea msgArea;

    // Open data fields
    private JTextField odTitle, odCategory;
    private JTextArea odDesc;

    public NotificationManagementPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel t = new JLabel("🔔  Notification & Data Management");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        hdr.add(t, BorderLayout.WEST);
        JButton back = UIUtils.secondaryButton("← Dashboard");
        back.addActionListener(e -> mainFrame.showPanel("admin_dashboard"));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(AppColors.DARK_GREEN);
        right.add(back);
        hdr.add(right, BorderLayout.EAST);
        return hdr;
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new GridLayout(1, 3, 14, 0));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(16, 20, 16, 20));
        body.add(buildNotifList());
        body.add(buildComposePanel());
        body.add(buildOpenDataPanel());
        return body;
    }

    // ── Notification list ──────────────────────────────────────────────────
    private JPanel buildNotifList() {
        JPanel card = whiteCard(new BorderLayout(0, 8));
        JLabel t = new JLabel("All Notifications");
        t.setFont(new Font("Segoe UI", Font.BOLD, 16));
        t.setForeground(AppColors.DARK_GREEN);
        card.add(t, BorderLayout.NORTH);

        String[] cols = {"Source", "Message", "Date", "Read"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setFont(AppColors.SMALL_FONT);
        table.setRowHeight(28);
        table.setGridColor(new Color(235, 235, 240));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(220);
        table.getColumnModel().getColumn(2).setPreferredWidth(110);
        table.getColumnModel().getColumn(3).setPreferredWidth(40);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        btns.setBackground(Color.WHITE);
        JButton markAllBtn  = UIUtils.primaryButton("Mark All Read");
        JButton deleteSelBtn = UIUtils.secondaryButton("Delete Selected");
        markAllBtn.addActionListener(e -> {
            DataStore.getInstance().markAllRead();
            loadNotifTable();
            mainFrame.refreshNav();
        });
        deleteSelBtn.addActionListener(e -> deleteSelectedNotif());
        btns.add(markAllBtn); btns.add(deleteSelBtn);
        card.add(btns, BorderLayout.SOUTH);

        loadNotifTable();
        return card;
    }

    private void loadNotifTable() {
        tableModel.setRowCount(0);
        List<DataStore.Notification> notifs = DataStore.getInstance().getNotifications();
        for (DataStore.Notification n : notifs) {
            tableModel.addRow(new Object[]{n.source, n.message, n.date, n.read ? "Yes" : "No"});
        }
    }

    private void deleteSelectedNotif() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtils.showError(this, "Select a notification first."); return; }
        DataStore.getInstance().deleteNotification(row);
        loadNotifTable();
        mainFrame.refreshNav();
        UIUtils.showSuccess(this, "Notification deleted.");
    }

    // ── Compose panel ──────────────────────────────────────────────────────
    private JPanel buildComposePanel() {
        JPanel card = whiteCard(new BorderLayout(0, 10));
        JLabel title = new JLabel("Broadcast Announcement");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(Color.WHITE);

        sourceBox = UIUtils.styledCombo(new String[]{
            "SYS","ADMIN","REGISTRAR","FACULTY","LIBRARY","CLINIC","FINANCE","IT"
        });
        msgArea = UIUtils.styledArea(6, 30);

        fields.add(UIUtils.formRow("Source / Office", sourceBox));
        fields.add(Box.createVerticalStrut(10));
        JLabel ml = new JLabel("Message:");
        ml.setFont(new Font("Segoe UI", Font.BOLD, 13));
        ml.setForeground(AppColors.TEXT_DARK);
        fields.add(ml);
        fields.add(Box.createVerticalStrut(4));
        JScrollPane ms = new JScrollPane(msgArea);
        ms.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(ms);
        fields.add(Box.createVerticalStrut(14));

        JButton sendBtn = UIUtils.primaryButton("Send Broadcast");
        sendBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        sendBtn.addActionListener(e -> sendBroadcast());
        fields.add(sendBtn);

        fields.add(Box.createVerticalStrut(24));

        // Stats box
        fields.add(buildNotifStats());
        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildNotifStats() {
        JPanel p = new JPanel(new GridLayout(2, 2, 8, 8));
        p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(
            new MatteBorder(1, 0, 0, 0, AppColors.BORDER),
            new EmptyBorder(12, 0, 0, 0)
        ));
        DataStore ds = DataStore.getInstance();
        int total  = ds.getNotifications().size();
        int unread = ds.getUnreadCount();
        p.add(miniStat("Total",   String.valueOf(total),        AppColors.DARK_GREEN));
        p.add(miniStat("Unread",  String.valueOf(unread),       new Color(231, 76, 60)));
        p.add(miniStat("Read",    String.valueOf(total-unread), AppColors.MEDIUM_GREEN));
        p.add(miniStat("Sources", "8",                          new Color(142, 68, 173)));
        return p;
    }

    private JPanel miniStat(String label, String val, Color color) {
        JPanel p = new JPanel(); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(new Color(248, 250, 252));
        p.setBorder(new CompoundBorder(new LineBorder(new Color(220,220,230),1,true), new EmptyBorder(8,6,8,6)));
        JLabel v = new JLabel(val, SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 22)); v.setForeground(color); v.setAlignmentX(CENTER_ALIGNMENT);
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(AppColors.SMALL_FONT); l.setForeground(AppColors.TEXT_GRAY); l.setAlignmentX(CENTER_ALIGNMENT);
        p.add(v); p.add(l);
        return p;
    }

    private void sendBroadcast() {
        String src = (String) sourceBox.getSelectedItem();
        String msg = msgArea.getText().trim();
        if (msg.isEmpty()) { UIUtils.showError(this, "Please enter a message."); return; }
        DataStore.getInstance().addNotification(src, msg);
        msgArea.setText("");
        loadNotifTable();
        mainFrame.refreshNav();
        UIUtils.showSuccess(this, "Broadcast sent to all users!");
    }

    // ── Open Data management ───────────────────────────────────────────────
    private JPanel buildOpenDataPanel() {
        JPanel card = whiteCard(new BorderLayout(0, 10));
        JLabel title = new JLabel("Manage Open Data");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(Color.WHITE);

        odTitle    = UIUtils.styledField("Record title");
        odCategory = UIUtils.styledField("e.g. Academic, Financial");
        odDesc     = UIUtils.styledArea(4, 30);

        fields.add(UIUtils.formRow("Title *",       odTitle));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Category *",    odCategory));
        fields.add(Box.createVerticalStrut(8));
        JLabel dl = new JLabel("Description:");
        dl.setFont(new Font("Segoe UI", Font.BOLD, 13)); dl.setForeground(AppColors.TEXT_DARK);
        fields.add(dl);
        fields.add(Box.createVerticalStrut(4));
        JScrollPane ds = new JScrollPane(odDesc); ds.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(ds);
        fields.add(Box.createVerticalStrut(12));

        JButton addBtn = UIUtils.primaryButton("Add Record");
        addBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        addBtn.addActionListener(e -> addOpenData());
        fields.add(addBtn);
        fields.add(Box.createVerticalStrut(16));

        // Existing records list
        JLabel existLbl = new JLabel("Existing Records");
        existLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        existLbl.setForeground(AppColors.DARK_GREEN);
        fields.add(existLbl);
        fields.add(Box.createVerticalStrut(6));

        JPanel listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(Color.WHITE);
        List<DataStore.OpenDataRecord> records = DataStore.getInstance().getOpenData();
        for (int i = 0; i < records.size(); i++) {
            DataStore.OpenDataRecord rec = records.get(i);
            final int idx = i;
            JPanel row = new JPanel(new BorderLayout(6, 0));
            row.setBackground(i % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
            row.setBorder(new EmptyBorder(4, 4, 4, 4));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            JLabel lbl = new JLabel("<html><b>" + rec.title + "</b> <font color='gray'>(" + rec.category + ")</font></html>");
            lbl.setFont(AppColors.SMALL_FONT);
            JButton del = new JButton("✕");
            del.setFont(new Font("Segoe UI", Font.BOLD, 11));
            del.setBackground(new Color(231, 76, 60));
            del.setForeground(Color.WHITE);
            del.setBorderPainted(false);
            del.setFocusPainted(false);
            del.setPreferredSize(new Dimension(28, 24));
            del.addActionListener(e -> {
                DataStore.getInstance().deleteOpenData(idx);
                UIUtils.showSuccess(this, "Record deleted.");
                // rebuild panel by re-showing
                mainFrame.showPanel("admin_notifications");
            });
            row.add(lbl, BorderLayout.CENTER);
            row.add(del, BorderLayout.EAST);
            listPanel.add(row);
        }
        JScrollPane listSp = new JScrollPane(listPanel);
        listSp.setBorder(new LineBorder(AppColors.BORDER));
        listSp.setPreferredSize(new Dimension(0, 160));
        fields.add(listSp);

        JScrollPane outer = new JScrollPane(fields);
        outer.setBorder(null);
        card.add(outer, BorderLayout.CENTER);
        return card;
    }

    private void addOpenData() {
        String title = odTitle.getText().trim();
        String cat   = odCategory.getText().trim();
        String desc  = odDesc.getText().trim();
        if (title.isEmpty() || cat.isEmpty()) {
            UIUtils.showError(this, "Title and Category are required."); return;
        }
        DataStore.getInstance().addOpenData(title, cat, desc.isEmpty() ? "No description." : desc);
        odTitle.setText(""); odCategory.setText(""); odDesc.setText("");
        UIUtils.showSuccess(this, "Open data record added: " + title);
        // Refresh
        mainFrame.showPanel("admin_notifications");
    }

    private JPanel whiteCard(LayoutManager lm) {
        JPanel p = new JPanel(lm); p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(new LineBorder(new Color(220, 220, 230), 1, true), new EmptyBorder(20, 20, 20, 20)));
        return p;
    }
}
