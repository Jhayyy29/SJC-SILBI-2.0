package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.LayoutManager;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class AppointmentManagementPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTable table;
    private JComboBox<String> filterStatus;

    // Detail
    private JLabel detId, detOffice, detDate, detTime, detStudent, detSubmitted;
    private JTextArea detPurpose;
    private JComboBox<String> statusBox;

    public AppointmentManagementPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel t = new JLabel("📅  Appointment Management");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        hdr.add(t, BorderLayout.WEST);
        JButton back = UIUtils.secondaryButton("← Dashboard");
        back.addActionListener(e -> mainFrame.showPanel("admin_dashboard"));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(AppColors.DARK_GREEN);
        right.add(back);
        hdr.add(right, BorderLayout.EAST);
        return hdr;
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new GridLayout(1, 2, 16, 0));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(16, 20, 16, 20));
        body.add(buildTablePanel());
        body.add(buildDetailPanel());
        return body;
    }

    private JPanel buildTablePanel() {
        JPanel card = whiteCard(new BorderLayout(0, 8));
        JLabel t = new JLabel("All Appointments");
        t.setFont(new Font("Segoe UI", Font.BOLD, 16));
        t.setForeground(AppColors.DARK_GREEN);
        card.add(t, BorderLayout.NORTH);

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filters.setBackground(Color.WHITE);
        filterStatus = UIUtils.styledCombo(new String[]{"All","Confirmed","Completed","Cancelled","No-show"});
        JButton applyBtn = UIUtils.primaryButton("Filter");
        applyBtn.setPreferredSize(new Dimension(80, 28));
        applyBtn.addActionListener(e -> loadTable());
        filters.add(new JLabel("Status:")); filters.add(filterStatus); filters.add(applyBtn);
        card.add(filters, BorderLayout.SOUTH);

        String[] cols = {"ID","Office","Student","Date","Time","Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (col == 5) {
                    JLabel lbl = UIUtils.statusBadge((String) getValueAt(row, col));
                    lbl.setHorizontalAlignment(SwingConstants.CENTER);
                    return lbl;
                }
                if (!isRowSelected(row))
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(140);
        table.getColumnModel().getColumn(3).setPreferredWidth(90);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadDetail();
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);
        loadTable();
        return card;
    }

    private JPanel buildDetailPanel() {
        JPanel card = whiteCard(new BorderLayout(0, 10));
        JLabel title = new JLabel("Appointment Detail & Action");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(Color.WHITE);

        detId        = info("—"); detOffice    = info("—");
        detDate      = info("—"); detTime      = info("—");
        detStudent   = info("—"); detSubmitted = info("—");

        fields.add(row2("Appt ID",    detId));        fields.add(gap());
        fields.add(row2("Office",     detOffice));    fields.add(gap());
        fields.add(row2("Student",    detStudent));   fields.add(gap());
        fields.add(row2("Date",       detDate));      fields.add(gap());
        fields.add(row2("Time",       detTime));      fields.add(gap());
        fields.add(row2("Submitted",  detSubmitted)); fields.add(Box.createVerticalStrut(10));

        JLabel purLbl = new JLabel("Purpose:");
        purLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        purLbl.setForeground(AppColors.TEXT_DARK);
        fields.add(purLbl);
        fields.add(Box.createVerticalStrut(4));
        detPurpose = UIUtils.styledArea(3, 30);
        detPurpose.setEditable(false);
        detPurpose.setBackground(new Color(248, 250, 252));
        JScrollPane ps = new JScrollPane(detPurpose);
        ps.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(ps);
        fields.add(Box.createVerticalStrut(14));

        // Quick buttons
        JPanel quick = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        quick.setBackground(Color.WHITE);
        JButton completeBtn = UIUtils.primaryButton("Mark Completed");
        JButton noShowBtn   = makeRedBtn("No-show");
        JButton cancelBtn2  = makeRedBtn("Cancel");
        completeBtn.addActionListener(e -> quickStatus("Completed"));
        noShowBtn.addActionListener(e -> quickStatus("No-show"));
        cancelBtn2.addActionListener(e -> quickStatus("Cancelled"));
        quick.add(completeBtn); quick.add(noShowBtn); quick.add(cancelBtn2);
        fields.add(quick);
        fields.add(Box.createVerticalStrut(12));

        statusBox = UIUtils.styledCombo(new String[]{"Confirmed","Completed","Cancelled","No-show"});
        fields.add(row2("Set Status", statusBox));
        fields.add(Box.createVerticalStrut(12));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(Color.WHITE);
        JButton saveBtn = UIUtils.primaryButton("Save");
        saveBtn.addActionListener(e -> updateAppt());
        btns.add(saveBtn);
        fields.add(btns);

        // Email status indicator
        emailStatusLabel = new JLabel(" ");
        emailStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        emailStatusLabel.setForeground(AppColors.TEXT_GRAY);
        fields.add(Box.createVerticalStrut(4));
        fields.add(emailStatusLabel);

        JScrollPane outer = new JScrollPane(fields);
        outer.setBorder(null);
        card.add(outer, BorderLayout.CENTER);
        return card;
    }

    private JButton makeRedBtn(String label) {
        JButton b = new JButton(label);
        b.setFont(AppColors.BUTTON_FONT);
        b.setBackground(new Color(231, 76, 60));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(110, 34));
        return b;
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        String fs = (String) filterStatus.getSelectedItem();
        for (DataStore.Appointment a : DataStore.getInstance().getAppointments()) {
            if (!"All".equals(fs) && !a.status.equals(fs)) continue;
            tableModel.addRow(new Object[]{a.id, a.office, a.student, a.date, a.time, a.status});
        }
    }

    private void loadDetail() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String id = (String) tableModel.getValueAt(row, 0);
        for (DataStore.Appointment a : DataStore.getInstance().getAppointments()) {
            if (a.id.equals(id)) {
                detId.setText(a.id);         detOffice.setText(a.office);
                detDate.setText(a.date);     detTime.setText(a.time);
                detStudent.setText(a.student); detSubmitted.setText(a.submittedAt);
                detPurpose.setText(a.purpose);
                for (int i = 0; i < statusBox.getItemCount(); i++) {
                    if (statusBox.getItemAt(i).equals(a.status)) { statusBox.setSelectedIndex(i); break; }
                }
                return;
            }
        }
    }

    private JLabel emailStatusLabel;

    private void quickStatus(String status) {
        if (detId.getText().equals("—")) { UIUtils.showError(this, "Select an appointment first."); return; }
        String id      = detId.getText();
        String office  = detOffice.getText();
        String date    = detDate.getText();
        String time    = detTime.getText();
        String student = detStudent.getText();
        DataStore.getInstance().updateAppointmentStatus(id, status);

        // ── Email notification ─────────────────────────────────────────
        String studentEmail = findStudentEmail(student);
        EmailService.notifyAppointmentUpdate(studentEmail, student, id, office, date, time, status,
            err -> javax.swing.SwingUtilities.invokeLater(() -> {
                if (err == null) showEmailBadge("✅ Status set to '" + status + "'. Email sent to " + studentEmail, false);
                else             showEmailBadge("⚠️ Updated but email failed: " + err, true);
            })
        );
        UIUtils.showSuccess(this, "Appointment #" + id + " set to: " + status +
            "\nEmail notification is being sent.");
        loadTable();
    }

    private void updateAppt() {
        if (detId.getText().equals("—")) { UIUtils.showError(this, "Select an appointment first."); return; }
        String id      = detId.getText();
        String status  = (String) statusBox.getSelectedItem();
        String office  = detOffice.getText();
        String date    = detDate.getText();
        String time    = detTime.getText();
        String student = detStudent.getText();
        DataStore.getInstance().updateAppointmentStatus(id, status);

        // ── Email notification ─────────────────────────────────────────
        String studentEmail = findStudentEmail(student);
        EmailService.notifyAppointmentUpdate(studentEmail, student, id, office, date, time, status,
            err -> javax.swing.SwingUtilities.invokeLater(() -> {
                if (err == null) showEmailBadge("✅ Appointment #" + id + " updated. Email sent to " + studentEmail, false);
                else             showEmailBadge("⚠️ Updated but email failed: " + err, true);
            })
        );
        UIUtils.showSuccess(this, "Appointment #" + id + " updated to: " + status +
            "\nEmail notification is being sent.");
        loadTable();
    }

    private JLabel info(String t) { JLabel l = new JLabel(t); l.setFont(AppColors.BODY_FONT); l.setForeground(Color.BLACK); return l; }
    private Box.Filler gap() { return (Box.Filler) Box.createVerticalStrut(6); }
    private JPanel row2(String label, JComponent value) {
        JPanel row = new JPanel(new BorderLayout(8, 0)); row.setBackground(Color.WHITE);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel lbl = new JLabel(label + ":"); lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(Color.BLACK); lbl.setPreferredSize(new Dimension(110, 24));
        row.add(lbl, BorderLayout.WEST); row.add(value, BorderLayout.CENTER);
        return row;
    }
    private void styleTable(JTable t) {
        t.setFont(AppColors.BODY_FONT); t.setRowHeight(30);
        t.setGridColor(new Color(235, 235, 240));
        t.setSelectionBackground(new Color(200, 235, 215));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.getTableHeader().setBackground(AppColors.DARK_GREEN);
        t.getTableHeader().setForeground(Color.BLACK);
    }
    private JPanel whiteCard(LayoutManager lm) {
        JPanel p = new JPanel(lm); p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(new LineBorder(new Color(220, 220, 230), 1, true), new EmptyBorder(20, 20, 20, 20)));
        return p;
    }

    // ── Email helpers ──────────────────────────────────────────────────────

    private String findStudentEmail(String fullName) {
        for (DataStore.User u : DataStore.getInstance().getAllUsers()) {
            if (u.fullName.equalsIgnoreCase(fullName)) return u.email;
        }
        return EmailConfig.FALLBACK_STUDENT_EMAIL;
    }

    private void showEmailBadge(String msg, boolean warn) {
        if (emailStatusLabel != null) {
            emailStatusLabel.setText(msg);
            emailStatusLabel.setForeground(warn ? new Color(180, 90, 0) : new Color(22, 130, 70));
        }
    }
}
