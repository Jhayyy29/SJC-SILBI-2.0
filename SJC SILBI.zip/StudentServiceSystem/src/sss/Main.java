package sss;

import javax.swing.*;

/**
 * Entry point for the Student Service System desktop application.
 */
public class Main {
    public static void main(String[] args) {
        // Run on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            try {
                // Use system look and feel for native rendering
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
