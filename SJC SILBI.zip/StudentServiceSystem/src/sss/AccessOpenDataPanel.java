package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;

public class AccessOpenDataPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public AccessOpenDataPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("📊  Access Open Data",
            "Browse publicly available school data and statistics."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new BorderLayout(0, 12));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));

        // Search bar
        JPanel searchPanel = new JPanel(new BorderLayout(8, 0));
        searchPanel.setBackground(AppColors.CREAM);
        searchField = UIUtils.styledField("Search records...");
        JButton searchBtn = UIUtils.primaryButton("Search");
        searchBtn.setPreferredSize(new Dimension(100, 34));
        searchBtn.addActionListener(e -> refreshTable(searchField.getText().trim()));
        searchPanel.add(new JLabel("🔍 "), BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchBtn, BorderLayout.EAST);
        main.add(searchPanel, BorderLayout.NORTH);

        // Table
        String[] cols = {"Title", "Category", "Description", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel);
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(200);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(340);
        table.getColumnModel().getColumn(3).setPreferredWidth(130);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        main.add(sp, BorderLayout.CENTER);

        // Info cards row
        JPanel cards = new JPanel(new GridLayout(1, 4, 12, 0));
        cards.setBackground(AppColors.CREAM);
        cards.add(infoCard("4,521", "Total Students"));
        cards.add(infoCard("312", "Faculty Members"));
        cards.add(infoCard("48", "Programs Offered"));
        cards.add(infoCard("6", "Campus Buildings"));
        main.add(cards, BorderLayout.SOUTH);

        refreshTable("");
        return main;
    }

    private void refreshTable(String filter) {
        tableModel.setRowCount(0);
        List<DataStore.OpenDataRecord> recs = DataStore.getInstance().getOpenData();
        for (DataStore.OpenDataRecord r : recs) {
            if (filter.isEmpty() ||
                r.title.toLowerCase().contains(filter.toLowerCase()) ||
                r.category.toLowerCase().contains(filter.toLowerCase()) ||
                r.description.toLowerCase().contains(filter.toLowerCase())) {
                tableModel.addRow(new Object[]{r.title, r.category, r.description, r.date});
            }
        }
    }

    private JPanel infoCard(String number, String label) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(AppColors.DARK_GREEN);
        p.setBorder(new EmptyBorder(16, 12, 16, 12));
        p.setBorder(new CompoundBorder(
            new LineBorder(AppColors.MEDIUM_GREEN, 1, true),
            new EmptyBorder(14, 12, 14, 12)
        ));
        p.setBackground(AppColors.DARK_GREEN);

        JLabel num = new JLabel(number, SwingConstants.CENTER);
        num.setFont(new Font("Segoe UI", Font.BOLD, 28));
        num.setForeground(AppColors.WHITE);
        num.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(AppColors.SMALL_FONT);
        lbl.setForeground(new Color(180, 220, 200));
        lbl.setAlignmentX(CENTER_ALIGNMENT);

        p.add(num);
        p.add(Box.createVerticalStrut(4));
        p.add(lbl);
        return p;
    }

    private void styleTable(JTable table) {
        table.setFont(AppColors.BODY_FONT);
        table.setRowHeight(32);
        table.setGridColor(new Color(220, 215, 200));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.setSelectionForeground(AppColors.TEXT_DARK);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
        table.setShowGrid(true);
        table.setIntercellSpacing(new Dimension(1, 1));
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
