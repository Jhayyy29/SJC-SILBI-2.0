package sss;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

/**
 * Application shell — holds the navigation bar and a CardLayout content area.
 * Automatically switches between a student nav bar and an admin nav bar
 * depending on the logged-in user's role.
 */
public class MainFrame extends JFrame {

    // ── Student panel keys ─────────────────────────────────────────────────
    public static final String CARD_LOGIN        = "login";
    public static final String CARD_DASHBOARD    = "dashboard";
    public static final String CARD_OPENDATA     = "opendata";
    public static final String CARD_REPORT       = "report";
    public static final String CARD_DOCREQUEST   = "docrequest";
    public static final String CARD_NOTIF        = "notifications";
    public static final String CARD_APPOINTMENT  = "appointment";
    public static final String CARD_SERVICES     = "services";
    public static final String CARD_PROFILE      = "profile";
    public static final String CARD_INFOREQUEST  = "inforequest";
    public static final String CARD_SERVICEREQ   = "servicerequest";

    // ── Admin panel keys ───────────────────────────────────────────────────
    public static final String CARD_ADMIN_DASH   = "admin_dashboard";
    public static final String CARD_ADMIN_USERS  = "admin_users";
    public static final String CARD_ADMIN_RPT    = "admin_reports";
    public static final String CARD_ADMIN_DOCS   = "admin_docs";
    public static final String CARD_ADMIN_APPT   = "admin_appointments";
    public static final String CARD_ADMIN_NOTIF  = "admin_notifications";
    public static final String CARD_ADMIN_SERVICEMGMT = "admin_servicemgmt";
    public static final String CARD_ADMIN_INFO   = "admin_inforeqs";
    public static final String CARD_ADMIN_AUDIT  = "admin_audit";

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel     contentArea = new JPanel(cardLayout);

    // Nav bar refs for refresh
    private JLabel userLabel;
    private JLabel notifBadge;
    private JPanel navBar;
    private JPanel studentNavCenter;
    private JPanel adminNavCenter;

    public MainFrame() {
        setTitle("SJC SILBI");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1200, 760));
        setPreferredSize(new Dimension(1366, 860));
        setLocationRelativeTo(null);

        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}

        setLayout(new BorderLayout());
        add(buildNavBar(), BorderLayout.NORTH);
        add(contentArea,   BorderLayout.CENTER);

        buildAllCards();
        cardLayout.show(contentArea, CARD_LOGIN);
        pack();
    }

    // ══════════════════════════════════════════════════════════════════════
    // Navigation bar
    // ══════════════════════════════════════════════════════════════════════
    private JPanel buildNavBar() {
        navBar = new JPanel(new BorderLayout());
        navBar.setBackground(AppColors.DARK_GREEN);
        navBar.setPreferredSize(new Dimension(0, 52));
        navBar.setBorder(new EmptyBorder(0, 16, 0, 16));

        // Logo / brand
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setBackground(AppColors.DARK_GREEN);
        JLabel logo = new JLabel("🎓");
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        JLabel name = new JLabel("SJC SILBI");
        name.setFont(new Font("Segoe UI", Font.BOLD, 16));
        name.setForeground(AppColors.WHITE);
        left.add(logo); left.add(name);
        navBar.add(left, BorderLayout.WEST);

        // Student center links
        studentNavCenter = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        studentNavCenter.setBackground(AppColors.DARK_GREEN);
        studentNavCenter.add(navLink("HOME",            e -> showDashboard()));
        studentNavCenter.add(navLink("SERVICE ▾",        e -> showPanel(CARD_SERVICES)));
        studentNavCenter.add(navLink("STUDENT CHARTER",  e -> showStudentCharter()));
        studentNavCenter.add(navLink("CONTACT US",       e -> showContactUs()));

        // Admin center links
        adminNavCenter = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        adminNavCenter.setBackground(AppColors.DARK_GREEN);
        adminNavCenter.add(adminNavLink("⊞ DASHBOARD",    CARD_ADMIN_DASH));
        adminNavCenter.add(adminNavLink("👥 USERS",        CARD_ADMIN_USERS));
        adminNavCenter.add(adminNavLink("📋 REPORTS",      CARD_ADMIN_RPT));
        adminNavCenter.add(adminNavLink("📄 DOCUMENTS",    CARD_ADMIN_DOCS));
        adminNavCenter.add(adminNavLink("📅 APPOINTMENTS", CARD_ADMIN_APPT));
        adminNavCenter.add(adminNavLink("🔔 NOTIFY",       CARD_ADMIN_NOTIF));
        adminNavCenter.add(adminNavLink("ℹ️ INFO REQS",     CARD_ADMIN_INFO));

        // Wrap both in a container; only one is shown at a time
        JPanel centerWrap = new JPanel(new CardLayout());
        centerWrap.setBackground(AppColors.DARK_GREEN);
        centerWrap.add(studentNavCenter, "student");
        centerWrap.add(adminNavCenter,   "admin");
        navBar.add(centerWrap, BorderLayout.CENTER);

        // Right: notification bell + user pill
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setBackground(AppColors.DARK_GREEN);

        notifBadge = new JLabel("🔔");
        notifBadge.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        notifBadge.setForeground(AppColors.WHITE);
        notifBadge.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        notifBadge.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (DataStore.getInstance().isAdmin()) showPanel(CARD_ADMIN_NOTIF);
                else showPanel(CARD_NOTIF);
            }
        });

        userLabel = new JLabel("Login / Register");
        userLabel.setFont(AppColors.NAV_FONT);
        userLabel.setForeground(AppColors.DARK_GREEN);
        userLabel.setBackground(AppColors.CREAM);
        userLabel.setOpaque(true);
        userLabel.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(4, 12, 4, 12)
        ));
        userLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        userLabel.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (DataStore.getInstance().isLoggedIn()) showPanel(CARD_PROFILE);
                else showLogin();
            }
        });

        right.add(notifBadge);
        right.add(userLabel);
        navBar.add(right, BorderLayout.EAST);

        return navBar;
    }

    private JLabel navLink(String text, ActionListener action) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(AppColors.NAV_FONT);
        lbl.setForeground(AppColors.WHITE);
        lbl.setBorder(new EmptyBorder(0, 14, 0, 14));
        lbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lbl.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { action.actionPerformed(null); }
            @Override public void mouseEntered(MouseEvent e) { lbl.setForeground(AppColors.LIGHT_GREEN); }
            @Override public void mouseExited(MouseEvent e)  { lbl.setForeground(AppColors.WHITE); }
        });
        return lbl;
    }

    private JLabel adminNavLink(String text, String panelKey) {
        return navLink(text, e -> showPanel(panelKey));
    }

    // Switch which nav center row is showing
    private void syncNavCenter() {
        JPanel centerWrap = (JPanel) navBar.getComponent(1); // CENTER component
        CardLayout cl = (CardLayout) centerWrap.getLayout();
        if (DataStore.getInstance().isAdmin()) cl.show(centerWrap, "admin");
        else cl.show(centerWrap, "student");
    }

    // ══════════════════════════════════════════════════════════════════════
    // Card building
    // ══════════════════════════════════════════════════════════════════════
    private void buildAllCards() {
        // Student panels
        contentArea.add(new LoginPanel(this),           CARD_LOGIN);
        contentArea.add(new DashboardPanel(this),       CARD_DASHBOARD);
        contentArea.add(new AccessOpenDataPanel(this),  CARD_OPENDATA);
        contentArea.add(new FileReportPanel(this),      CARD_REPORT);
        contentArea.add(new DocumentRequestPanel(this), CARD_DOCREQUEST);
        contentArea.add(new NotificationsPanel(this),   CARD_NOTIF);
        contentArea.add(new AppointmentPanel(this),     CARD_APPOINTMENT);
        contentArea.add(new ViewServicesPanel(this),    CARD_SERVICES);
        contentArea.add(new StudentProfilePanel(this),  CARD_PROFILE);
        contentArea.add(new InfoRequestPanel(this),     CARD_INFOREQUEST);
        contentArea.add(new RequestServicePanel(this),  CARD_SERVICEREQ);

        // Admin panels
        contentArea.add(new AdminDashboardPanel(this),          CARD_ADMIN_DASH);
        contentArea.add(new UserManagementPanel(this),          CARD_ADMIN_USERS);
        contentArea.add(new ReportManagementPanel(this),        CARD_ADMIN_RPT);
        contentArea.add(new DocumentManagementPanel(this),      CARD_ADMIN_DOCS);
        contentArea.add(new AppointmentManagementPanel(this),   CARD_ADMIN_APPT);
        contentArea.add(new NotificationManagementPanel(this),  CARD_ADMIN_NOTIF);
        contentArea.add(new ServiceRequestManagementPanel(this), CARD_ADMIN_SERVICEMGMT);
        contentArea.add(new InfoRequestManagementPanel(this),   CARD_ADMIN_INFO);
        contentArea.add(new AuditLogPanel(this),                CARD_ADMIN_AUDIT);
    }

    // ══════════════════════════════════════════════════════════════════════
    // Navigation helpers
    // ══════════════════════════════════════════════════════════════════════
    public void showLogin() {
        refreshNav();
        cardLayout.show(contentArea, CARD_LOGIN);
    }

    /** Route to the correct home screen based on role. */
    public void showDashboard() {
        if (!DataStore.getInstance().isLoggedIn()) { showLogin(); return; }
        if (DataStore.getInstance().isAdmin()) {
            // Rebuild admin dashboard for fresh stats
            contentArea.remove(findCard(CARD_ADMIN_DASH));
            contentArea.add(new AdminDashboardPanel(this), CARD_ADMIN_DASH);
            refreshNav();
            cardLayout.show(contentArea, CARD_ADMIN_DASH);
        } else {
            // Rebuild student dashboard for fresh stats
            contentArea.remove(findCard(CARD_DASHBOARD));
            contentArea.add(new DashboardPanel(this), CARD_DASHBOARD);
            refreshNav();
            cardLayout.show(contentArea, CARD_DASHBOARD);
        }
    }

    public void showPanel(String key) {
        if (!DataStore.getInstance().isLoggedIn()) { showLogin(); return; }
        // Prevent students from accessing admin panels and vice-versa
        boolean isAdminKey = key.startsWith("admin_");
        if (isAdminKey && !DataStore.getInstance().isAdmin()) {
            UIUtils.showError(this, "Access denied. Admin only.");
            return;
        }
        refreshNav();
        cardLayout.show(contentArea, key);
    }

    /** Called by child panels to refresh the nav bar. */
    public void refreshNav() {
        DataStore ds = DataStore.getInstance();
        if (ds.isLoggedIn()) {
            String prefix = ds.isAdmin() ? "⚙️ " : "👤 ";
            userLabel.setText(prefix + ds.getCurrentUser().fullName);
            int unread = ds.getUnreadCount();
            notifBadge.setText(unread > 0 ? "🔔 " + unread : "🔔");
        } else {
            userLabel.setText("Login / Register");
            notifBadge.setText("🔔");
        }
        syncNavCenter();
        navBar.revalidate();
        navBar.repaint();
    }

    // Locate a card component by its constraint name
    private Component findCard(String name) {
        // We can't easily look up by card name, so just return null —
        // the duplicate-key add in Swing will silently replace it.
        return null;
    }

    // ══════════════════════════════════════════════════════════════════════
    // Static dialogs
    // ══════════════════════════════════════════════════════════════════════
    private void showStudentCharter() {
        JTextArea text = new JTextArea(
            "STUDENT CHARTER — SJC\n\n" +
            "As a student of Saint Jude College (SJC), you are entitled to:\n\n" +
            "1. QUALITY EDUCATION\n" +
            "   Access to quality instruction, updated curriculum, and adequate facilities.\n\n" +
            "2. FAIR TREATMENT\n" +
            "   Equal and non-discriminatory treatment regardless of gender, religion, or background.\n\n" +
            "3. ACADEMIC FREEDOM\n" +
            "   Freedom to express academic opinions and pursue intellectual inquiry.\n\n" +
            "4. STUDENT REPRESENTATION\n" +
            "   The right to organize, elect student representatives, and participate in governance.\n\n" +
            "5. GRIEVANCE MECHANISM\n" +
            "   Access to a formal process for filing complaints and concerns.\n\n" +
            "6. PRIVACY\n" +
            "   Protection of personal data in accordance with the Data Privacy Act.\n\n" +
            "RESPONSIBILITIES:\n" +
            "  • Attend classes regularly and on time.\n" +
            "  • Respect fellow students, faculty, and staff.\n" +
            "  • Maintain academic integrity — no plagiarism or cheating.\n" +
            "  • Follow school rules and regulations.", 20, 50);
        text.setEditable(false);
        text.setFont(AppColors.BODY_FONT);
        JOptionPane.showMessageDialog(this, new JScrollPane(text),
            "Student Charter", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showContactUs() {
        JOptionPane.showMessageDialog(this,
            "CONTACT US\n\n" +
            "Student Affairs Office\n" +
            "  studentaffairs@sjc.edu  |  (02) 8-123-4567 local 100\n\n" +
            "Registrar's Office\n" +
            "  registrar@sjc.edu  |  (02) 8-123-4567 local 101\n\n" +
            "IT Help Desk\n" +
            "  ithelpdesk@sjc.edu  |  (02) 8-123-4567 local 200\n\n" +
            "Office Hours: Monday – Friday, 8:00 AM – 5:00 PM",
            "Contact Us", JOptionPane.INFORMATION_MESSAGE);
    }
}
