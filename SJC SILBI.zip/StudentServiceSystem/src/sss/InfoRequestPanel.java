package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class InfoRequestPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;

    private JComboBox<String> topicBox;
    private JTextField emailField;
    private JTextArea detailsArea;

    public InfoRequestPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("ℹ️  Request for Information",
            "Ask the school for specific information or request school documents online."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new GridLayout(1, 2, 16, 0));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));
        main.add(buildForm());
        main.add(buildHistory());
        return main;
    }

    private JPanel buildForm() {
        JPanel card = UIUtils.createCard("Submit Information Request");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        topicBox = UIUtils.styledCombo(new String[]{
            "Enrollment Procedures",
            "Grade / Academic Records",
            "Scholarship Information",
            "School Policies",
            "Faculty Contact",
            "Campus Facilities",
            "Events and Activities",
            "Other"
        });

        emailField  = UIUtils.styledField("Your email for response");
        detailsArea = UIUtils.styledArea(6, 30);

        DataStore.User user = DataStore.getInstance().getCurrentUser();
        if (user != null) emailField.setText(user.email);

        fields.add(UIUtils.formRow("Topic", topicBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Contact Email", emailField));
        fields.add(Box.createVerticalStrut(10));

        JLabel detLbl = new JLabel("Your Question / Request");
        detLbl.setFont(AppColors.BODY_FONT);
        detLbl.setForeground(AppColors.TEXT_DARK);
        fields.add(detLbl);
        fields.add(Box.createVerticalStrut(4));

        JScrollPane scroll = new JScrollPane(detailsArea);
        scroll.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(scroll);
        fields.add(Box.createVerticalStrut(12));

        JLabel note = new JLabel("<html><i>Responses are typically sent within 2–3 business days<br>" +
            "to your provided email address.</i></html>");
        note.setFont(AppColors.SMALL_FONT);
        note.setForeground(AppColors.TEXT_GRAY);
        fields.add(note);
        fields.add(Box.createVerticalStrut(12));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(AppColors.CARD_BG);
        JButton clearBtn  = UIUtils.secondaryButton("Clear");
        JButton submitBtn = UIUtils.primaryButton("Submit Request");
        clearBtn.addActionListener(e -> clearForm());
        submitBtn.addActionListener(e -> submitRequest());
        btns.add(clearBtn);
        btns.add(submitBtn);
        fields.add(btns);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildHistory() {
        JPanel card = UIUtils.createCard("My Information Requests");

        String[] cols = {"ID", "Topic", "Contact Email", "Status", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel) {
            @Override public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
                Component c = super.prepareRenderer(renderer, row, col);
                if (col == 3) {
                    JLabel badge = UIUtils.statusBadge((String) getValueAt(row, col));
                    badge.setHorizontalAlignment(SwingConstants.CENTER);
                    return badge;
                }
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(180);
        table.getColumnModel().getColumn(2).setPreferredWidth(160);
        table.getColumnModel().getColumn(3).setPreferredWidth(80);
        table.getColumnModel().getColumn(4).setPreferredWidth(120);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        // FAQ quick links
        JPanel faqPanel = new JPanel();
        faqPanel.setLayout(new BoxLayout(faqPanel, BoxLayout.Y_AXIS));
        faqPanel.setBackground(AppColors.CARD_BG);
        faqPanel.setBorder(new CompoundBorder(
            new MatteBorder(1, 0, 0, 0, AppColors.BORDER),
            new EmptyBorder(12, 0, 4, 0)
        ));
        faqPanel.add(UIUtils.sectionTitle("Quick FAQs"));
        String[] faqs = {
            "Q: When does enrollment open?",
            "Q: How do I apply for a scholarship?",
            "Q: Where is the Registrar's Office?",
            "Q: How do I get my TOR?"
        };
        for (String faq : faqs) {
            JLabel l = new JLabel(faq);
            l.setFont(AppColors.SMALL_FONT);
            l.setForeground(AppColors.MEDIUM_GREEN);
            l.setBorder(new EmptyBorder(2, 0, 2, 0));
            faqPanel.add(l);
        }
        card.add(faqPanel, BorderLayout.SOUTH);

        JButton refreshBtn = UIUtils.secondaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadRequests());

        loadRequests();
        return card;
    }

    private void loadRequests() {
        tableModel.setRowCount(0);
        for (DataStore.InfoRequest ir : DataStore.getInstance().getInfoRequests()) {
            tableModel.addRow(new Object[]{
                ir.id, ir.topic, ir.contactEmail, ir.status, ir.date
            });
        }
    }

    private void submitRequest() {
        String topic   = (String) topicBox.getSelectedItem();
        String email   = emailField.getText().trim();
        String details = detailsArea.getText().trim();

        if (email.isEmpty()) { UIUtils.showError(this, "Please enter your contact email."); return; }
        if (details.isEmpty()) { UIUtils.showError(this, "Please describe your request."); return; }
        if (!email.contains("@")) { UIUtils.showError(this, "Please enter a valid email address."); return; }

        DataStore.InfoRequest ir = DataStore.getInstance().submitInfoRequest(topic, details, email);
        UIUtils.showSuccess(this, "Request #" + ir.id + " submitted!\n" +
            "We will respond to " + email + " within 2–3 business days.");
        clearForm();
        loadRequests();
    }

    private void clearForm() {
        topicBox.setSelectedIndex(0);
        detailsArea.setText("");
        DataStore.User user = DataStore.getInstance().getCurrentUser();
        emailField.setText(user != null ? user.email : "");
    }

    private void styleTable(JTable table) {
        table.setFont(AppColors.BODY_FONT);
        table.setRowHeight(30);
        table.setGridColor(new Color(220, 215, 200));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
