package sss;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class ReportManagementPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTable table;
    private JComboBox<String> filterStatus, filterPriority;

    // Detail pane
    private JLabel detId, detSubject, detSubmitter, detDate, detCategory, detPriority;
    private JTextArea detDetails, remarksArea;
    private JComboBox<String> statusBox;

    public ReportManagementPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel t = new JLabel("📋  Report Management");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        hdr.add(t, BorderLayout.WEST);
        JButton back = UIUtils.secondaryButton("← Dashboard");
        back.addActionListener(e -> mainFrame.showPanel("admin_dashboard"));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(AppColors.DARK_GREEN);
        right.add(back);
        hdr.add(right, BorderLayout.EAST);
        return hdr;
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new GridLayout(1, 2, 16, 0));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(16, 20, 16, 20));
        body.add(buildTablePanel());
        body.add(buildDetailPanel());
        return body;
    }

    private JPanel buildTablePanel() {
        JPanel card = whiteCard(new BorderLayout(0, 8));

        JLabel t = new JLabel("All Reports");
        t.setFont(new Font("Segoe UI", Font.BOLD, 16));
        t.setForeground(AppColors.DARK_GREEN);
        card.add(t, BorderLayout.NORTH);

        // Filters
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filters.setBackground(Color.WHITE);
        filterStatus   = UIUtils.styledCombo(new String[]{"All","Pending","Processing","Resolved","Closed"});
        filterPriority = UIUtils.styledCombo(new String[]{"All","Low","Medium","High","Urgent"});
        JButton applyBtn = UIUtils.primaryButton("Filter");
        applyBtn.setPreferredSize(new Dimension(80, 28));
        applyBtn.addActionListener(e -> loadTable());
        filters.add(new JLabel("Status:")); filters.add(filterStatus);
        filters.add(new JLabel("Priority:")); filters.add(filterPriority);
        filters.add(applyBtn);
        card.add(filters, BorderLayout.SOUTH);

        String[] cols = {"ID","Subject","Category","Priority","Submitter","Status","Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (col == 5) {
                    JLabel lbl = UIUtils.statusBadge((String) getValueAt(row, col));
                    lbl.setHorizontalAlignment(SwingConstants.CENTER);
                    return lbl;
                }
                if (!isRowSelected(row))
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(70);
        table.getColumnModel().getColumn(4).setPreferredWidth(130);
        table.getColumnModel().getColumn(5).setPreferredWidth(85);
        table.getColumnModel().getColumn(6).setPreferredWidth(110);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadDetail();
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        loadTable();
        return card;
    }

    private JPanel buildDetailPanel() {
        JPanel card = whiteCard(new BorderLayout(0, 10));

        JLabel title = new JLabel("Report Detail");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(Color.WHITE);

        detId        = infoLabel("—");
        detSubject   = infoLabel("—");
        detSubmitter = infoLabel("—");
        detDate      = infoLabel("—");
        detCategory  = infoLabel("—");
        detPriority  = infoLabel("—");

        fields.add(detailRow("Report ID",    detId));
        fields.add(Box.createVerticalStrut(6));
        fields.add(detailRow("Subject",      detSubject));
        fields.add(Box.createVerticalStrut(6));
        fields.add(detailRow("Submitted By", detSubmitter));
        fields.add(Box.createVerticalStrut(6));
        fields.add(detailRow("Date",         detDate));
        fields.add(Box.createVerticalStrut(6));
        fields.add(detailRow("Category",     detCategory));
        fields.add(Box.createVerticalStrut(6));
        fields.add(detailRow("Priority",     detPriority));
        fields.add(Box.createVerticalStrut(10));

        JLabel detLbl = new JLabel("Details:");
        detLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        detLbl.setForeground(AppColors.TEXT_DARK);
        fields.add(detLbl);
        fields.add(Box.createVerticalStrut(4));
        detDetails = UIUtils.styledArea(4, 30);
        detDetails.setEditable(false);
        detDetails.setBackground(new Color(248, 250, 252));
        JScrollPane ds = new JScrollPane(detDetails);
        ds.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(ds);
        fields.add(Box.createVerticalStrut(12));

        // Status update
        fields.add(sectionLabel("Update Status"));
        statusBox = UIUtils.styledCombo(new String[]{"Pending","Processing","Resolved","Closed"});
        fields.add(Box.createVerticalStrut(4));
        fields.add(UIUtils.formRow("New Status", statusBox));
        fields.add(Box.createVerticalStrut(8));

        JLabel remLbl = new JLabel("Admin Remarks:");
        remLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        remLbl.setForeground(AppColors.TEXT_DARK);
        fields.add(remLbl);
        fields.add(Box.createVerticalStrut(4));
        remarksArea = UIUtils.styledArea(3, 30);
        JScrollPane rs = new JScrollPane(remarksArea);
        rs.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(rs);
        fields.add(Box.createVerticalStrut(12));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(Color.WHITE);
        JButton updateBtn = UIUtils.primaryButton("Update");
        JButton deleteBtn = UIUtils.secondaryButton("Delete Report");
        updateBtn.addActionListener(e -> updateReport());
        deleteBtn.addActionListener(e -> deleteReport());
        btns.add(deleteBtn); btns.add(updateBtn);
        fields.add(btns);

        // Email status indicator
        emailStatusLabel = new JLabel(" ");
        emailStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        emailStatusLabel.setForeground(AppColors.TEXT_GRAY);
        fields.add(Box.createVerticalStrut(4));
        fields.add(emailStatusLabel);

        JScrollPane outer = new JScrollPane(fields);
        outer.setBorder(null);
        card.add(outer, BorderLayout.CENTER);
        return card;
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        String fs = (String) filterStatus.getSelectedItem();
        String fp = (String) filterPriority.getSelectedItem();
        for (DataStore.Report r : DataStore.getInstance().getReports()) {
            if (!"All".equals(fs) && !r.status.equals(fs)) continue;
            if (!"All".equals(fp) && !r.priority.equals(fp)) continue;
            tableModel.addRow(new Object[]{
                r.id, r.subject, r.category, r.priority, r.submitter, r.status, r.date
            });
        }
    }

    private void loadDetail() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String id = (String) tableModel.getValueAt(row, 0);
        for (DataStore.Report r : DataStore.getInstance().getReports()) {
            if (r.id.equals(id)) {
                detId.setText(r.id);
                detSubject.setText(r.subject);
                detSubmitter.setText(r.submitter);
                detDate.setText(r.date);
                detCategory.setText(r.category);
                detPriority.setText(r.priority);
                detDetails.setText(r.details);
                remarksArea.setText(r.remarks);
                for (int i = 0; i < statusBox.getItemCount(); i++) {
                    if (statusBox.getItemAt(i).equals(r.status)) { statusBox.setSelectedIndex(i); break; }
                }
                return;
            }
        }
    }

    private void updateReport() {
        if (detId.getText().equals("—")) { UIUtils.showError(this, "Select a report first."); return; }
        String id     = detId.getText();
        String status = (String) statusBox.getSelectedItem();
        String remark = remarksArea.getText().trim();
        DataStore ds  = DataStore.getInstance();
        ds.updateReportStatus(id, status);
        ds.updateReportRemarks(id, remark);

        // ── Email notification ────────────────────────────────────────────
        String submitterName = detSubmitter.getText();
        String subject       = detSubject.getText();
        String studentEmail  = findStudentEmail(submitterName);
        EmailService.notifyReportUpdate(
            studentEmail, submitterName, id, subject, status, remark,
            err -> javax.swing.SwingUtilities.invokeLater(() -> {
                if (err == null)
                    showEmailSentBadge("Report #" + id + " updated. Email sent to " + studentEmail);
                else
                    showEmailWarn("Report updated but email failed: " + err);
            })
        );

        UIUtils.showSuccess(this, "Report #" + id + " updated to: " + status +
            "\nEmail notification is being sent.");
        loadTable();
    }

    private void deleteReport() {
        if (detId.getText().equals("—")) { UIUtils.showError(this, "Select a report first."); return; }
        String id = detId.getText();
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete Report #" + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            DataStore.getInstance().deleteReport(id);
            resetDetail();
            loadTable();
            UIUtils.showSuccess(this, "Report deleted.");
        }
    }

    private void resetDetail() {
        detId.setText("—"); detSubject.setText("—"); detSubmitter.setText("—");
        detDate.setText("—"); detCategory.setText("—"); detPriority.setText("—");
        detDetails.setText(""); remarksArea.setText("");
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    private JLabel infoLabel(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(AppColors.BODY_FONT);
        l.setForeground(Color.BLACK);
        return l;
    }

    private JPanel detailRow(String label, JLabel value) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(Color.WHITE);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
        JLabel lbl = new JLabel(label + ":");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(Color.BLACK);
        lbl.setPreferredSize(new Dimension(110, 22));
        row.add(lbl, BorderLayout.WEST);
        row.add(value, BorderLayout.CENTER);
        return row;
    }

    private JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 14));
        l.setForeground(AppColors.DARK_GREEN);
        return l;
    }

    private void styleTable(JTable t) {
        t.setFont(AppColors.BODY_FONT);
        t.setRowHeight(30);
        t.setGridColor(new Color(235, 235, 240));
        t.setSelectionBackground(new Color(200, 235, 215));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.getTableHeader().setBackground(AppColors.DARK_GREEN);
        t.getTableHeader().setForeground(Color.BLACK);
    }

    private JPanel whiteCard(LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 230), 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));
        return p;
    }

    // ── Email helpers ──────────────────────────────────────────────────────

    /** Looks up the registered email for a user by their full name. */
    private String findStudentEmail(String fullName) {
        for (DataStore.User u : DataStore.getInstance().getAllUsers()) {
            if (u.fullName.equalsIgnoreCase(fullName)) return u.email;
        }
        return EmailConfig.FALLBACK_STUDENT_EMAIL;
    }

    private JLabel emailStatusLabel;

    private void showEmailSentBadge(String msg) {
        if (emailStatusLabel != null) {
            emailStatusLabel.setText("✅ " + msg);
            emailStatusLabel.setForeground(new Color(22, 130, 70));
        }
    }

    private void showEmailWarn(String msg) {
        if (emailStatusLabel != null) {
            emailStatusLabel.setText("⚠️ " + msg);
            emailStatusLabel.setForeground(new Color(180, 90, 0));
        }
    }
}
