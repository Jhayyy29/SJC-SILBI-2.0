package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class FileReportPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;

    // Form fields
    private JComboBox<String> categoryBox, priorityBox;
    private JTextField subjectField;
    private JTextArea detailsArea;

    public FileReportPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("⚠️  File a Report",
            "Submit incidents, concerns, or issues to the administration."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new GridLayout(1, 2, 16, 0));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));

        main.add(buildForm());
        main.add(buildHistory());
        return main;
    }

    private JPanel buildForm() {
        JPanel card = UIUtils.createCard("Submit a New Report");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        categoryBox = UIUtils.styledCombo(new String[]{
            "Bullying / Harassment", "Academic Concern", "Facility Issue",
            "Safety Hazard", "Misconduct", "Other"
        });
        priorityBox = UIUtils.styledCombo(new String[]{"Low", "Medium", "High", "Urgent"});
        subjectField = UIUtils.styledField("Brief description of the issue");
        detailsArea  = UIUtils.styledArea(6, 30);

        fields.add(UIUtils.formRow("Category", categoryBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Priority", priorityBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Subject", subjectField));
        fields.add(Box.createVerticalStrut(10));

        JLabel detLbl = new JLabel("Details");
        detLbl.setFont(AppColors.BODY_FONT);
        detLbl.setForeground(AppColors.TEXT_DARK);
        fields.add(detLbl);
        fields.add(Box.createVerticalStrut(4));

        JScrollPane detScroll = new JScrollPane(detailsArea);
        detScroll.setBorder(new LineBorder(AppColors.BORDER));
        detScroll.setPreferredSize(new Dimension(0, 120));
        fields.add(detScroll);
        fields.add(Box.createVerticalStrut(16));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(AppColors.CARD_BG);
        JButton clearBtn = UIUtils.secondaryButton("Clear");
        JButton submitBtn = UIUtils.primaryButton("Submit Report");
        clearBtn.addActionListener(e -> clearForm());
        submitBtn.addActionListener(e -> submitReport());
        btns.add(clearBtn);
        btns.add(submitBtn);
        fields.add(btns);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildHistory() {
        JPanel card = UIUtils.createCard("My Submitted Reports");

        String[] cols = {"ID", "Subject", "Category", "Priority", "Status", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel) {
            @Override public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
                Component c = super.prepareRenderer(renderer, row, col);
                if (col == 4) {
                    String status = (String) getValueAt(row, col);
                    JLabel badge = UIUtils.statusBadge(status);
                    badge.setHorizontalAlignment(SwingConstants.CENTER);
                    return badge;
                }
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(70);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(120);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        JButton refreshBtn = UIUtils.secondaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadReports());
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(AppColors.CARD_BG);
        btnRow.add(refreshBtn);
        card.add(btnRow, BorderLayout.SOUTH);

        loadReports();
        return card;
    }

    private void loadReports() {
        tableModel.setRowCount(0);
        String currentUser = DataStore.getInstance().isLoggedIn()
            ? DataStore.getInstance().getCurrentUser().fullName : "";
        for (DataStore.Report r : DataStore.getInstance().getReports()) {
            if (!DataStore.getInstance().isLoggedIn() || r.submitter.equals(currentUser)) {
                tableModel.addRow(new Object[]{
                    r.id, r.subject, r.category, r.priority, r.status, r.date
                });
            }
        }
    }

    private void submitReport() {
        String cat     = (String) categoryBox.getSelectedItem();
        String pri     = (String) priorityBox.getSelectedItem();
        String subject = subjectField.getText().trim();
        String details = detailsArea.getText().trim();

        if (subject.isEmpty()) { UIUtils.showError(this, "Please enter a subject."); return; }
        if (details.isEmpty()) { UIUtils.showError(this, "Please enter report details."); return; }

        DataStore.Report r = DataStore.getInstance().submitReport(cat, subject, details, pri);
        UIUtils.showSuccess(this, "Report #" + r.id + " submitted successfully!\nStatus: Pending review.");
        clearForm();
        loadReports();
    }

    private void clearForm() {
        subjectField.setText("");
        detailsArea.setText("");
        categoryBox.setSelectedIndex(0);
        priorityBox.setSelectedIndex(0);
    }

    private void styleTable(JTable table) {
        table.setFont(AppColors.BODY_FONT);
        table.setRowHeight(30);
        table.setGridColor(new Color(220, 215, 200));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
