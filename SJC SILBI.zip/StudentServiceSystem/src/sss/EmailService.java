package sss;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.*;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Sends HTML emails via Gmail SMTP (SSL port 465) using only JDK classes.
 * No external JARs required.
 *
 * Emails are dispatched on a background thread so the UI never freezes.
 */
public class EmailService {

    /** Single background thread for all email sends. */
    private static final ExecutorService EXECUTOR =
        Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "email-sender");
            t.setDaemon(true);
            return t;
        });

    // ── Public API ─────────────────────────────────────────────────────────

    /**
     * Sends a status-update email asynchronously.
     *
     * @param toEmail   recipient address
     * @param toName    recipient full name
     * @param subject   email subject
     * @param bodyHtml  HTML body content
     * @param onResult  callback: receives null on success, error message on failure
     */
    public static void sendAsync(String toEmail, String toName,
                                 String subject, String bodyHtml,
                                 Consumer<String> onResult) {
        if (!EmailConfig.isConfigured()) {
            if (onResult != null)
                onResult.accept("Email not configured. Set ADMIN_APP_PASSWORD in EmailConfig.java.");
            return;
        }

        String resolvedEmail = (toEmail == null || toEmail.isBlank())
            ? EmailConfig.FALLBACK_STUDENT_EMAIL : toEmail;

        EXECUTOR.submit(() -> {
            String err = sendSmtp(resolvedEmail, toName, subject, bodyHtml);
            if (onResult != null) onResult.accept(err);
        });
    }

    // ── Pre-built email templates ──────────────────────────────────────────

    /** Report status update notification */
    public static void notifyReportUpdate(String toEmail, String toName,
                                          String reportId, String subject,
                                          String newStatus, String remarks,
                                          Consumer<String> cb) {
        String color = statusColor(newStatus);
        String html  = htmlWrap(toName,
            "<p>Your report has been updated by the administrator.</p>" +
            "<table style='border-collapse:collapse;width:100%'>" +
            detailRow("Report ID",  "#" + reportId) +
            detailRow("Subject",    subject) +
            detailRow("New Status", "<span style='background:" + color + ";color:#fff;" +
                "padding:3px 10px;border-radius:4px;font-weight:bold'>" + newStatus + "</span>") +
            (remarks.isEmpty() ? "" : detailRow("Admin Remarks", remarks)) +
            "</table>" +
            "<p style='margin-top:18px'>You can log in to the Student Service System to view the full details.</p>"
        );
        sendAsync(toEmail, toName,
            "📋 Report #" + reportId + " — Status: " + newStatus, html, cb);
    }

    /** Document request status update */
    public static void notifyDocUpdate(String toEmail, String toName,
                                       String requestId, String docType,
                                       String newStatus, String remarks,
                                       Consumer<String> cb) {
        String color = statusColor(newStatus);
        String html  = htmlWrap(toName,
            "<p>Your document request has been processed by the Registrar / Admin.</p>" +
            "<table style='border-collapse:collapse;width:100%'>" +
            detailRow("Request ID",    "#" + requestId) +
            detailRow("Document",      docType) +
            detailRow("New Status",    "<span style='background:" + color + ";color:#fff;" +
                "padding:3px 10px;border-radius:4px;font-weight:bold'>" + newStatus + "</span>") +
            (remarks.isEmpty() ? "" : detailRow("Admin Remarks", remarks)) +
            "</table>" +
            actionNote(newStatus,
                "Ready"     , "Please visit the Registrar's Office to claim your document.",
                "Completed" , "Your document has been released. Thank you!",
                "Rejected"  , "Your request was not approved. Please contact the Registrar for more information.",
                "Processing", "Your request is being processed. We will notify you when it is ready.")
        );
        sendAsync(toEmail, toName,
            "📄 Document Request #" + requestId + " — " + newStatus, html, cb);
    }

    /** Appointment status update */
    public static void notifyAppointmentUpdate(String toEmail, String toName,
                                               String apptId, String office,
                                               String date, String time,
                                               String newStatus,
                                               Consumer<String> cb) {
        String color = statusColor(newStatus);
        String html  = htmlWrap(toName,
            "<p>Your appointment status has been updated.</p>" +
            "<table style='border-collapse:collapse;width:100%'>" +
            detailRow("Appointment ID", "#" + apptId) +
            detailRow("Office",         office) +
            detailRow("Schedule",       date + " at " + time) +
            detailRow("New Status",     "<span style='background:" + color + ";color:#fff;" +
                "padding:3px 10px;border-radius:4px;font-weight:bold'>" + newStatus + "</span>") +
            "</table>" +
            actionNote(newStatus,
                "Confirmed" , "Your appointment is confirmed. Please arrive 5 minutes early.",
                "Completed" , "Your appointment has been completed. Thank you for visiting!",
                "Cancelled" , "Your appointment has been cancelled. Please book a new one if needed.",
                "No-show"   , "You were marked as a no-show. Please contact the office to reschedule.")
        );
        sendAsync(toEmail, toName,
            "📅 Appointment #" + apptId + " — " + newStatus, html, cb);
    }

    /** Information request response */
    public static void notifyInfoResponse(String toEmail, String toName,
                                          String requestId, String topic,
                                          String newStatus, String adminResponse,
                                          Consumer<String> cb) {
        String color = statusColor(newStatus);
        String html  = htmlWrap(toName,
            "<p>Your information request has received a response from the administration.</p>" +
            "<table style='border-collapse:collapse;width:100%'>" +
            detailRow("Request ID", "#" + requestId) +
            detailRow("Topic",      topic) +
            detailRow("Status",     "<span style='background:" + color + ";color:#fff;" +
                "padding:3px 10px;border-radius:4px;font-weight:bold'>" + newStatus + "</span>") +
            "</table>" +
            (adminResponse.isEmpty() ? "" :
                "<div style='margin-top:16px;background:#f0f9f5;border-left:4px solid #22874a;" +
                "padding:12px 16px;border-radius:4px'>" +
                "<strong style='color:#1b523c'>Admin Response:</strong>" +
                "<p style='margin:8px 0 0 0;color:#333'>" +
                adminResponse.replace("\n", "<br>") + "</p></div>")
        );
        sendAsync(toEmail, toName,
            "ℹ️ Info Request #" + requestId + " — " + newStatus, html, cb);
    }

    // ── SMTP core ──────────────────────────────────────────────────────────

    /**
     * Opens an SSL connection to smtp.gmail.com:465 and sends one email.
     * Returns null on success, or an error description on failure.
     */
    private static String sendSmtp(String toEmail, String toName,
                                   String subject, String bodyHtml) {
        try {
            SSLSocketFactory factory =
                (SSLSocketFactory) SSLSocketFactory.getDefault();

            try (SSLSocket socket = (SSLSocket) factory.createSocket(
                    EmailConfig.SMTP_HOST, EmailConfig.SMTP_PORT)) {

                socket.setSoTimeout(15_000);
                socket.startHandshake();

                BufferedReader in  = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(),  "UTF-8"));
                PrintWriter    out = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

                // SMTP conversation
                expect(in, "220");
                send(out, "EHLO smtp.gmail.com");
                readUntilEnd(in, "250");

                // AUTH LOGIN
                send(out, "AUTH LOGIN");
                expect(in, "334");
                send(out, b64(EmailConfig.ADMIN_EMAIL));
                expect(in, "334");
                send(out, b64(EmailConfig.ADMIN_APP_PASSWORD));
                expect(in, "235");

                // Envelope
                send(out, "MAIL FROM:<" + EmailConfig.ADMIN_EMAIL + ">");
                expect(in, "250");
                send(out, "RCPT TO:<" + toEmail + ">");
                expect(in, "250");
                send(out, "DATA");
                expect(in, "354");

                // Headers + body
                String msg = buildMimeMessage(toEmail, toName, subject, bodyHtml);
                out.print(msg);
                out.print("\r\n.\r\n");
                out.flush();
                expect(in, "250");

                send(out, "QUIT");
            }
            return null; // success

        } catch (SmtpException e) {
            return "SMTP error: " + e.getMessage();
        } catch (Exception e) {
            return "Connection error: " + e.getMessage();
        }
    }

    // ── SMTP helpers ───────────────────────────────────────────────────────

    private static void send(PrintWriter out, String cmd) {
        out.print(cmd + "\r\n");
        out.flush();
    }

    private static void expect(BufferedReader in, String code) throws Exception {
        String line = in.readLine();
        if (line == null || !line.startsWith(code))
            throw new SmtpException("Expected " + code + " but got: " + line);
    }

    /** Reads multi-line EHLO response until a line starting with "250 " */
    private static void readUntilEnd(BufferedReader in, String code) throws Exception {
        String line;
        do { line = in.readLine(); } while (line != null && line.startsWith(code + "-"));
        if (line == null || !line.startsWith(code))
            throw new SmtpException("Expected " + code + " but got: " + line);
    }

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    private static String buildMimeMessage(String toEmail, String toName,
                                           String subject, String htmlBody) {
        String boundary = "----=_SSS_" + System.currentTimeMillis();
        String safeSubject = "=?UTF-8?B?" +
            Base64.getEncoder().encodeToString(subject.getBytes()) + "?=";

        StringBuilder sb = new StringBuilder();
        sb.append("From: ").append(EmailConfig.SCHOOL_NAME)
          .append(" <").append(EmailConfig.ADMIN_EMAIL).append(">\r\n");
        sb.append("To: ").append(toName).append(" <").append(toEmail).append(">\r\n");
        sb.append("Subject: ").append(safeSubject).append("\r\n");
        sb.append("MIME-Version: 1.0\r\n");
        sb.append("Content-Type: multipart/alternative; boundary=\"").append(boundary).append("\"\r\n");
        sb.append("\r\n");

        // Plain text fallback
        sb.append("--").append(boundary).append("\r\n");
        sb.append("Content-Type: text/plain; charset=UTF-8\r\n\r\n");
        sb.append("Dear ").append(toName).append(",\r\n\r\n");
        sb.append(subject).append("\r\n\r\n");
        sb.append("Please log in to the Student Service System for full details.\r\n\r\n");
        sb.append("-- ").append(EmailConfig.SCHOOL_FOOTER).append("\r\n\r\n");

        // HTML part
        sb.append("--").append(boundary).append("\r\n");
        sb.append("Content-Type: text/html; charset=UTF-8\r\n\r\n");
        sb.append(htmlBody).append("\r\n\r\n");

        sb.append("--").append(boundary).append("--\r\n");
        return sb.toString();
    }

    // ── HTML template helpers ──────────────────────────────────────────────

    /** Wraps content in a styled HTML email template. */
    private static String htmlWrap(String recipientName, String content) {
        return "<!DOCTYPE html><html><head><meta charset='UTF-8'></head><body " +
            "style='margin:0;padding:0;background:#f4f4f4;font-family:Segoe UI,Arial,sans-serif'>" +
            "<table width='100%' cellpadding='0' cellspacing='0' bgcolor='#f4f4f4'><tr><td>" +
            "<table width='620' cellpadding='0' cellspacing='0' align='center' " +
            "style='background:#fff;margin:30px auto;border-radius:8px;overflow:hidden;" +
            "box-shadow:0 2px 8px rgba(0,0,0,.08)'>" +

            // Header
            "<tr><td style='background:#1b523c;padding:28px 36px'>" +
            "<p style='margin:0;color:#fff;font-size:11px;text-transform:uppercase;letter-spacing:1px'>" +
            EmailConfig.SCHOOL_FOOTER + "</p>" +
            "<h1 style='margin:6px 0 0 0;color:#fff;font-size:22px;font-weight:700'>" +
            EmailConfig.SCHOOL_NAME + "</h1></td></tr>" +

            // Body
            "<tr><td style='padding:32px 36px;color:#333;font-size:15px;line-height:1.6'>" +
            "<p style='margin:0 0 16px 0'>Dear <strong>" + recipientName + "</strong>,</p>" +
            content +
            "<p style='margin-top:28px;color:#666;font-size:13px'>" +
            "If you did not make this request, please contact the Student Affairs Office immediately.</p>" +
            "</td></tr>" +

            // Footer
            "<tr><td style='background:#f9f9f9;padding:18px 36px;border-top:1px solid #eee;" +
            "color:#999;font-size:12px;text-align:center'>" +
            "This is an automated message from " + EmailConfig.SCHOOL_NAME + ". " +
            "Please do not reply directly to this email." +
            "</td></tr></table></td></tr></table></body></html>";
    }

    private static String detailRow(String label, String value) {
        return "<tr>" +
            "<td style='padding:8px 12px 8px 0;color:#666;font-size:13px;width:140px;vertical-align:top'>" +
            "<strong>" + label + ":</strong></td>" +
            "<td style='padding:8px 0;color:#222;font-size:14px'>" + value + "</td>" +
            "</tr>";
    }

    /**
     * Returns an action-specific note paragraph.
     * Pairs: status, message, status, message, ...
     */
    private static String actionNote(String status, String... pairs) {
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            if (pairs[i].equalsIgnoreCase(status)) {
                return "<div style='margin-top:18px;background:#e8f5ee;border-left:4px solid #22874a;" +
                    "padding:12px 16px;border-radius:4px;color:#1b523c;font-size:14px'>" +
                    pairs[i + 1] + "</div>";
            }
        }
        return "";
    }

    private static String statusColor(String status) {
        return switch (status.toLowerCase()) {
            case "resolved", "completed", "ready", "confirmed" -> "#22874a";
            case "processing"                                  -> "#0c5460";
            case "rejected", "cancelled", "no-show"           -> "#721c24";
            default                                            -> "#495057";
        };
    }

    /** Checked exception for SMTP protocol errors. */
    private static class SmtpException extends Exception {
        SmtpException(String msg) { super(msg); }
    }
}
