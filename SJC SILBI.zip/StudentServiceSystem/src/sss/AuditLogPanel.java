package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class AuditLogPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public AuditLogPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel t = new JLabel("📜  System Audit Log");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        hdr.add(t, BorderLayout.WEST);
        JButton back = UIUtils.secondaryButton("← Dashboard");
        back.addActionListener(e -> mainFrame.showPanel("admin_dashboard"));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(AppColors.DARK_GREEN);
        right.add(back);
        hdr.add(right, BorderLayout.EAST);
        return hdr;
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(16, 20, 16, 20));

        // Search bar
        JPanel search = new JPanel(new BorderLayout(8, 0));
        search.setBackground(new Color(245, 246, 250));
        searchField = UIUtils.styledField("Search by actor, action, or details...");
        JButton searchBtn = UIUtils.primaryButton("Search");
        searchBtn.setPreferredSize(new Dimension(100, 34));
        searchBtn.addActionListener(e -> loadTable(searchField.getText().trim()));
        JButton clearBtn = UIUtils.secondaryButton("Clear");
        clearBtn.setPreferredSize(new Dimension(80, 34));
        clearBtn.addActionListener(e -> { searchField.setText(""); loadTable(""); });
        JPanel searchRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        searchRight.setBackground(new Color(245, 246, 250));
        searchRight.add(clearBtn); searchRight.add(searchBtn);
        search.add(new JLabel("🔍 "), BorderLayout.WEST);
        search.add(searchField, BorderLayout.CENTER);
        search.add(searchRight, BorderLayout.EAST);
        body.add(search, BorderLayout.NORTH);

        // Table
        String[] cols = {"Date / Time", "Actor", "Action", "Details"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (!isRowSelected(row))
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                return c;
            }
        };
        table.setFont(AppColors.BODY_FONT);
        table.setRowHeight(28);
        table.setGridColor(new Color(235, 235, 240));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
        table.getColumnModel().getColumn(0).setPreferredWidth(140);
        table.getColumnModel().getColumn(1).setPreferredWidth(110);
        table.getColumnModel().getColumn(2).setPreferredWidth(130);
        table.getColumnModel().getColumn(3).setPreferredWidth(500);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        body.add(sp, BorderLayout.CENTER);

        loadTable("");
        return body;
    }

    private void loadTable(String filter) {
        tableModel.setRowCount(0);
        List<DataStore.AuditLog> logs = DataStore.getInstance().getAuditLogs();
        for (DataStore.AuditLog log : logs) {
            if (!filter.isEmpty() &&
                !log.actor.toLowerCase().contains(filter.toLowerCase()) &&
                !log.action.toLowerCase().contains(filter.toLowerCase()) &&
                !log.details.toLowerCase().contains(filter.toLowerCase())) continue;
            tableModel.addRow(new Object[]{log.date, log.actor, log.action, log.details});
        }
    }
}
