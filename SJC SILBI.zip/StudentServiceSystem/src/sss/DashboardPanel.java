package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class DashboardPanel extends JPanel {

    private final MainFrame mainFrame;

    // Path to the SJC campus background image.
    // Place any JPG/PNG named "sjc_campus.jpg" inside the assets folder.
    private static final String IMAGE_PATH =
        "src/sss/assets/sjc_campus.jpg";

    /** Loads the hero background image once; null if file not found. */
    private static BufferedImage loadHeroImage() {
        // Try relative to working directory (project root when run via run.bat)
        File f = new File(IMAGE_PATH);
        if (!f.exists()) {
            // Also try beside the .class files
            f = new File("assets/sjc_campus.jpg");
        }
        if (f.exists()) {
            try {
                return ImageIO.read(f);
            } catch (IOException e) {
                System.err.println("Warning: could not load hero image — " + e.getMessage());
            }
        }
        return null;
    }

    private static final BufferedImage HERO_IMAGE = loadHeroImage();

    public DashboardPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(buildHero(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    // ── Hero banner ────────────────────────────────────────────────────────
    private JPanel buildHero() {
        JPanel hero = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC);

                if (HERO_IMAGE != null) {
                    // Draw campus photo scaled to fill the banner
                    int w = getWidth(), h = getHeight();
                    double scaleX = (double) w / HERO_IMAGE.getWidth();
                    double scaleY = (double) h / HERO_IMAGE.getHeight();
                    double scale  = Math.max(scaleX, scaleY);
                    int imgW = (int) (HERO_IMAGE.getWidth()  * scale);
                    int imgH = (int) (HERO_IMAGE.getHeight() * scale);
                    int offX = (w - imgW) / 2;
                    int offY = (h - imgH) / 2;
                    g2.drawImage(HERO_IMAGE, offX, offY, imgW, imgH, null);

                    // Dark green overlay so text stays readable
                    g2.setColor(new Color(27, 82, 60, 175));   // DARK_GREEN @ ~69% opacity
                    g2.fillRect(0, 0, w, h);
                } else {
                    // Fallback gradient when image is not present
                    GradientPaint gp = new GradientPaint(
                        0, 0, AppColors.DARK_GREEN,
                        getWidth(), getHeight(), new Color(22, 110, 80)
                    );
                    g2.setPaint(gp);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                }
                g2.dispose();
            }
        };
        hero.setPreferredSize(new Dimension(0, 240));
        hero.setBorder(new EmptyBorder(40, 36, 40, 36));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);

        JLabel welcome = new JLabel("WELCOME TO");
        welcome.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        welcome.setForeground(new Color(180, 220, 200));
        welcome.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Bold italic title matching the screenshot style
        JLabel title = new JLabel("SJC SILBI");
        title.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 36));
        title.setForeground(AppColors.WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Transforming school services for a faster, convenient,");
        sub.setFont(new Font("Segoe UI", Font.ITALIC, 15));
        sub.setForeground(new Color(220, 245, 232));
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        String userName = DataStore.getInstance().isLoggedIn()
            ? DataStore.getInstance().getCurrentUser().fullName : "Guest";
        JLabel sub2 = new JLabel("and smarter digital experience for " + userName + ".");
        sub2.setFont(new Font("Segoe UI", Font.ITALIC, 15));
        sub2.setForeground(new Color(220, 245, 232));
        sub2.setAlignmentX(Component.LEFT_ALIGNMENT);

        textPanel.add(welcome);
        textPanel.add(Box.createVerticalStrut(4));
        textPanel.add(title);
        textPanel.add(Box.createVerticalStrut(8));
        textPanel.add(sub);
        textPanel.add(Box.createVerticalStrut(2));
        textPanel.add(sub2);
        hero.add(textPanel, BorderLayout.WEST);

        // Quick stats
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 16, 0));
        stats.setOpaque(false);
        DataStore ds = DataStore.getInstance();
        stats.add(quickStat("📋", String.valueOf(ds.getReports().size()), "Reports"));
        stats.add(quickStat("📄", String.valueOf(ds.getDocRequests().size()), "Doc Reqs"));
        stats.add(quickStat("📅", String.valueOf(ds.getAppointments().size()), "Appts"));
        stats.add(quickStat("🔔", String.valueOf(ds.getUnreadCount()), "Unread"));
        hero.add(stats, BorderLayout.EAST);

        return hero;
    }

    private JPanel quickStat(String icon, String val, String label) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setBorder(new CompoundBorder(
            new LineBorder(new Color(100, 180, 140), 1, true),
            new EmptyBorder(8, 14, 8, 14)
        ));

        JLabel ico = new JLabel(icon, SwingConstants.CENTER);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        ico.setAlignmentX(CENTER_ALIGNMENT);

        JLabel num = new JLabel(val, SwingConstants.CENTER);
        num.setFont(new Font("Segoe UI", Font.BOLD, 22));
        num.setForeground(AppColors.WHITE);
        num.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lbl.setForeground(new Color(180, 220, 200));
        lbl.setAlignmentX(CENTER_ALIGNMENT);

        p.add(ico);
        p.add(num);
        p.add(lbl);
        return p;
    }

    // ── Body ───────────────────────────────────────────────────────────────
    private JScrollPane buildBody() {
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(AppColors.CREAM);
        body.setBorder(new EmptyBorder(20, 24, 24, 24));

        // FAQ link
        JLabel faq = new JLabel("Got a Question?  Check our FAQS >");
        faq.setFont(AppColors.SMALL_FONT);
        faq.setForeground(AppColors.MEDIUM_GREEN);
        faq.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        faq.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                JOptionPane.showMessageDialog(DashboardPanel.this,
                    "Frequently Asked Questions\n\n" +
                    "Q: How do I request a document?\n" +
                    "A: Go to Online Document Request and fill out the form.\n\n" +
                    "Q: How do I book an appointment?\n" +
                    "A: Go to Appointment Booking and select your preferred office and time.\n\n" +
                    "Q: How do I track my request status?\n" +
                    "A: Check the respective module — each shows a request history table.",
                    "FAQ", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        faq.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(faq);
        body.add(Box.createVerticalStrut(12));

        // Popular Services section
        body.add(sectionHeader("Popular Services"));
        body.add(Box.createVerticalStrut(10));
        body.add(buildServiceGrid());
        body.add(Box.createVerticalStrut(28));

        // People's Corner
        body.add(sectionHeader("People's Corner — BE HEARD! BE INVOLVED!"));
        body.add(Box.createVerticalStrut(10));
        body.add(buildPeoplesCorner());

        JScrollPane sp = new JScrollPane(body);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.setBackground(AppColors.CREAM);
        return sp;
    }

    private JLabel sectionHeader(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lbl.setForeground(AppColors.DARK_GREEN);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    // 2×3 grid of popular service tiles
    private JPanel buildServiceGrid() {
        JPanel grid = new JPanel(new GridLayout(2, 3, 14, 14));
        grid.setBackground(AppColors.CREAM);
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));

        addTile(grid, "📊", "Access Open Data",       "opendata");
        addTile(grid, "⚠️",  "File a Report",          "report");
        addTile(grid, "📄", "Online Document Request", "docrequest");
        addTile(grid, "🔔", "Push Notifications",      "notifications");
        addTile(grid, "📅", "Appointment Booking",     "appointment");
        addTile(grid, "⊞",  "View all Service",        "services");

        return grid;
    }

    private void addTile(JPanel grid, String icon, String label, String panelKey) {
        JButton tile = UIUtils.serviceTile(icon, label);
        tile.setPreferredSize(new Dimension(180, 90));
        tile.addActionListener(e -> mainFrame.showPanel(panelKey));
        grid.add(tile);
    }

    // People's Corner — 4 feature cards
    private JPanel buildPeoplesCorner() {
        JPanel row = new JPanel(new GridLayout(1, 4, 14, 0));
        row.setBackground(AppColors.CREAM);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));

        row.add(cornerCard("🛠️", "Request a Service",
            "Submit service requests to the Student's Service System for issues like bullying..",
            "servicerequest"));
        row.add(cornerCard("📈", "Real time request status",
            "Lets students track whether their request is pending, processing, or completed.",
            "report"));
        row.add(cornerCard("👤", "Student profile management",
            "Allows students to view and update their personal and academic information.",
            "profile"));
        row.add(cornerCard("ℹ️", "Request for Information",
            "Allows students to request school documents online without needing to visit the office.",
            "inforequest"));

        return row;
    }

    private JPanel cornerCard(String icon, String title, String desc, String panelKey) {
        JPanel card = new JPanel(new BorderLayout(6, 6));
        card.setBackground(AppColors.DARK_GREEN);
        card.setBorder(new CompoundBorder(
            new LineBorder(AppColors.MEDIUM_GREEN, 1, true),
            new EmptyBorder(14, 14, 14, 14)
        ));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Icon circle
        JLabel ico = new JLabel(icon, SwingConstants.CENTER);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        ico.setPreferredSize(new Dimension(60, 60));
        card.add(ico, BorderLayout.WEST);

        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setBackground(AppColors.DARK_GREEN);

        JLabel titleLbl = new JLabel("<html><b>" + title + "</b></html>");
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(AppColors.WHITE);

        JLabel descLbl = new JLabel("<html>" + desc + "</html>");
        descLbl.setFont(AppColors.SMALL_FONT);
        descLbl.setForeground(new Color(180, 220, 200));

        text.add(titleLbl);
        text.add(Box.createVerticalStrut(4));
        text.add(descLbl);
        card.add(text, BorderLayout.CENTER);

        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                mainFrame.showPanel(panelKey);
            }
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                card.setBackground(new Color(34, 100, 72));
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                card.setBackground(AppColors.DARK_GREEN);
            }
        });

        return card;
    }
}
