package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class AdminDashboardPanel extends JPanel {

    private final MainFrame mainFrame;

    public AdminDashboardPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    // ── Top bar ────────────────────────────────────────────────────────────
    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(AppColors.DARK_GREEN);
        bar.setBorder(new EmptyBorder(18, 28, 18, 28));

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(AppColors.DARK_GREEN);
        JLabel title = new JLabel("Admin Control Panel");
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Student Service System — SJC  |  " + DataStore.now());
        sub.setFont(AppColors.SMALL_FONT);
        sub.setForeground(new Color(180, 220, 200));
        left.add(title);
        left.add(Box.createVerticalStrut(3));
        left.add(sub);
        bar.add(left, BorderLayout.WEST);

        // Admin badge
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setBackground(AppColors.DARK_GREEN);
        String name = DataStore.getInstance().isLoggedIn()
            ? DataStore.getInstance().getCurrentUser().fullName : "Admin";
        JLabel badge = new JLabel("⚙️  " + name);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 13));
        badge.setForeground(AppColors.CREAM);
        badge.setBorder(new CompoundBorder(
            new LineBorder(AppColors.MEDIUM_GREEN, 1, true),
            new EmptyBorder(5, 14, 5, 14)
        ));
        right.add(badge);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    // ── Body ───────────────────────────────────────────────────────────────
    private JPanel buildBody() {
        JPanel body = new JPanel(new BorderLayout(16, 16));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(20, 24, 20, 24));
        body.add(buildStatsRow(), BorderLayout.NORTH);
        body.add(buildMiddle(), BorderLayout.CENTER);
        return body;
    }

    // ── Stat cards row ─────────────────────────────────────────────────────
    private JPanel buildStatsRow() {
        DataStore ds = DataStore.getInstance();
        long pendingReports = ds.getReports().stream()
            .filter(r -> "Pending".equals(r.status)).count();
        long pendingDocs = ds.getDocRequests().stream()
            .filter(d -> "Pending".equals(d.status)).count();
        long pendingInfo = ds.getInfoRequests().stream()
            .filter(i -> "Pending".equals(i.status)).count();
        long totalUsers = ds.getAllUsers().size();

        JPanel row = new JPanel(new GridLayout(1, 6, 14, 0));
        row.setBackground(new Color(245, 246, 250));
        row.add(statCard("👥", String.valueOf(totalUsers),       "Total Users",        new Color(52, 152, 219)));
        row.add(statCard("📋", String.valueOf(ds.getReports().size()), "Reports",        new Color(231, 76, 60)));
        row.add(statCard("⚠️",  String.valueOf(pendingReports),  "Pending Reports",    new Color(230, 126, 34)));
        row.add(statCard("📄", String.valueOf(ds.getDocRequests().size()), "Doc Requests", AppColors.MEDIUM_GREEN));
        row.add(statCard("📅", String.valueOf(ds.getAppointments().size()), "Appointments", new Color(142, 68, 173)));
        row.add(statCard("ℹ️",  String.valueOf(pendingInfo),     "Pending Info Reqs",  new Color(22, 160, 133)));
        return row;
    }

    private JPanel statCard(String icon, String value, String label, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 230), 1, true),
            new EmptyBorder(18, 18, 18, 18)
        ));
        // Accent bar on top
        JPanel accent1 = new JPanel();
        accent1.setBackground(accent);
        accent1.setPreferredSize(new Dimension(0, 4));
        card.add(accent1, BorderLayout.NORTH);

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(Color.WHITE);

        JLabel ico = new JLabel(icon);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));
        ico.setAlignmentX(CENTER_ALIGNMENT);

        JLabel val = new JLabel(value);
        val.setFont(new Font("Segoe UI", Font.BOLD, 32));
        val.setForeground(accent);
        val.setAlignmentX(CENTER_ALIGNMENT);

        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(new Color(120, 120, 130));
        lbl.setAlignmentX(CENTER_ALIGNMENT);

        center.add(Box.createVerticalStrut(4));
        center.add(ico);
        center.add(Box.createVerticalStrut(4));
        center.add(val);
        center.add(lbl);
        card.add(center, BorderLayout.CENTER);
        return card;
    }

    // ── Middle section: quick nav + audit log ──────────────────────────────
    private JPanel buildMiddle() {
        JPanel mid = new JPanel(new GridLayout(1, 2, 16, 0));
        mid.setBackground(new Color(245, 246, 250));
        mid.add(buildQuickNav());
        mid.add(buildAuditLog());
        return mid;
    }

    private JPanel buildQuickNav() {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 230), 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel title = new JLabel("Quick Navigation");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(3, 2, 12, 12));
        grid.setBackground(Color.WHITE);

        grid.add(navBtn("👥  Users",         "admin_users"));
        grid.add(navBtn("📋  Reports",        "admin_reports"));
        grid.add(navBtn("📄  Documents",      "admin_docs"));
        grid.add(navBtn("📅  Appointments",   "admin_appointments"));
        grid.add(navBtn("🔔  Notifications",  "admin_notifications"));
        grid.add(navBtn("🛠️  Service Requests", "admin_servicemgmt"));

        card.add(grid, BorderLayout.CENTER);

        JButton auditBtn = UIUtils.secondaryButton("📜  View Full Audit Log");
        auditBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        auditBtn.addActionListener(e -> mainFrame.showPanel("admin_audit"));
        JPanel south = new JPanel(new BorderLayout());
        south.setBackground(Color.WHITE);
        south.add(auditBtn);
        card.add(south, BorderLayout.SOUTH);

        return card;
    }

    private JButton navBtn(String label, String panelKey) {
        JButton btn = new JButton(label);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(new Color(245, 250, 247));
        btn.setForeground(AppColors.DARK_GREEN);
        btn.setFocusPainted(false);
        btn.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(10, 12, 10, 12)
        ));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> mainFrame.showPanel(panelKey));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(220, 240, 230));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(245, 250, 247));
            }
        });
        return btn;
    }

    private JPanel buildAuditLog() {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 230), 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel title = new JLabel("Recent Activity Log");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        String[] cols = {"Time", "Actor", "Action", "Details"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        List<DataStore.AuditLog> logs = DataStore.getInstance().getAuditLogs();
        int max = Math.min(logs.size(), 20);
        for (int i = 0; i < max; i++) {
            DataStore.AuditLog log = logs.get(i);
            model.addRow(new Object[]{log.date, log.actor, log.action, log.details});
        }

        JTable table = new JTable(model);
        table.setFont(AppColors.SMALL_FONT);
        table.setRowHeight(26);
        table.setGridColor(new Color(235, 235, 240));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
        table.getColumnModel().getColumn(0).setPreferredWidth(120);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setPreferredWidth(110);
        table.getColumnModel().getColumn(3).setPreferredWidth(220);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);
        return card;
    }
}
