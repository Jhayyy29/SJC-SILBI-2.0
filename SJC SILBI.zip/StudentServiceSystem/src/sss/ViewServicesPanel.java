package sss;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

public class ViewServicesPanel extends JPanel {

    private final MainFrame mainFrame;

    private static final String[][] SERVICES = {
        {"📊", "Access Open Data",        "Browse publicly available school data, statistics, and reports."},
        {"⚠️", "File a Report",            "Submit incidents, bullying reports, or other concerns."},
        {"📄", "Online Document Request",  "Request TOR, certificates, and other official documents."},
        {"🔔", "Push Notifications",       "Receive real-time announcements and system alerts."},
        {"📅", "Appointment Booking",      "Schedule meetings with school offices and departments."},
        {"👤", "Student Profile",          "View and update your personal and academic information."},
        {"ℹ️", "Request for Information",  "Ask the school for specific information or clarifications."},
        {"🛠️", "Request a Service",        "Submit service requests for facilities, IT, or admin issues."},
        {"📈", "Real-time Request Status", "Track the live status of all your submitted requests."},
        {"📚", "Student Charter",          "Learn your rights and responsibilities as a student."},
        {"🏥", "Health Services",          "Access clinic schedules and health-related assistance."},
        {"💰", "Financial Assistance",     "Explore scholarship, grants, and payment options."},
    };

    public ViewServicesPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("⊞  All Services",
            "Complete list of available student services at SJC."), BorderLayout.NORTH);
        add(buildGrid(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JScrollPane buildGrid() {
        JPanel grid = new JPanel(new GridLayout(0, 3, 16, 16));
        grid.setBackground(AppColors.CREAM);
        grid.setBorder(new EmptyBorder(20, 20, 20, 20));

        for (String[] svc : SERVICES) {
            grid.add(buildServiceCard(svc[0], svc[1], svc[2]));
        }

        JScrollPane sp = new JScrollPane(grid);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        return sp;
    }

    private JPanel buildServiceCard(String icon, String name, String desc) {
        JPanel card = new JPanel(new BorderLayout(8, 8));
        card.setBackground(AppColors.CARD_BG);
        card.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        // Top: icon + name
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setBackground(AppColors.CARD_BG);
        JLabel ico = new JLabel(icon);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        JLabel nameLbl = new JLabel("<html><b>" + name + "</b></html>");
        nameLbl.setFont(AppColors.CARD_FONT);
        nameLbl.setForeground(AppColors.DARK_GREEN);
        top.add(ico);
        top.add(nameLbl);
        card.add(top, BorderLayout.NORTH);

        // Description
        JLabel descLbl = new JLabel("<html>" + desc + "</html>");
        descLbl.setFont(AppColors.SMALL_FONT);
        descLbl.setForeground(AppColors.TEXT_GRAY);
        card.add(descLbl, BorderLayout.CENTER);

        // Open button
        JButton openBtn = UIUtils.primaryButton("Open");
        openBtn.setPreferredSize(new Dimension(90, 30));
        openBtn.addActionListener(e -> navigate(name));
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        btnWrap.setBackground(AppColors.CARD_BG);
        btnWrap.add(openBtn);
        card.add(btnWrap, BorderLayout.SOUTH);

        return card;
    }

    private void navigate(String name) {
        switch (name) {
            case "Request a Service"       -> mainFrame.showPanel("servicerequest");
            case "Access Open Data"        -> mainFrame.showPanel("opendata");
            case "File a Report"           -> mainFrame.showPanel("report");
            case "Online Document Request" -> mainFrame.showPanel("docrequest");
            case "Push Notifications"      -> mainFrame.showPanel("notifications");
            case "Appointment Booking"     -> mainFrame.showPanel("appointment");
            case "Student Profile"         -> mainFrame.showPanel("profile");
            case "Request for Information" -> mainFrame.showPanel("inforequest");
            default -> JOptionPane.showMessageDialog(this,
                name + " module coming soon!", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
