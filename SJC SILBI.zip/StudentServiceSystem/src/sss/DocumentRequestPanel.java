package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class DocumentRequestPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;

    private JComboBox<String> docTypeBox, copiesBox;
    private JTextArea purposeArea;
    private JTextField recipientField;

    public DocumentRequestPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("📄  Online Document Request",
            "Request official school documents without visiting the office."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new GridLayout(1, 2, 16, 0));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));
        main.add(buildForm());
        main.add(buildHistory());
        return main;
    }

    private JPanel buildForm() {
        JPanel card = UIUtils.createCard("Request a Document");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        docTypeBox = UIUtils.styledCombo(new String[]{
            "Transcript of Records (TOR)",
            "Certificate of Enrollment",
            "Certificate of Graduation",
            "Good Moral Certificate",
            "Diploma Copy",
            "Form 137",
            "Student ID Replacement",
            "Other"
        });
        copiesBox = UIUtils.styledCombo(new String[]{"1", "2", "3", "4", "5"});
        purposeArea   = UIUtils.styledArea(4, 30);
        recipientField = UIUtils.styledField("e.g. scholarship, employment");

        fields.add(UIUtils.formRow("Document Type", docTypeBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("No. of Copies", copiesBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("For / Purpose", recipientField));
        fields.add(Box.createVerticalStrut(10));

        JLabel detLbl = new JLabel("Purpose Details");
        detLbl.setFont(AppColors.BODY_FONT);
        detLbl.setForeground(AppColors.TEXT_DARK);
        fields.add(detLbl);
        fields.add(Box.createVerticalStrut(4));

        JScrollPane detScroll = new JScrollPane(purposeArea);
        detScroll.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(detScroll);
        fields.add(Box.createVerticalStrut(16));

        // Notice
        JLabel notice = new JLabel("<html><i>Note: Documents are typically ready within 3–5 business days.</i></html>");
        notice.setFont(AppColors.SMALL_FONT);
        notice.setForeground(AppColors.TEXT_GRAY);
        fields.add(notice);
        fields.add(Box.createVerticalStrut(12));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(AppColors.CARD_BG);
        JButton clearBtn  = UIUtils.secondaryButton("Clear");
        JButton submitBtn = UIUtils.primaryButton("Submit Request");
        clearBtn.addActionListener(e -> clearForm());
        submitBtn.addActionListener(e -> submitRequest());
        btns.add(clearBtn);
        btns.add(submitBtn);
        fields.add(btns);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildHistory() {
        JPanel card = UIUtils.createCard("My Document Requests");

        String[] cols = {"ID", "Document Type", "Copies", "Purpose", "Status", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel) {
            @Override public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
                Component c = super.prepareRenderer(renderer, row, col);
                if (col == 4) {
                    JLabel badge = UIUtils.statusBadge((String) getValueAt(row, col));
                    badge.setHorizontalAlignment(SwingConstants.CENTER);
                    return badge;
                }
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(200);
        table.getColumnModel().getColumn(2).setPreferredWidth(50);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(120);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        JButton refreshBtn = UIUtils.secondaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadRequests());
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(AppColors.CARD_BG);
        btnRow.add(refreshBtn);
        card.add(btnRow, BorderLayout.SOUTH);

        loadRequests();
        return card;
    }

    private void loadRequests() {
        tableModel.setRowCount(0);
        for (DataStore.DocumentRequest dr : DataStore.getInstance().getDocRequests()) {
            tableModel.addRow(new Object[]{
                dr.id, dr.docType, dr.copies, dr.purpose, dr.status, dr.date
            });
        }
    }

    private void submitRequest() {
        String docType = (String) docTypeBox.getSelectedItem();
        String copies  = (String) copiesBox.getSelectedItem();
        String purpose = recipientField.getText().trim();
        String details = purposeArea.getText().trim();

        if (purpose.isEmpty()) { UIUtils.showError(this, "Please specify the purpose."); return; }

        String fullPurpose = purpose + (details.isEmpty() ? "" : " - " + details);
        DataStore.DocumentRequest dr = DataStore.getInstance().submitDocRequest(docType, fullPurpose, copies);
        UIUtils.showSuccess(this, "Request #" + dr.id + " submitted!\n" +
            "Document: " + docType + "\nEstimated release: 3–5 business days.");
        clearForm();
        loadRequests();
    }

    private void clearForm() {
        docTypeBox.setSelectedIndex(0);
        copiesBox.setSelectedIndex(0);
        recipientField.setText("");
        purposeArea.setText("");
    }

    private void styleTable(JTable table) {
        table.setFont(AppColors.BODY_FONT);
        table.setRowHeight(30);
        table.setGridColor(new Color(220, 215, 200));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
