package sss;

import java.awt.Color;
import java.awt.Font;

public class AppColors {
    // Primary palette matching the screenshots
    public static final Color DARK_GREEN   = new Color(27, 82, 60);
    public static final Color MEDIUM_GREEN = new Color(34, 139, 103);
    public static final Color LIGHT_GREEN  = new Color(56, 176, 130);
    public static final Color CREAM        = new Color(255, 248, 220);
    public static final Color CARD_BG      = new Color(255, 245, 210);
    public static final Color WHITE        = Color.WHITE;
    public static final Color TEXT_DARK    = Color.BLACK;
    public static final Color TEXT_GRAY    = new Color(100, 100, 100);
    public static final Color BORDER       = new Color(200, 190, 160);

    // Fonts
    public static final Font TITLE_FONT   = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font HEADER_FONT  = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font BODY_FONT    = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font SMALL_FONT   = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font BUTTON_FONT  = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font NAV_FONT     = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font CARD_FONT    = new Font("Segoe UI", Font.BOLD, 14);
}
