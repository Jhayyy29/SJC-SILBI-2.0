package sss;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.List;

public class NotificationsPanel extends JPanel {

    private final MainFrame mainFrame;
    private JPanel listPanel;
    private JTextField msgField;
    private JComboBox<String> sourceBox;

    public NotificationsPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("🔔  Push Notifications",
            "Stay updated with announcements and system alerts."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new GridLayout(1, 2, 16, 0));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));
        main.add(buildNotificationList());
        main.add(buildComposePanel());
        return main;
    }

    private JPanel buildNotificationList() {
        JPanel card = UIUtils.createCard("Notifications");

        // Mark all read button
        JButton markBtn = UIUtils.primaryButton("Mark All Read");
        markBtn.setPreferredSize(new Dimension(140, 32));
        markBtn.addActionListener(e -> {
            DataStore.getInstance().markAllRead();
            loadNotifications();
            mainFrame.refreshNav();
        });
        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        topRow.setBackground(AppColors.CARD_BG);
        topRow.add(markBtn);
        card.add(topRow, BorderLayout.SOUTH);

        listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(AppColors.CARD_BG);

        JScrollPane sp = new JScrollPane(listPanel);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        card.add(sp, BorderLayout.CENTER);

        loadNotifications();
        return card;
    }

    private void loadNotifications() {
        listPanel.removeAll();
        List<DataStore.Notification> notifs = DataStore.getInstance().getNotifications();
        if (notifs.isEmpty()) {
            JLabel empty = new JLabel("No notifications", SwingConstants.CENTER);
            empty.setFont(AppColors.BODY_FONT);
            empty.setForeground(AppColors.TEXT_GRAY);
            listPanel.add(empty);
        } else {
            for (DataStore.Notification n : notifs) {
                listPanel.add(buildNotifRow(n));
                listPanel.add(Box.createVerticalStrut(2));
            }
        }
        listPanel.revalidate();
        listPanel.repaint();
    }

    private JPanel buildNotifRow(DataStore.Notification n) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
        row.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 1, 0, AppColors.BORDER),
            new EmptyBorder(8, 8, 8, 8)
        ));

        Color bg = n.read ? AppColors.CARD_BG : new Color(230, 248, 240);
        row.setBackground(bg);

        // Icon
        String icon = switch (n.source) {
            case "RPT"  -> "⚠️";
            case "DOC"  -> "📄";
            case "APPT" -> "📅";
            case "INFO" -> "ℹ️";
            default     -> "🔔";
        };
        JLabel iconLbl = new JLabel(icon);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));
        iconLbl.setPreferredSize(new Dimension(36, 36));
        row.add(iconLbl, BorderLayout.WEST);

        // Text
        JPanel textPnl = new JPanel();
        textPnl.setLayout(new BoxLayout(textPnl, BoxLayout.Y_AXIS));
        textPnl.setBackground(bg);
        JLabel msg = new JLabel("<html>" + n.message + "</html>");
        msg.setFont(n.read ? AppColors.BODY_FONT : new Font("Segoe UI", Font.BOLD, 14));
        msg.setForeground(AppColors.TEXT_DARK);
        JLabel date = new JLabel(n.date);
        date.setFont(AppColors.SMALL_FONT);
        date.setForeground(AppColors.TEXT_GRAY);
        textPnl.add(msg);
        textPnl.add(date);
        row.add(textPnl, BorderLayout.CENTER);

        if (!n.read) {
            JLabel dot = new JLabel("●");
            dot.setForeground(AppColors.MEDIUM_GREEN);
            dot.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            row.add(dot, BorderLayout.EAST);
        }
        return row;
    }

    private JPanel buildComposePanel() {
        JPanel card = UIUtils.createCard("Send Announcement");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        sourceBox = UIUtils.styledCombo(new String[]{"SYS", "ADMIN", "FACULTY", "LIBRARY", "CLINIC"});
        msgField = UIUtils.styledField("Type your announcement...");

        fields.add(UIUtils.formRow("Source", sourceBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Message", msgField));
        fields.add(Box.createVerticalStrut(16));

        JButton sendBtn = UIUtils.primaryButton("Send Notification");
        sendBtn.setAlignmentX(CENTER_ALIGNMENT);
        sendBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        sendBtn.addActionListener(e -> sendNotification());
        fields.add(sendBtn);

        fields.add(Box.createVerticalStrut(24));
        // Stats
        JPanel stats = new JPanel(new GridLayout(2, 2, 8, 8));
        stats.setBackground(AppColors.CARD_BG);
        int total  = DataStore.getInstance().getNotifications().size();
        int unread = DataStore.getInstance().getUnreadCount();
        stats.add(statBox("Total", String.valueOf(total)));
        stats.add(statBox("Unread", String.valueOf(unread)));
        stats.add(statBox("System", "SYS"));
        stats.add(statBox("Types", "5"));
        fields.add(UIUtils.sectionTitle("Statistics"));
        fields.add(stats);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel statBox(String label, String val) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(new Color(240, 250, 244));
        p.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(10, 8, 10, 8)
        ));
        JLabel v = new JLabel(val, SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 22));
        v.setForeground(AppColors.DARK_GREEN);
        v.setAlignmentX(CENTER_ALIGNMENT);
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(AppColors.SMALL_FONT);
        l.setForeground(AppColors.TEXT_GRAY);
        l.setAlignmentX(CENTER_ALIGNMENT);
        p.add(v);
        p.add(l);
        return p;
    }

    private void sendNotification() {
        String src = (String) sourceBox.getSelectedItem();
        String msg = msgField.getText().trim();
        if (msg.isEmpty()) { UIUtils.showError(this, "Please enter a message."); return; }
        DataStore.getInstance().addNotification(src, msg);
        msgField.setText("");
        loadNotifications();
        mainFrame.refreshNav();
        UIUtils.showSuccess(this, "Notification sent!");
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
