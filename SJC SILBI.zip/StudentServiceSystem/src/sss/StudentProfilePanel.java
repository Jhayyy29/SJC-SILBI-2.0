package sss;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class StudentProfilePanel extends JPanel {

    private final MainFrame mainFrame;

    private JTextField fullNameField, emailField, sectionField, usernameField;
    private JLabel roleLabel;
    private JPasswordField currentPassField, newPassField, confirmPassField;

    public StudentProfilePanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("👤  Student Profile Management",
            "View and update your personal and academic information."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new GridLayout(1, 2, 16, 0));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));
        main.add(buildProfileCard());
        main.add(buildSecurityCard());
        return main;
    }

    private JPanel buildProfileCard() {
        JPanel card = UIUtils.createCard("Profile Information");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        DataStore.User user = DataStore.getInstance().getCurrentUser();
        String name    = user != null ? user.fullName  : "";
        String email   = user != null ? user.email     : "";
        String section = user != null ? user.section   : "";
        String uname   = user != null ? user.username  : "";
        String role    = user != null ? user.role      : "";

        // Avatar circle
        JPanel avatarWrap = new JPanel(new FlowLayout(FlowLayout.CENTER));
        avatarWrap.setBackground(AppColors.CARD_BG);
        JLabel avatar = new JLabel(getInitials(name), SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(AppColors.DARK_GREEN);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(AppColors.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 28));
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        avatar.setPreferredSize(new Dimension(80, 80));
        avatar.setOpaque(false);
        avatarWrap.add(avatar);
        fields.add(avatarWrap);
        fields.add(Box.createVerticalStrut(8));

        roleLabel = new JLabel(role, SwingConstants.CENTER);
        roleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        roleLabel.setForeground(AppColors.MEDIUM_GREEN);
        roleLabel.setAlignmentX(CENTER_ALIGNMENT);
        fields.add(roleLabel);
        fields.add(Box.createVerticalStrut(16));

        usernameField = UIUtils.styledField("");
        usernameField.setText(uname);
        usernameField.setEditable(false);
        usernameField.setBackground(new Color(245, 245, 245));

        fullNameField  = UIUtils.styledField("Full Name");
        emailField     = UIUtils.styledField("Email");
        sectionField   = UIUtils.styledField("Section");

        fullNameField.setText(name);
        emailField.setText(email);
        sectionField.setText(section);

        fields.add(UIUtils.formRow("Username (readonly)", usernameField));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Full Name", fullNameField));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Email Address", emailField));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Section", sectionField));
        fields.add(Box.createVerticalStrut(16));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(AppColors.CARD_BG);
        JButton resetBtn  = UIUtils.secondaryButton("Reset");
        JButton saveBtn   = UIUtils.primaryButton("Save Changes");
        resetBtn.addActionListener(e -> loadProfile());
        saveBtn.addActionListener(e -> saveProfile());
        btns.add(resetBtn);
        btns.add(saveBtn);
        fields.add(btns);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildSecurityCard() {
        JPanel card = UIUtils.createCard("Security & Account");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        currentPassField = UIUtils.styledPassword("Current Password");
        newPassField     = UIUtils.styledPassword("New Password (min 6 chars)");
        confirmPassField = UIUtils.styledPassword("Confirm New Password");

        fields.add(UIUtils.sectionTitle("Change Password"));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Current Password", currentPassField));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("New Password", newPassField));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Confirm Password", confirmPassField));
        fields.add(Box.createVerticalStrut(16));

        JButton changePassBtn = UIUtils.primaryButton("Change Password");
        changePassBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        changePassBtn.setAlignmentX(CENTER_ALIGNMENT);
        changePassBtn.addActionListener(e -> changePassword());
        fields.add(changePassBtn);

        fields.add(Box.createVerticalStrut(32));
        fields.add(new JSeparator());
        fields.add(Box.createVerticalStrut(16));

        // Account summary
        fields.add(UIUtils.sectionTitle("Account Summary"));
        fields.add(Box.createVerticalStrut(8));
        DataStore ds = DataStore.getInstance();
        fields.add(summaryRow("Reports Submitted",      String.valueOf(ds.getReports().size())));
        fields.add(Box.createVerticalStrut(6));
        fields.add(summaryRow("Document Requests",      String.valueOf(ds.getDocRequests().size())));
        fields.add(Box.createVerticalStrut(6));
        fields.add(summaryRow("Appointments Booked",    String.valueOf(ds.getAppointments().size())));
        fields.add(Box.createVerticalStrut(6));
        fields.add(summaryRow("Info Requests",          String.valueOf(ds.getInfoRequests().size())));
        fields.add(Box.createVerticalStrut(24));

        JButton logoutBtn = UIUtils.secondaryButton("Logout");
        logoutBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        logoutBtn.setAlignmentX(CENTER_ALIGNMENT);
        logoutBtn.addActionListener(e -> {
            DataStore.getInstance().logout();
            mainFrame.showLogin();
        });
        fields.add(logoutBtn);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel summaryRow(String label, String value) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(AppColors.CARD_BG);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel lbl = new JLabel(label);
        lbl.setFont(AppColors.BODY_FONT);
        lbl.setForeground(AppColors.TEXT_DARK);
        JLabel val = new JLabel(value);
        val.setFont(new Font("Segoe UI", Font.BOLD, 14));
        val.setForeground(AppColors.DARK_GREEN);
        row.add(lbl, BorderLayout.WEST);
        row.add(val, BorderLayout.EAST);
        return row;
    }

    private void loadProfile() {
        DataStore.User user = DataStore.getInstance().getCurrentUser();
        if (user == null) return;
        fullNameField.setText(user.fullName);
        emailField.setText(user.email);
        sectionField.setText(user.section);
    }

    private void saveProfile() {
        String name    = fullNameField.getText().trim();
        String email   = emailField.getText().trim();
        String section = sectionField.getText().trim();
        if (name.isEmpty() || email.isEmpty()) {
            UIUtils.showError(this, "Name and email are required.");
            return;
        }
        DataStore.getInstance().updateProfile(name, email, section);
        UIUtils.showSuccess(this, "Profile updated successfully!");
        mainFrame.refreshNav();
    }

    private void changePassword() {
        String curr = new String(currentPassField.getPassword());
        String nw   = new String(newPassField.getPassword());
        String conf = new String(confirmPassField.getPassword());
        DataStore.User user = DataStore.getInstance().getCurrentUser();
        if (user == null) return;
        if (!user.password.equals(curr)) {
            UIUtils.showError(this, "Current password is incorrect.");
            return;
        }
        if (nw.length() < 6) {
            UIUtils.showError(this, "New password must be at least 6 characters.");
            return;
        }
        if (!nw.equals(conf)) {
            UIUtils.showError(this, "Passwords do not match.");
            return;
        }
        user.password = nw;
        currentPassField.setText("");
        newPassField.setText("");
        confirmPassField.setText("");
        UIUtils.showSuccess(this, "Password changed successfully!");
    }

    private String getInitials(String name) {
        if (name == null || name.isEmpty()) return "?";
        String[] parts = name.trim().split(" ");
        if (parts.length >= 2) return ("" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
        return String.valueOf(parts[0].charAt(0)).toUpperCase();
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
