package sss;

/**
 * Central configuration for the email notification system.
 *
 * SETUP REQUIRED:
 *  1. Go to https://myaccount.google.com/apppasswords
 *  2. Create an "App Password" for "Mail" on "Windows Computer"
 *  3. Paste the 16-character app password into ADMIN_APP_PASSWORD below.
 *     (Do NOT use your regular Gmail login password here.)
 */
public class EmailConfig {

    // ── Admin / sender account ─────────────────────────────────────────────
    public static final String ADMIN_EMAIL       = "ivannadmin@gmail.com";

    /**
     * Gmail App Password (16 chars, no spaces).
     * Replace "your-app-password-here" with the actual value.
     * Example: "abcd efgh ijkl mnop"  →  "abcdefghijklmnop"
     */
    public static final String ADMIN_APP_PASSWORD = "ivanadmin123!";

    // ── Default student email used when a record has no registered email ───
    public static final String FALLBACK_STUDENT_EMAIL = "ivje.guevarra.sjc@phinmaed.com";

    // ── Gmail SMTP settings (do not change) ───────────────────────────────
    public static final String SMTP_HOST = "smtp.gmail.com";
    public static final int    SMTP_PORT = 465;          // SSL port

    // ── School branding in emails ─────────────────────────────────────────
    public static final String SCHOOL_NAME   = "SJC — Student Service System";
    public static final String SCHOOL_FOOTER = "PHINMA Saint Jude College";

    /** Returns true when the app password has been configured. */
    public static boolean isConfigured() {
        return !ADMIN_APP_PASSWORD.equals("ivanadmin123!")
            && !ADMIN_APP_PASSWORD.isBlank();
    }
}
