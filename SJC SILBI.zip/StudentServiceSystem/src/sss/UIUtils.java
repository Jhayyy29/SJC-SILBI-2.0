package sss;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class UIUtils {

    /** Rounded panel with shadow-like border */
    public static JPanel createCard(String title) {
        JPanel card = new JPanel(new BorderLayout(8, 8));
        card.setBackground(AppColors.CARD_BG);
        card.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));
        if (title != null && !title.isEmpty()) {
            JLabel lbl = new JLabel(title);
            lbl.setFont(AppColors.HEADER_FONT);
            lbl.setForeground(AppColors.DARK_GREEN);
            lbl.setBorder(new EmptyBorder(0, 0, 8, 0));
            card.add(lbl, BorderLayout.NORTH);
        }
        return card;
    }

    /** Green primary button */
    public static JButton primaryButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? AppColors.DARK_GREEN :
                            getModel().isRollover() ? AppColors.LIGHT_GREEN : AppColors.MEDIUM_GREEN);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.setColor(AppColors.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.setFont(getFont());
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        btn.setFont(AppColors.BUTTON_FONT);
        btn.setForeground(AppColors.WHITE);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 36));
        return btn;
    }

    /** Outlined secondary button */
    public static JButton secondaryButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(230, 245, 238) : AppColors.WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.setColor(AppColors.MEDIUM_GREEN);
                g2.setStroke(new BasicStroke(2f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth() - 2, getHeight() - 2, 10, 10));
                g2.setColor(AppColors.DARK_GREEN);
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.setFont(getFont());
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        btn.setFont(AppColors.BUTTON_FONT);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 36));
        return btn;
    }

    /** Service tile button used on the dashboard grid */
    public static JButton serviceTile(String icon, String label) {
        JButton btn = new JButton("<html><center>" + icon + "<br><b>" + label + "</b></center></html>") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isRollover() ? new Color(240, 250, 244) : AppColors.CARD_BG;
                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18));
                g2.setColor(AppColors.BORDER);
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth() - 2, getHeight() - 2, 18, 18));
                super.paintComponent(g);
                g2.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(AppColors.TEXT_DARK);
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Styled text field */
    public static JTextField styledField(String placeholder) {
        JTextField f = new JTextField();
        f.setFont(AppColors.BODY_FONT);
        f.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(5, 7, 5, 7)
        ));
        f.setToolTipText(placeholder);
        return f;
    }

    /** Styled password field */
    public static JPasswordField styledPassword(String placeholder) {
        JPasswordField f = new JPasswordField();
        f.setFont(AppColors.BODY_FONT);
        f.setBorder(new CompoundBorder(
            new LineBorder(AppColors.BORDER, 1, true),
            new EmptyBorder(6, 10, 6, 10)
        ));
        f.setToolTipText(placeholder);
        return f;
    }

    /** Styled combo box */
    public static JComboBox<String> styledCombo(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(AppColors.BODY_FONT);
        cb.setBackground(AppColors.WHITE);
        return cb;
    }

    /** Styled text area */
    public static JTextArea styledArea(int rows, int cols) {
        JTextArea ta = new JTextArea(rows, cols);
        ta.setFont(AppColors.BODY_FONT);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBorder(new EmptyBorder(6, 10, 6, 10));
        return ta;
    }

    /** Label form row */
    public static JPanel formRow(String labelText, JComponent field) {
        JPanel row = new JPanel(new BorderLayout(8, 4));
        row.setOpaque(false);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(AppColors.BODY_FONT);
        lbl.setForeground(AppColors.TEXT_DARK);
        lbl.setPreferredSize(new Dimension(160, 24));
        row.add(lbl, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        return row;
    }

    /** Status badge */
    public static JLabel statusBadge(String status) {
        JLabel lbl = new JLabel(status, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lbl.setOpaque(true);
        lbl.setBorder(new EmptyBorder(3, 10, 3, 10));
        switch (status.toLowerCase()) {
            case "pending"   -> { lbl.setBackground(new Color(255, 243, 205)); lbl.setForeground(new Color(133, 100, 4)); }
            case "confirmed" -> { lbl.setBackground(new Color(209, 236, 241)); lbl.setForeground(new Color(12, 84, 96)); }
            case "completed" -> { lbl.setBackground(new Color(212, 237, 218)); lbl.setForeground(new Color(21, 87, 36)); }
            case "cancelled" -> { lbl.setBackground(new Color(248, 215, 218)); lbl.setForeground(new Color(114, 28, 36)); }
            default          -> { lbl.setBackground(new Color(226, 227, 229)); lbl.setForeground(new Color(73, 80, 87)); }
        }
        return lbl;
    }

    /** Show success dialog */
    public static void showSuccess(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Show error dialog */
    public static void showError(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /** Section title label */
    public static JLabel sectionTitle(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(AppColors.HEADER_FONT);
        lbl.setForeground(AppColors.DARK_GREEN);
        lbl.setBorder(new EmptyBorder(0, 0, 8, 0));
        return lbl;
    }

    /** Top page header bar */
    public static JPanel pageHeader(String title, String subtitle) {
        JPanel hdr = new JPanel();
        hdr.setLayout(new BoxLayout(hdr, BoxLayout.Y_AXIS));
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(20, 24, 20, 24));
        JLabel t = new JLabel(title);
        t.setFont(AppColors.TITLE_FONT);
        t.setForeground(AppColors.WHITE);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        hdr.add(t);
        if (subtitle != null && !subtitle.isEmpty()) {
            JLabel s = new JLabel(subtitle);
            s.setFont(AppColors.BODY_FONT);
            s.setForeground(new Color(180, 220, 200));
            s.setAlignmentX(Component.LEFT_ALIGNMENT);
            hdr.add(Box.createVerticalStrut(4));
            hdr.add(s);
        }
        return hdr;
    }
}
