package sss;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class UserManagementPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTable table;

    // Form fields
    private JTextField fUsername, fFullName, fEmail, fSection, fPassword;
    private JComboBox<String> fRole;
    private JCheckBox fActive;
    private JLabel formTitle;
    private boolean editMode = false;
    private String editingUsername = null;

    public UserManagementPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel t = new JLabel("👥  User Management");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        hdr.add(t, BorderLayout.WEST);
        JButton back = UIUtils.secondaryButton("← Dashboard");
        back.addActionListener(e -> mainFrame.showPanel("admin_dashboard"));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(AppColors.DARK_GREEN);
        right.add(back);
        hdr.add(right, BorderLayout.EAST);
        return hdr;
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new GridLayout(1, 2, 16, 0));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(16, 20, 16, 20));
        body.add(buildTablePanel());
        body.add(buildFormPanel());
        return body;
    }

    // ── User Table ─────────────────────────────────────────────────────────
    private JPanel buildTablePanel() {
        JPanel card = whiteCard();
        card.setLayout(new BorderLayout(0, 8));

        JLabel t = new JLabel("All Accounts");
        t.setFont(new Font("Segoe UI", Font.BOLD, 16));
        t.setForeground(AppColors.DARK_GREEN);
        card.add(t, BorderLayout.NORTH);

        String[] cols = {"Username", "Full Name", "Role", "Section", "Email", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (col == 5) {
                    String val = (String) getValueAt(row, col);
                    JLabel lbl = UIUtils.statusBadge(val);
                    lbl.setHorizontalAlignment(SwingConstants.CENTER);
                    return lbl;
                }
                if (!isRowSelected(row))
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(90);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(110);
        table.getColumnModel().getColumn(3).setPreferredWidth(90);
        table.getColumnModel().getColumn(4).setPreferredWidth(170);
        table.getColumnModel().getColumn(5).setPreferredWidth(70);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadSelectedToForm();
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        // Bottom action buttons
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        btns.setBackground(Color.WHITE);
        JButton newBtn    = UIUtils.primaryButton("+ New User");
        JButton deleteBtn = UIUtils.secondaryButton("Delete");
        JButton resetBtn  = UIUtils.secondaryButton("Reset Password");
        newBtn.addActionListener(e -> clearForm(false));
        deleteBtn.addActionListener(e -> deleteSelected());
        resetBtn.addActionListener(e -> resetSelectedPassword());
        btns.add(newBtn); btns.add(deleteBtn); btns.add(resetBtn);
        card.add(btns, BorderLayout.SOUTH);

        loadTable();
        return card;
    }

    // ── Form Panel ─────────────────────────────────────────────────────────
    private JPanel buildFormPanel() {
        JPanel card = whiteCard();
        card.setLayout(new BorderLayout(0, 12));

        formTitle = new JLabel("Add New User");
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        formTitle.setForeground(AppColors.DARK_GREEN);
        card.add(formTitle, BorderLayout.NORTH);

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(Color.WHITE);

        fUsername = UIUtils.styledField("username");
        fFullName = UIUtils.styledField("Full Name");
        fEmail    = UIUtils.styledField("email@sjc.edu");
        fPassword = UIUtils.styledField("Password (leave blank to keep)");
        fSection  = UIUtils.styledField("e.g. BSCS-2A or N/A");
        fRole     = UIUtils.styledCombo(new String[]{"Student","Faculty","Staff","Administrator"});
        fActive   = new JCheckBox("Account Active");
        fActive.setBackground(Color.WHITE);
        fActive.setFont(AppColors.BODY_FONT);
        fActive.setSelected(true);

        fields.add(UIUtils.formRow("Username *",   fUsername));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Full Name *",  fFullName));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Email *",      fEmail));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Role",         fRole));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Section",      fSection));
        fields.add(Box.createVerticalStrut(8));
        fields.add(UIUtils.formRow("Password",     fPassword));
        fields.add(Box.createVerticalStrut(8));
        fields.add(fActive);
        fields.add(Box.createVerticalStrut(20));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(Color.WHITE);
        JButton cancelBtn = UIUtils.secondaryButton("Cancel");
        JButton saveBtn   = UIUtils.primaryButton("Save");
        cancelBtn.addActionListener(e -> clearForm(false));
        saveBtn.addActionListener(e -> saveUser());
        btns.add(cancelBtn); btns.add(saveBtn);
        fields.add(btns);

        card.add(fields, BorderLayout.CENTER);

        // Summary stats
        JPanel stats = new JPanel(new GridLayout(2, 3, 8, 8));
        stats.setBackground(Color.WHITE);
        stats.setBorder(new CompoundBorder(
            new MatteBorder(1, 0, 0, 0, AppColors.BORDER),
            new EmptyBorder(12, 0, 0, 0)
        ));
        DataStore ds = DataStore.getInstance();
        List<DataStore.User> all = ds.getAllUsers();
        long students = all.stream().filter(u -> "Student".equals(u.role)).count();
        long faculty  = all.stream().filter(u -> "Faculty".equals(u.role)).count();
        long staff    = all.stream().filter(u -> "Staff".equals(u.role)).count();
        long admins   = all.stream().filter(u -> "Administrator".equals(u.role)).count();
        long active   = all.stream().filter(u -> u.active).count();
        stats.add(miniStat("Students",  String.valueOf(students),  new Color(52,152,219)));
        stats.add(miniStat("Faculty",   String.valueOf(faculty),   AppColors.MEDIUM_GREEN));
        stats.add(miniStat("Staff",     String.valueOf(staff),     new Color(142,68,173)));
        stats.add(miniStat("Admins",    String.valueOf(admins),    new Color(231,76,60)));
        stats.add(miniStat("Active",    String.valueOf(active),    new Color(39,174,96)));
        stats.add(miniStat("Total",     String.valueOf(all.size()),AppColors.DARK_GREEN));
        card.add(stats, BorderLayout.SOUTH);

        return card;
    }

    private JPanel miniStat(String label, String val, Color color) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(new Color(248, 250, 252));
        p.setBorder(new CompoundBorder(
            new LineBorder(new Color(220,220,230), 1, true),
            new EmptyBorder(8, 6, 8, 6)
        ));
        JLabel v = new JLabel(val, SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 20));
        v.setForeground(color);
        v.setAlignmentX(CENTER_ALIGNMENT);
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(AppColors.SMALL_FONT);
        l.setForeground(AppColors.TEXT_GRAY);
        l.setAlignmentX(CENTER_ALIGNMENT);
        p.add(v); p.add(l);
        return p;
    }

    // ── Data operations ────────────────────────────────────────────────────
    private void loadTable() {
        tableModel.setRowCount(0);
        for (DataStore.User u : DataStore.getInstance().getAllUsers()) {
            tableModel.addRow(new Object[]{
                u.username, u.fullName, u.role, u.section, u.email,
                u.active ? "Active" : "Inactive"
            });
        }
    }

    private void loadSelectedToForm() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String uname = (String) tableModel.getValueAt(row, 0);
        for (DataStore.User u : DataStore.getInstance().getAllUsers()) {
            if (u.username.equals(uname)) {
                editMode = true;
                editingUsername = uname;
                formTitle.setText("Edit User: " + uname);
                fUsername.setText(u.username);
                fUsername.setEditable(false);
                fFullName.setText(u.fullName);
                fEmail.setText(u.email);
                fSection.setText(u.section);
                fPassword.setText("");
                fActive.setSelected(u.active);
                // set role combo
                for (int i = 0; i < fRole.getItemCount(); i++) {
                    if (fRole.getItemAt(i).equals(u.role)) { fRole.setSelectedIndex(i); break; }
                }
                return;
            }
        }
    }

    private void clearForm(boolean keepEdit) {
        if (!keepEdit) {
            editMode = false;
            editingUsername = null;
            formTitle.setText("Add New User");
            fUsername.setEditable(true);
        }
        fUsername.setText(""); fFullName.setText(""); fEmail.setText("");
        fSection.setText(""); fPassword.setText("");
        fRole.setSelectedIndex(0); fActive.setSelected(true);
        table.clearSelection();
    }

    private void saveUser() {
        String uname   = fUsername.getText().trim();
        String full    = fFullName.getText().trim();
        String email   = fEmail.getText().trim();
        String section = fSection.getText().trim();
        String role    = (String) fRole.getSelectedItem();
        String pass    = fPassword.getText().trim();
        boolean active = fActive.isSelected();

        if (uname.isEmpty() || full.isEmpty() || email.isEmpty()) {
            UIUtils.showError(this, "Username, Full Name, and Email are required."); return;
        }
        DataStore ds = DataStore.getInstance();
        if (editMode) {
            if (!pass.isEmpty()) ds.adminResetPassword(uname, pass);
            ds.adminUpdateUser(uname, full, email, role, section, active);
            UIUtils.showSuccess(this, "User '" + uname + "' updated.");
        } else {
            if (pass.isEmpty()) { UIUtils.showError(this, "Password is required for new users."); return; }
            if (!ds.adminAddUser(uname, pass, full, email, role, section)) {
                UIUtils.showError(this, "Username already exists."); return;
            }
            UIUtils.showSuccess(this, "User '" + uname + "' created.");
        }
        clearForm(false);
        loadTable();
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtils.showError(this, "Select a user first."); return; }
        String uname = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete user '" + uname + "'? This cannot be undone.", "Confirm Delete",
            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            if (DataStore.getInstance().adminDeleteUser(uname)) {
                UIUtils.showSuccess(this, "User deleted.");
                clearForm(false); loadTable();
            } else {
                UIUtils.showError(this, "Cannot delete your own account.");
            }
        }
    }

    private void resetSelectedPassword() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtils.showError(this, "Select a user first."); return; }
        String uname = (String) tableModel.getValueAt(row, 0);
        String newPass = JOptionPane.showInputDialog(this,
            "Enter new password for '" + uname + "':", "Reset Password", JOptionPane.PLAIN_MESSAGE);
        if (newPass != null && !newPass.trim().isEmpty()) {
            if (newPass.trim().length() < 6) { UIUtils.showError(this, "Password must be 6+ characters."); return; }
            DataStore.getInstance().adminResetPassword(uname, newPass.trim());
            UIUtils.showSuccess(this, "Password reset for '" + uname + "'.");
        }
    }

    private void styleTable(JTable t) {
        t.setFont(AppColors.BODY_FONT);
        t.setRowHeight(30);
        t.setGridColor(new Color(235, 235, 240));
        t.setSelectionBackground(new Color(200, 235, 215));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.getTableHeader().setBackground(AppColors.DARK_GREEN);
        t.getTableHeader().setForeground(Color.BLACK);
        t.setShowGrid(true);
    }

    private JPanel whiteCard() {
        JPanel p = new JPanel();
        p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 230), 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));
        return p;
    }
}
