package sss;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

/**
 * StudentSync-style Login/Register panel for StudentServiceSystem.
 *
 * Layout mirrors the StudentSync design:
 *   REGISTER screen  →  branding LEFT  |  form RIGHT
 *   LOGIN    screen  →  form LEFT      |  branding RIGHT
 */
public class LoginPanel extends JPanel {

    private static final Color BG_DARK    = new Color(0x1B523C); // dark green
    private static final Color BG_CREAM   = new Color(0xF5F0E8);
    private static final Color FIELD_BG   = new Color(0x163D2D); // deeper green
    private static final Color TEXT_CREAM = new Color(0xF5F0E8);
    private static final Color TEXT_DARK  = new Color(0x1B523C); // dark green
    private static final Color SUCCESS    = new Color(0x2ECC71);
    private static final Color DANGER     = new Color(0xE74C3C);

    private final MainFrame mainFrame;
    private java.awt.image.BufferedImage bgImage;

    // Which screen is visible
    private final CardLayout screenLayout = new CardLayout();
    private final JPanel     screenCards  = new JPanel(screenLayout);

    private static final String SCREEN_LOGIN    = "login";
    private static final String SCREEN_REGISTER = "register";

    // ── Login fields ──────────────────────────────────────────────────────
    private JTextField    loginUser;
    private JPasswordField loginPass;

    // ── Register fields ───────────────────────────────────────────────────
    private JTextField    regFull, regUser, regEmail, regSection;
    private JPasswordField regPass, regPass2;
    private JComboBox<String> regRole;
    private boolean       faceCaptured = false;
    private JLabel        faceStatus;

    // ── Face data ─────────────────────────────────────────────────────────
    private static final String FACE_DIR = "face_data";

    public LoginPanel(MainFrame frame) {
        this.mainFrame = frame;

        // Load background image
        try {
            java.io.InputStream is = getClass().getResourceAsStream("/sss/assets/sjc_bg.jpg");
            if (is != null) bgImage = javax.imageio.ImageIO.read(is);
        } catch (Exception ignored) {}

        setLayout(new BorderLayout());
        setOpaque(false);

        screenCards.setOpaque(false);
        screenCards.add(buildLoginScreen(),    SCREEN_LOGIN);
        screenCards.add(buildRegisterScreen(), SCREEN_REGISTER);

        add(screenCards, BorderLayout.CENTER);
        screenLayout.show(screenCards, SCREEN_LOGIN);

        // Ensure face_data directory exists
        try { Files.createDirectories(Paths.get(FACE_DIR)); }
        catch (IOException ignored) {}
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        if (bgImage != null) {
            g2.drawImage(bgImage, 0, 0, getWidth(), getHeight(), null);
            // 50% dark green overlay
            g2.setComposite(java.awt.AlphaComposite.getInstance(
                    java.awt.AlphaComposite.SRC_OVER, 0.50f));
            g2.setColor(BG_DARK);
            g2.fillRect(0, 0, getWidth(), getHeight());
        } else {
            g2.setColor(BG_DARK);
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
        g2.dispose();
    }

    // ==================================================================
    //  LOGIN SCREEN  —  form LEFT  |  branding RIGHT
    // ==================================================================
    private JPanel buildLoginScreen() {
        JPanel screen = new JPanel(new BorderLayout());
        screen.setOpaque(false);

        // ── Left: form panel ─────────────────────────────────────────────
        JPanel left = new JPanel(new BorderLayout());
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(440, 0));

        JLabel title = new JLabel("Login");
        title.setFont(new Font("Georgia", Font.BOLD, 28));
        title.setForeground(Color.BLACK);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        title.setBorder(new EmptyBorder(30, 0, 10, 0));
        left.add(title, BorderLayout.NORTH);

        left.add(wrapCard(buildLoginCard()), BorderLayout.CENTER);

        // ── Right: branding ──────────────────────────────────────────────
        JPanel right = buildBrandingPanel(
                "Already have\nan account?", "Register",
                () -> screenLayout.show(screenCards, SCREEN_REGISTER),
                false);

        screen.add(left,  BorderLayout.WEST);
        screen.add(right, BorderLayout.CENTER);
        return screen;
    }

    private JPanel buildLoginCard() {
        JPanel card = roundedCard(BG_CREAM, 20);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(24, 24, 24, 24));

        loginUser = darkField("Username", false);
        loginPass = (JPasswordField) darkField("Password", true);

        card.add(fieldWrapper(loginUser, "\uD83D\uDC64"));
        card.add(Box.createVerticalStrut(12));
        card.add(fieldWrapper(loginPass, "\uD83D\uDD12"));
        card.add(Box.createVerticalStrut(8));

        // Face login row
        card.add(buildFaceLoginRow());
        card.add(Box.createVerticalStrut(8));

        // Forgot password
        JLabel forgot = new JLabel("Forgot Password?");
        forgot.setFont(new Font("SansSerif", Font.PLAIN, 12));
        forgot.setForeground(TEXT_DARK);
        forgot.setAlignmentX(CENTER_ALIGNMENT);
        forgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        forgot.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showForgotPasswordDialog(); }
        });
        card.add(forgot);
        card.add(Box.createVerticalStrut(14));

        // Login button
        JButton loginBtn = primaryButton("Login");
        loginBtn.addActionListener(e -> doLogin());
        card.add(loginBtn);
        card.add(Box.createVerticalStrut(14));


        return card;
    }

    private JPanel buildFaceLoginRow() {
        JPanel row = roundedCard(new Color(0x163D2D), 12);
        row.setLayout(new BorderLayout(8, 0));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        row.setPreferredSize(new Dimension(0, 48));
        row.setBorder(new EmptyBorder(6, 14, 6, 14));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        left.setOpaque(false);
        JLabel ico  = new JLabel("\uD83D\uDC41");
        ico.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JLabel txt  = new JLabel("Login with Face");
        txt.setFont(new Font("SansSerif", Font.BOLD, 13));
        txt.setForeground(TEXT_CREAM);
        left.add(ico); left.add(txt);

        JLabel hint = new JLabel("Tap to scan");
        hint.setFont(new Font("SansSerif", Font.PLAIN, 11));
        hint.setForeground(new Color(0xAAAACC));

        row.add(left, BorderLayout.CENTER);
        row.add(hint, BorderLayout.EAST);
        row.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        row.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                String username = loginUser.getText().trim();
                if (username.isEmpty() || username.equals("Username")) {
                    JOptionPane.showMessageDialog(LoginPanel.this,
                        "Enter your username first.", "Required",
                        JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                if (!hasFaceData(username)) {
                    JOptionPane.showMessageDialog(LoginPanel.this,
                        "No face data registered for \"" + username + "\".\n"
                        + "Please register your face during registration.",
                        "Face Not Found", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                boolean ok = showFaceVerifyDialog(username);
                if (ok) {
                    // Face verified — attempt password-less login by
                    // checking if user exists in DataStore
                    DataStore ds = DataStore.getInstance();
                    DataStore.User found = null;
                    for (DataStore.User u : ds.getAllUsers()) {
                        if (u.username.equalsIgnoreCase(username)) { found = u; break; }
                    }
                    if (found != null) {
                        ds.loginDirect(found.username);
                        mainFrame.showDashboard();
                    } else {
                        JOptionPane.showMessageDialog(LoginPanel.this,
                            "User not found. Please register first.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
            @Override public void mouseEntered(MouseEvent e) { hint.setText("Click to scan \u25B6"); }
            @Override public void mouseExited(MouseEvent e)  { hint.setText("Tap to scan"); }
        });
        return row;
    }

    // ==================================================================
    //  REGISTER SCREEN  —  branding LEFT  |  form RIGHT
    // ==================================================================
    private JPanel buildRegisterScreen() {
        JPanel screen = new JPanel(new BorderLayout());
        screen.setOpaque(false);

        // ── Left: branding ───────────────────────────────────────────────
        JPanel left = buildBrandingPanel(
                "Already have\nan account?", "Login",
                () -> screenLayout.show(screenCards, SCREEN_LOGIN),
                true);

        // ── Right: form panel ────────────────────────────────────────────
        JPanel right = new JPanel(new BorderLayout());
        right.setOpaque(false);
        right.setPreferredSize(new Dimension(440, 0));

        JLabel title = new JLabel("Registration");
        title.setFont(new Font("Georgia", Font.BOLD, 28));
        title.setForeground(Color.BLACK);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        title.setBorder(new EmptyBorder(30, 0, 10, 0));
        right.add(title, BorderLayout.NORTH);

        right.add(wrapCard(buildRegisterCard()), BorderLayout.CENTER);

        screen.add(left,  BorderLayout.CENTER);
        screen.add(right, BorderLayout.EAST);
        return screen;
    }

    private JPanel buildRegisterCard() {
        JPanel card = roundedCard(BG_CREAM, 20);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(18, 22, 18, 22));

        regFull    = darkField("Full Name",         false);
        regUser    = darkField("Username",           false);
        regEmail   = darkField("Email Address",      false);
        regSection = darkField("Section",            false);
        regPass    = (JPasswordField) darkField("Password",         true);
        regPass2   = (JPasswordField) darkField("Confirm Password", true);
        regRole    = new JComboBox<>(new String[]{"Student"});
        styleCombo(regRole);

        card.add(fieldWrapper(regFull,    "\uD83D\uDC64")); card.add(Box.createVerticalStrut(9));
        card.add(fieldWrapper(regUser,    "@"));             card.add(Box.createVerticalStrut(9));
        card.add(fieldWrapper(regEmail,   "\u2709"));        card.add(Box.createVerticalStrut(9));
        card.add(comboWrapper(regRole,    "Role"));          card.add(Box.createVerticalStrut(9));
        card.add(fieldWrapper(regSection, "\uD83C\uDFEB")); card.add(Box.createVerticalStrut(9));
        card.add(fieldWrapper(regPass,    "\uD83D\uDD12")); card.add(Box.createVerticalStrut(9));
        card.add(fieldWrapper(regPass2,   "\uD83D\uDD12")); card.add(Box.createVerticalStrut(10));

        // Face capture row
        card.add(buildFaceCaptureRow());
        card.add(Box.createVerticalStrut(12));

        // Register button
        JButton regBtn = primaryButton("Register");
        regBtn.addActionListener(e -> doRegister());
        card.add(regBtn);
        card.add(Box.createVerticalStrut(10));



        return card;
    }

    private JPanel buildFaceCaptureRow() {
        JPanel row = roundedCard(new Color(0xE8E4DC), 12);
        row.setLayout(new BorderLayout(8, 0));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        row.setPreferredSize(new Dimension(0, 48));
        row.setBorder(new EmptyBorder(6, 12, 6, 12));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        left.setOpaque(false);
        JLabel ico  = new JLabel("\uD83D\uDCF7");
        ico.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JLabel txt  = new JLabel("Register Face");
        txt.setFont(new Font("SansSerif", Font.BOLD, 13));
        txt.setForeground(TEXT_DARK);
        left.add(ico); left.add(txt);

        faceStatus = new JLabel("Not captured");
        faceStatus.setFont(new Font("SansSerif", Font.PLAIN, 11));
        faceStatus.setForeground(new Color(0x999980));

        row.add(left,       BorderLayout.CENTER);
        row.add(faceStatus, BorderLayout.EAST);
        row.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        row.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                String username = regUser.getText().trim();
                if (username.isEmpty() || username.equals("Username")) {
                    JOptionPane.showMessageDialog(LoginPanel.this,
                        "Enter a username first.", "Required",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
                boolean ok = showFaceCaptureDialog(username);
                if (ok) {
                    faceCaptured = true;
                    faceStatus.setText("\u2705 Face registered");
                    faceStatus.setForeground(SUCCESS);
                    row.repaint();
                }
            }
        });
        return row;
    }

    // ==================================================================
    //  BRANDING PANEL (StudentSync-style circle arc + title + button)
    // ==================================================================
    private JPanel buildBrandingPanel(String subText, String btnText,
                                       Runnable btnAction, boolean circleRight) {
        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                int diam = (int)(Math.min(w, h) * 1.5);
                double cx = circleRight ? w * 0.55 : w * 0.45;
                g2.setColor(BG_CREAM);
                g2.setStroke(new BasicStroke(3f));
                g2.draw(new Ellipse2D.Double(cx - diam / 2.0,
                        h / 2.0 - diam / 2.0, diam, diam));
                g2.dispose();
            }
        };
        panel.setOpaque(false);

        JPanel inner = new JPanel();
        inner.setOpaque(false);
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));

        JLabel l1 = centeredLabel("SJC SILBI",  new Font("Georgia", Font.BOLD, 36), TEXT_CREAM);
        JLabel l2    = centeredLabel(subText,    new Font("SansSerif", Font.PLAIN, 14), TEXT_CREAM);

        JButton btn = outlineButton(btnText);
        btn.addActionListener(e -> btnAction.run());

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnRow.setOpaque(false);
        btnRow.add(btn);

        inner.add(l1);
        inner.add(Box.createVerticalStrut(14));
        inner.add(l2);
        inner.add(Box.createVerticalStrut(16));
        inner.add(btnRow);
        panel.add(inner);
        return panel;
    }

    // ==================================================================
    //  FACE DIALOGS  (simple — no OpenCV needed)
    // ==================================================================
    private boolean showFaceCaptureDialog(String username) {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(16, 20, 8, 20));
        p.setBackground(Color.WHITE);

        JLabel ico  = new JLabel("\uD83D\uDCF8", SwingConstants.CENTER);
        ico.setFont(new Font("SansSerif", Font.PLAIN, 48));
        JLabel info = new JLabel(
            "<html><center><b>Register Face for " + username + "</b><br><br>"
            + "Position your face in the camera frame and click <b>Capture</b>.</center></html>",
            SwingConstants.CENTER);
        info.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        p.add(ico,  BorderLayout.NORTH);
        p.add(info, BorderLayout.CENTER);

        int res = JOptionPane.showConfirmDialog(this, p,
                "Capture Face", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res != JOptionPane.OK_OPTION) return false;

        // Save a placeholder face image
        try {
            Files.createDirectories(Paths.get(FACE_DIR));
            BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setColor(new Color(0x2A2A50)); g.fillRect(0, 0, 100, 100);
            g.setColor(BG_CREAM); g.fillOval(20, 10, 60, 70);
            g.setColor(new Color(0x2A2A50));
            g.fillOval(32, 30, 10, 10); g.fillOval(58, 30, 10, 10);
            g.drawArc(38, 58, 24, 12, 0, -180);
            g.setFont(new Font("SansSerif", Font.BOLD, 8));
            g.setColor(BG_CREAM);
            g.drawString(username.substring(0, Math.min(username.length(), 8)), 4, 96);
            g.dispose();
            ImageIO.write(img, "png",
                new File(FACE_DIR + File.separator + username.toLowerCase() + ".png"));
        } catch (IOException ex) {
            System.err.println("Face save error: " + ex.getMessage());
        }

        JOptionPane.showMessageDialog(this,
            "\u2705  Face captured for " + username + "!",
            "Success", JOptionPane.INFORMATION_MESSAGE);
        return true;
    }

    private boolean showFaceVerifyDialog(String username) {
        JProgressBar bar = new JProgressBar(0, 100);
        bar.setStringPainted(true);
        bar.setString("Analyzing face...");
        bar.setForeground(new Color(0x2A2A50));

        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(16, 20, 16, 20));
        p.setBackground(Color.WHITE);
        JLabel lbl = new JLabel(
            "<html><center>Look at the camera to verify your identity.<br>"
            + "Verifying: <b>" + username + "</b></center></html>",
            SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        p.add(lbl, BorderLayout.NORTH);
        p.add(bar, BorderLayout.CENTER);

        JDialog dlg = new JDialog((Frame) null, "Face Verification", true);
        dlg.setUndecorated(true);
        dlg.getRootPane().setBorder(new LineBorder(new Color(0x2A2A50), 2, true));
        dlg.add(p);
        dlg.setSize(320, 110);
        dlg.setLocationRelativeTo(this);

        Timer t = new Timer(40, null);
        t.addActionListener(ev -> {
            int v = bar.getValue() + 4;
            if (v >= 100) { t.stop(); dlg.dispose(); }
            else bar.setValue(v);
        });
        t.start();
        dlg.setVisible(true);

        boolean ok = Math.random() > 0.05; // 95% success for demo
        if (!ok) JOptionPane.showMessageDialog(this,
            "\u274C  Face not recognised. Try again or use password.",
            "Verification Failed", JOptionPane.ERROR_MESSAGE);
        return ok;
    }

    private boolean hasFaceData(String username) {
        return new File(FACE_DIR + File.separator + username.toLowerCase() + ".png").exists();
    }

    // ==================================================================
    //  FORGOT PASSWORD  (unchanged logic, restyled dialogs)
    // ==================================================================
    private void showForgotPasswordDialog() {
        // Step 1
        JTextField usernameField = styledDialogField();
        JPanel s1 = dialogStep("\uD83D\uDD11  Forgot your password?",
            "Enter your <b>username</b> below.", "Username", usernameField);
        if (JOptionPane.showConfirmDialog(this, s1,
                "Forgot Password — Step 1 of 3",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE)
                != JOptionPane.OK_OPTION) return;

        String username = usernameField.getText().trim();
        if (username.isEmpty()) { UIUtils.showError(this, "Please enter your username."); return; }

        DataStore.User target = null;
        for (DataStore.User u : DataStore.getInstance().getAllUsers())
            if (u.username.equalsIgnoreCase(username)) { target = u; break; }
        if (target == null) { UIUtils.showError(this, "No account found: " + username); return; }

        // Step 2
        JTextField emailField = styledDialogField();
        JPanel s2 = dialogStep("\uD83D\uDCE7  Verify your identity",
            "Account found for <b>" + username + "</b>.<br>Enter the registered <b>email</b>.",
            "Email Address", emailField);
        if (JOptionPane.showConfirmDialog(this, s2,
                "Forgot Password — Step 2 of 3",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE)
                != JOptionPane.OK_OPTION) return;

        if (!emailField.getText().trim().equalsIgnoreCase(target.email)) {
            UIUtils.showError(this, "Email does not match. Reset cancelled."); return;
        }

        // Step 3
        JPasswordField np = styledPasswordField(), cp = styledPasswordField();
        JPanel s3 = new JPanel(new GridBagLayout());
        s3.setBackground(Color.WHITE);
        s3.setPreferredSize(new Dimension(360, 200));
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0; gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1; gc.insets = new Insets(5, 10, 5, 10);
        gc.gridy = 0; s3.add(stepTitle("\uD83D\uDD12  Set a new password"), gc);
        gc.gridy = 1; s3.add(stepBody("Email verified! Choose a <b>new password</b> (min 6 chars)."), gc);
        gc.gridy = 2; s3.add(stepLabel("New Password"), gc);
        gc.gridy = 3; s3.add(np, gc);
        gc.gridy = 4; s3.add(stepLabel("Confirm Password"), gc);
        gc.gridy = 5; s3.add(cp, gc);

        if (JOptionPane.showConfirmDialog(this, s3,
                "Forgot Password — Step 3 of 3",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE)
                != JOptionPane.OK_OPTION) return;

        String pw1 = new String(np.getPassword()).trim();
        String pw2 = new String(cp.getPassword()).trim();
        if (pw1.isEmpty())              { UIUtils.showError(this, "Password cannot be empty.");        return; }
        if (pw1.length() < 6)           { UIUtils.showError(this, "Minimum 6 characters.");            return; }
        if (!pw1.equals(pw2))           { UIUtils.showError(this, "Passwords do not match.");          return; }

        DataStore.getInstance().adminResetPassword(target.username, pw1);
        JOptionPane.showMessageDialog(this,
            "\u2705  Password reset! You can now log in.", "Done",
            JOptionPane.INFORMATION_MESSAGE);
        loginUser.setText(target.username);
        loginPass.setText("");
        screenLayout.show(screenCards, SCREEN_LOGIN);
    }

    // ==================================================================
    //  LOGIN / REGISTER  LOGIC
    // ==================================================================
    private void doLogin() {
        String user = loginUser.getText().trim();
        String pass = new String(loginPass.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            UIUtils.showError(this, "Please enter username and password."); return;
        }
        if (DataStore.getInstance().login(user, pass)) {
            mainFrame.showDashboard();
        } else {
            UIUtils.showError(this, "Invalid username or password.");
        }
    }

    private void doRegister() {
        String full    = regFull.getText().trim();
        String user    = regUser.getText().trim();
        String email   = regEmail.getText().trim();
        String section = regSection.getText().trim();
        String role    = (String) regRole.getSelectedItem();
        String pass    = new String(regPass.getPassword());
        String pass2   = new String(regPass2.getPassword());

        if (full.isEmpty() || user.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            UIUtils.showError(this, "Please fill in all required fields."); return;
        }
        if (!pass.equals(pass2))  { UIUtils.showError(this, "Passwords do not match.");          return; }
        if (pass.length() < 6)    { UIUtils.showError(this, "Password must be at least 6 chars."); return; }
        if (!faceCaptured) {
            int c = JOptionPane.showConfirmDialog(this,
                "You haven't registered a face yet.\nContinue without face recognition?",
                "Face Not Registered", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (c != JOptionPane.YES_OPTION) return;
        }
        if (DataStore.getInstance().register(user, pass, full, email, role, section)) {
            UIUtils.showSuccess(this, "Account created! You can now log in.");
            loginUser.setText(user);
            loginPass.setText("");
            screenLayout.show(screenCards, SCREEN_LOGIN);
        } else {
            UIUtils.showError(this, "Username already exists. Please choose another.");
        }
    }

    // ==================================================================
    //  WIDGET HELPERS
    // ==================================================================

    /** Rounded panel with a solid fill colour. */
    private JPanel roundedCard(Color bg, int arc) {
        return new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
                g2.dispose();
            }
        };
    }

    /** Dark rounded input field with placeholder behaviour. */
    private JTextField darkField(String placeholder, boolean isPassword) {
        JTextField f = isPassword ? new JPasswordField(20) : new JTextField(20);
        f.setOpaque(false);
        f.setBorder(BorderFactory.createEmptyBorder());
        f.setFont(new Font("SansSerif", Font.PLAIN, 13));
        f.setForeground(new Color(0xAAAAAA));
        f.setCaretColor(Color.WHITE);
        f.setText(placeholder);
        if (isPassword) ((JPasswordField) f).setEchoChar((char) 0);
        f.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if (f.getText().equals(placeholder)) {
                    f.setText(""); f.setForeground(Color.WHITE);
                    if (isPassword) ((JPasswordField) f).setEchoChar('\u2022');
                }
            }
            @Override public void focusLost(FocusEvent e) {
                if (f.getText().isEmpty()) {
                    f.setText(placeholder); f.setForeground(new Color(0xAAAAAA));
                    if (isPassword) ((JPasswordField) f).setEchoChar((char) 0);
                }
            }
        });
        return f;
    }

    /** Wraps a dark field inside a dark rounded background with an icon. */
    private JPanel fieldWrapper(JTextField field, String iconText) {
        JPanel w = roundedCard(FIELD_BG, 12);
        w.setLayout(new BorderLayout());
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        w.setPreferredSize(new Dimension(0, 46));
        w.setBorder(new EmptyBorder(4, 12, 4, 12));

        if (field instanceof JPasswordField) {
            JPasswordField pf = (JPasswordField) field;
            // Eye toggle button
            JLabel toggle = new JLabel("\uD83D\uDC41"); // 👁
            toggle.setForeground(TEXT_CREAM);
            toggle.setFont(new Font("SansSerif", Font.PLAIN, 14));
            toggle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            toggle.addMouseListener(new MouseAdapter() {
                private boolean visible = false;
                @Override public void mouseClicked(MouseEvent e) {
                    visible = !visible;
                    pf.setEchoChar(visible ? (char) 0 : '\u2022');
                    toggle.setText(visible ? "\uD83D\uDC41" : "\uD83D\uDD12");
                }
            });
            w.add(field,  BorderLayout.CENTER);
            w.add(toggle, BorderLayout.EAST);
        } else {
            JLabel icon = new JLabel(iconText);
            icon.setForeground(TEXT_CREAM);
            icon.setFont(new Font("SansSerif", Font.PLAIN, 14));
            w.add(field, BorderLayout.CENTER);
            w.add(icon,  BorderLayout.EAST);
        }
        return w;
    }

    private JPanel comboWrapper(JComboBox<?> combo, String label) {
        JPanel w = roundedCard(FIELD_BG, 12);
        w.setLayout(new BorderLayout(8, 0));
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        w.setPreferredSize(new Dimension(0, 46));
        w.setBorder(new EmptyBorder(4, 12, 4, 12));
        JLabel lbl = new JLabel(label);
        lbl.setForeground(Color.BLACK);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        w.add(lbl,   BorderLayout.WEST);
        w.add(combo, BorderLayout.CENTER);
        return w;
    }

    private void styleCombo(JComboBox<?> c) {
        c.setBackground(FIELD_BG);
        c.setForeground(Color.BLACK);
        c.setFont(new Font("SansSerif", Font.PLAIN, 13));
        c.setBorder(BorderFactory.createEmptyBorder());
        // Center the selected item text
        c.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(
                    javax.swing.JList<?> list, Object value,
                    int index, boolean isSelected, boolean cellHasFocus) {
                JLabel lbl = (JLabel) super.getListCellRendererComponent(
                        list, value, index, isSelected, cellHasFocus);
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
                if (isSelected) {
                    lbl.setBackground(new Color(0x163D2D));
                    lbl.setForeground(Color.WHITE);
                } else {
                    lbl.setBackground(Color.WHITE);
                    lbl.setForeground(Color.BLACK);
                }
                return lbl;
            }
        });
    }

    private JPanel wrapCard(JPanel card) {
        JPanel w = new JPanel(new BorderLayout());
        w.setOpaque(false);
        w.setBorder(new EmptyBorder(0, 25, 30, 25));
        w.add(card, BorderLayout.CENTER);
        return w;
    }

    /** Full-width dark rounded primary button. */
    private JButton primaryButton(String text) {
        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(FIELD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.setColor(TEXT_CREAM);
                g2.setFont(new Font("Georgia", Font.BOLD, 15));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(text,
                        (getWidth()  - fm.stringWidth(text)) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        btn.setOpaque(false); btn.setContentAreaFilled(false); btn.setBorderPainted(false);
        btn.setAlignmentX(CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        btn.setPreferredSize(new Dimension(0, 46));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Cream-outline button used in the branding panel. */
    private JButton outlineButton(String text) {
        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_DARK);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.setColor(TEXT_CREAM);
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 12, 12);
                g2.setFont(new Font("Georgia", Font.BOLD, 15));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(text,
                        (getWidth()  - fm.stringWidth(text)) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        btn.setOpaque(false); btn.setContentAreaFilled(false); btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(160, 46));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JLabel centeredLabel(String text, Font font, Color color) {
        JLabel l = new JLabel(text.replace("\n", "<br>").contains("<br>")
                ? "<html><div style='text-align:center'>" + text.replace("\n","<br>") + "</div></html>"
                : text, SwingConstants.CENTER);
        l.setFont(font);
        l.setForeground(color);
        l.setAlignmentX(CENTER_ALIGNMENT);
        return l;
    }

    // ── Forgot-password dialog helpers ────────────────────────────────────
    private JPanel dialogStep(String iconText, String bodyHtml,
                               String fieldLabel, JTextField field) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setPreferredSize(new Dimension(370, 160));
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0; gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1; gc.insets = new Insets(5, 10, 5, 10);
        gc.gridy = 0; p.add(stepTitle(iconText), gc);
        gc.gridy = 1; p.add(stepBody(bodyHtml),  gc);
        gc.gridy = 2; p.add(stepLabel(fieldLabel), gc);
        gc.gridy = 3; p.add(field, gc);
        return p;
    }

    private JLabel stepTitle(String t) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Segoe UI", Font.BOLD, 14));
        l.setForeground(new Color(0x1E1E3A));
        return l;
    }

    private JLabel stepBody(String html) {
        JLabel l = new JLabel("<html>" + html + "</html>");
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(new Color(100, 100, 100));
        return l;
    }

    private JLabel stepLabel(String t) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l.setForeground(new Color(60, 80, 70));
        return l;
    }

    private JTextField styledDialogField() {
        JTextField f = new JTextField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setPreferredSize(new Dimension(0, 36));
        f.setBorder(new CompoundBorder(
            new LineBorder(new Color(180, 195, 185), 1, true),
            new EmptyBorder(4, 10, 4, 10)));
        return f;
    }

    private JPasswordField styledPasswordField() {
        JPasswordField f = new JPasswordField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setPreferredSize(new Dimension(0, 36));
        f.setBorder(new CompoundBorder(
            new LineBorder(new Color(180, 195, 185), 1, true),
            new EmptyBorder(4, 10, 4, 10)));
        return f;
    }

    /** Called from MainFrame to jump straight to the Login tab. */
    public void showLoginTab() {
        screenLayout.show(screenCards, SCREEN_LOGIN);
    }
}
