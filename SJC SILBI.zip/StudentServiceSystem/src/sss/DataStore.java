package sss;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * In-memory data store shared across all modules.
 * In a real application this would connect to a database.
 */
public class DataStore {

    private static DataStore instance;

    // ── Users ──────────────────────────────────────────────────────────────
    private final List<User> users = new ArrayList<>();
    private User currentUser = null;

    // ── Reports ────────────────────────────────────────────────────────────
    private final List<Report> reports = new ArrayList<>();
    private int reportIdSeq = 1000;

    // ── Document Requests ──────────────────────────────────────────────────
    private final List<DocumentRequest> docRequests = new ArrayList<>();
    private int docIdSeq = 2000;

    // ── Appointments ───────────────────────────────────────────────────────
    private final List<Appointment> appointments = new ArrayList<>();
    private int apptIdSeq = 3000;

    // ── Notifications ──────────────────────────────────────────────────────
    private final List<Notification> notifications = new ArrayList<>();

    // ── Info Requests ──────────────────────────────────────────────────────
    private final List<InfoRequest> infoRequests = new ArrayList<>();
    private int infoIdSeq = 4000;

    // ── Service Requests ───────────────────────────────────────────────────
    private final List<ServiceRequest> serviceRequests = new ArrayList<>();
    private int serviceReqIdSeq = 6000;

    // ── Open Data Records ──────────────────────────────────────────────────
    private final List<OpenDataRecord> openDataRecords = new ArrayList<>();
    private int openDataIdSeq = 5000;

    // ── Audit Log ──────────────────────────────────────────────────────────
    private final List<AuditLog> auditLogs = new ArrayList<>();

    private DataStore() { seedData(); }

    public static DataStore getInstance() {
        if (instance == null) instance = new DataStore();
        return instance;
    }

    // ── Seed ───────────────────────────────────────────────────────────────
    private void seedData() {
        // Accounts: admin + demo students
        users.add(new User("admin",    "admin123", "System Administrator", "admin@sjc.edu",    "Administrator", "N/A"));
        users.add(new User("student1", "pass123",  "Juan Dela Cruz",       "juan@sjc.edu",     "Student",       "BSCS-2A"));
        users.add(new User("student2", "pass123",  "Maria Santos",         "maria@sjc.edu",    "Student",       "BSIT-3B"));
        users.add(new User("faculty1", "pass123",  "Prof. Roberto Reyes",  "rreyes@sjc.edu",   "Faculty",       "CS Dept"));
        users.add(new User("staff1",   "pass123",  "Ana Gonzales",         "agonzales@sjc.edu","Staff",         "Registrar"));

        // Demo service requests
        serviceRequests.add(new ServiceRequest("6001", "IT & Technology", "Wi-Fi / Internet Issue",
                "Can't connect to SJC-WiFi in Bldg C 3rd floor",
                "Need help connecting to the WiFi network. Unable to access from classroom 301.",
                "High", "John Doe", now()));
        serviceRequests.add(new ServiceRequest("6002", "Facilities", "Room/Venue Reservation",
                "Conference Room A for org meeting",
                "Need to reserve Conference Room A for student org general assembly on Nov 15.",
                "Medium", "Jane Smith", now()));
        serviceRequests.add(new ServiceRequest("6003", "IT & Technology", "Software Installation Request",
                "Need Adobe Creative Suite for project",
                "Requesting installation of Adobe Creative Suite on lab computers for graphic design coursework.",
                "Medium", "Mike Johnson", now()));
        serviceRequests.add(new ServiceRequest("6004", "Administrative", "Transcript Request",
                "Official transcript for job application",
                "Need official transcript sent to ABC Corporation for employment verification.",
                "High", "Sarah Wilson", now()));
        
        // Set different statuses for demo
        serviceRequests.get(0).status = "In Progress";
        serviceRequests.get(1).status = "Approved";
        // Leave 6003 and 6004 as "Pending" for admin approval demo

        // Demo notifications
        notifications.add(new Notification("SYS", "Welcome to Student Service System!", now()));
        notifications.add(new Notification("SYS", "Enrollment period starts Oct 1, 2026.", now()));
        notifications.add(new Notification("SYS", "Library hours extended until 9 PM.", now()));

        // Demo reports
        Report r1 = new Report(String.valueOf(reportIdSeq++), "Bullying / Harassment",
            "Incident in Building C", "A classmate was verbally harassing me near the cafeteria.",
            "High", "Juan Dela Cruz", now());
        r1.status = "Processing";
        Report r2 = new Report(String.valueOf(reportIdSeq++), "Facility Issue",
            "Broken AC in Room 201", "Air conditioning unit has been broken for two weeks.",
            "Medium", "Maria Santos", now());
        reports.add(r1); reports.add(r2);

        // Demo doc requests
        DocumentRequest d1 = new DocumentRequest(String.valueOf(docIdSeq++),
            "Certificate of Enrollment", "scholarship application", "2", "Juan Dela Cruz", now());
        d1.status = "Processing";
        DocumentRequest d2 = new DocumentRequest(String.valueOf(docIdSeq++),
            "Transcript of Records (TOR)", "employment", "1", "Maria Santos", now());
        docRequests.add(d1); docRequests.add(d2);

        // Demo appointments
        Appointment a1 = new Appointment(String.valueOf(apptIdSeq++),
            "Registrar's Office", "2026-09-10", "10:00 AM",
            "TOR release inquiry", "Juan Dela Cruz", now());
        appointments.add(a1);

        // Demo info requests
        InfoRequest i1 = new InfoRequest(String.valueOf(infoIdSeq++),
            "Scholarship Information", "What scholarships are available for second year students?",
            "juan@sjc.edu", "Juan Dela Cruz", now());
        infoRequests.add(i1);

        // Demo open data
        openDataRecords.add(new OpenDataRecord("Enrollment Statistics 2026", "Academic",
            "Total enrolled: 4,521 students across all programs.", now()));
        openDataRecords.add(new OpenDataRecord("Faculty Directory", "Academic",
            "List of all faculty members and their departments.", now()));
        openDataRecords.add(new OpenDataRecord("School Calendar 2026-2027", "Administrative",
            "Key academic dates and holidays.", now()));
        openDataRecords.add(new OpenDataRecord("Scholarship Programs", "Financial",
            "Available scholarships and grant programs.", now()));
        openDataRecords.add(new OpenDataRecord("Campus Map", "Facilities",
            "Building locations and room assignments.", now()));

        // Seed audit log
        auditLogs.add(new AuditLog("SYSTEM", "BOOT", "Application started.", now()));
    }

    public static String now() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
    }

    // ── Role helpers ───────────────────────────────────────────────────────
    public boolean isAdmin() {
        return currentUser != null && "Administrator".equalsIgnoreCase(currentUser.role);
    }

    // ── User ops ───────────────────────────────────────────────────────────
    public boolean login(String username, String password) {
        for (User u : users) {
            if (u.username.equals(username) && u.password.equals(password) && u.active) {
                currentUser = u;
                addNotification("SYS", "Login successful. Welcome, " + u.fullName + "!");
                audit(u.username, "LOGIN", "User logged in.");
                return true;
            }
        }
        audit("UNKNOWN", "LOGIN_FAIL", "Failed login attempt for: " + username);
        return false;
    }

    /** Face-recognition bypass — sets the current user without password check. */
    public void loginDirect(String username) {
        for (User u : users) {
            if (u.username.equals(username) && u.active) {
                currentUser = u;
                addNotification("SYS", "Face login successful. Welcome, " + u.fullName + "!");
                audit(u.username, "FACE_LOGIN", "User logged in via face recognition.");
                return;
            }
        }
    }

    public boolean register(String username, String password, String fullName,
                            String email, String role, String section) {
        for (User u : users) {
            if (u.username.equalsIgnoreCase(username)) return false;
        }
        users.add(new User(username, password, fullName, email, role, section));
        audit("SYSTEM", "REGISTER", "New user registered: " + username);
        return true;
    }

    public void logout() {
        if (currentUser != null) audit(currentUser.username, "LOGOUT", "User logged out.");
        currentUser = null;
    }

    public User getCurrentUser() { return currentUser; }
    public boolean isLoggedIn()  { return currentUser != null; }

    public List<User> getAllUsers() { return new ArrayList<>(users); }

    public boolean updateProfile(String fullName, String email, String section) {
        if (currentUser == null) return false;
        currentUser.fullName = fullName;
        currentUser.email    = email;
        currentUser.section  = section;
        audit(currentUser.username, "PROFILE_UPDATE", "Profile updated.");
        return true;
    }

    /** Admin: add a new user account */
    public boolean adminAddUser(String username, String password, String fullName,
                                String email, String role, String section) {
        return register(username, password, fullName, email, role, section);
    }

    /** Admin: update any user's details */
    public boolean adminUpdateUser(String username, String fullName, String email,
                                   String role, String section, boolean active) {
        for (User u : users) {
            if (u.username.equals(username)) {
                u.fullName = fullName; u.email = email;
                u.role = role; u.section = section; u.active = active;
                audit("ADMIN", "USER_UPDATE", "Updated user: " + username);
                return true;
            }
        }
        return false;
    }

    /** Admin: delete a user (cannot delete yourself) */
    public boolean adminDeleteUser(String username) {
        if (currentUser != null && currentUser.username.equals(username)) return false;
        boolean removed = users.removeIf(u -> u.username.equals(username));
        if (removed) audit("ADMIN", "USER_DELETE", "Deleted user: " + username);
        return removed;
    }

    /** Admin: reset a user's password */
    public boolean adminResetPassword(String username, String newPassword) {
        for (User u : users) {
            if (u.username.equals(username)) {
                u.password = newPassword;
                audit("ADMIN", "PASSWORD_RESET", "Password reset for: " + username);
                return true;
            }
        }
        return false;
    }

    // ── Report ops ─────────────────────────────────────────────────────────
    public Report submitReport(String category, String subject, String details, String priority) {
        String submitter = currentUser != null ? currentUser.fullName : "Anonymous";
        Report r = new Report(String.valueOf(reportIdSeq++), category, subject, details,
                              priority, submitter, now());
        reports.add(r);
        addNotification("RPT", "Report #" + r.id + " submitted: " + subject);
        audit(submitter, "REPORT_SUBMIT", "Report submitted: " + subject);
        return r;
    }

    public List<Report> getReports() { return new ArrayList<>(reports); }

    public boolean updateReportStatus(String id, String status) {
        for (Report r : reports) {
            if (r.id.equals(id)) {
                r.status = status;
                audit("ADMIN", "REPORT_STATUS", "Report #" + id + " -> " + status);
                addNotification("RPT", "Report #" + id + " status updated to: " + status);
                return true;
            }
        }
        return false;
    }

    public boolean updateReportRemarks(String id, String remarks) {
        for (Report r : reports) {
            if (r.id.equals(id)) { r.remarks = remarks; return true; }
        }
        return false;
    }

    public boolean deleteReport(String id) {
        boolean removed = reports.removeIf(r -> r.id.equals(id));
        if (removed) audit("ADMIN", "REPORT_DELETE", "Deleted report #" + id);
        return removed;
    }

    // ── Document Request ops ───────────────────────────────────────────────
    public DocumentRequest submitDocRequest(String docType, String purpose, String copies) {
        String requester = currentUser != null ? currentUser.fullName : "Anonymous";
        DocumentRequest dr = new DocumentRequest(String.valueOf(docIdSeq++),
                                                 docType, purpose, copies, requester, now());
        docRequests.add(dr);
        addNotification("DOC", "Document request #" + dr.id + " received: " + docType);
        audit(requester, "DOC_REQUEST", "Document requested: " + docType);
        return dr;
    }

    public List<DocumentRequest> getDocRequests() { return new ArrayList<>(docRequests); }

    public boolean updateDocStatus(String id, String status) {
        for (DocumentRequest dr : docRequests) {
            if (dr.id.equals(id)) {
                dr.status = status;
                audit("ADMIN", "DOC_STATUS", "Doc request #" + id + " -> " + status);
                addNotification("DOC", "Document request #" + id + " is now: " + status);
                return true;
            }
        }
        return false;
    }

    public boolean updateDocRemarks(String id, String remarks) {
        for (DocumentRequest dr : docRequests) {
            if (dr.id.equals(id)) { dr.remarks = remarks; return true; }
        }
        return false;
    }

    // ── Appointment ops ────────────────────────────────────────────────────
    public Appointment bookAppointment(String office, String date, String time, String purpose) {
        String student = currentUser != null ? currentUser.fullName : "Anonymous";
        Appointment a = new Appointment(String.valueOf(apptIdSeq++),
                                        office, date, time, purpose, student, now());
        appointments.add(a);
        addNotification("APPT", "Appointment #" + a.id + " booked at " + office);
        audit(student, "APPT_BOOK", "Appointment booked at " + office + " on " + date);
        return a;
    }

    public List<Appointment> getAppointments() { return new ArrayList<>(appointments); }

    public boolean updateAppointmentStatus(String id, String status) {
        for (Appointment a : appointments) {
            if (a.id.equals(id)) {
                a.status = status;
                audit("ADMIN", "APPT_STATUS", "Appointment #" + id + " -> " + status);
                addNotification("APPT", "Appointment #" + id + " status updated to: " + status);
                return true;
            }
        }
        return false;
    }

    public boolean cancelAppointment(String id) {
        return updateAppointmentStatus(id, "Cancelled");
    }

    // ── Notification ops ───────────────────────────────────────────────────
    public List<Notification> getNotifications() { return new ArrayList<>(notifications); }
    public int getUnreadCount() {
        return (int) notifications.stream().filter(n -> !n.read).count();
    }
    public void markAllRead() { notifications.forEach(n -> n.read = true); }
    public void addNotification(String source, String message) {
        notifications.add(0, new Notification(source, message, now()));
    }
    public boolean deleteNotification(int index) {
        if (index >= 0 && index < notifications.size()) {
            notifications.remove(index);
            return true;
        }
        return false;
    }

    // ── Info Request ops ───────────────────────────────────────────────────
    public InfoRequest submitInfoRequest(String topic, String details, String contactEmail) {
        String requester = currentUser != null ? currentUser.fullName : "Anonymous";
        InfoRequest ir = new InfoRequest(String.valueOf(infoIdSeq++),
                                         topic, details, contactEmail, requester, now());
        infoRequests.add(ir);
        addNotification("INFO", "Information request #" + ir.id + " submitted.");
        audit(requester, "INFO_REQUEST", "Info request submitted: " + topic);
        return ir;
    }

    public List<InfoRequest> getInfoRequests() { return new ArrayList<>(infoRequests); }

    public boolean updateInfoStatus(String id, String status) {
        for (InfoRequest ir : infoRequests) {
            if (ir.id.equals(id)) {
                ir.status = status;
                audit("ADMIN", "INFO_STATUS", "Info request #" + id + " -> " + status);
                addNotification("INFO", "Your information request #" + id + " is now: " + status);
                return true;
            }
        }
        return false;
    }

    public boolean updateInfoResponse(String id, String response) {
        for (InfoRequest ir : infoRequests) {
            if (ir.id.equals(id)) { ir.adminResponse = response; return true; }
        }
        return false;
    }

    // ── Service Request ops ────────────────────────────────────────────────
    public ServiceRequest submitServiceRequest(String category, String serviceType,
                                               String subject, String details, String priority) {
        String requester = currentUser != null ? currentUser.fullName : "Anonymous";
        ServiceRequest sr = new ServiceRequest(String.valueOf(serviceReqIdSeq++),
                category, serviceType, subject, details, priority, requester, now());
        serviceRequests.add(sr);
        addNotification("SVC", "Service request #" + sr.id + " submitted: " + subject);
        audit(requester, "SERVICE_REQUEST", "Service request submitted: " + subject);
        return sr;
    }

    public List<ServiceRequest> getServiceRequests() { return new ArrayList<>(serviceRequests); }

    public boolean updateServiceRequestStatus(String id, String status, String remarks) {
        for (ServiceRequest sr : serviceRequests) {
            if (sr.id.equals(id)) {
                sr.status  = status;
                if (remarks != null && !remarks.isEmpty()) sr.adminRemarks = remarks;
                audit("ADMIN", "SERVICE_STATUS", "Service request #" + id + " -> " + status);
                addNotification("SVC", "Service request #" + id + " is now: " + status);
                return true;
            }
        }
        return false;
    }

    public boolean deleteServiceRequest(String id) {
        boolean removed = serviceRequests.removeIf(sr -> sr.id.equals(id));
        if (removed) audit("ADMIN", "SERVICE_DELETE", "Deleted service request #" + id);
        return removed;
    }

    // ── Open Data ops ──────────────────────────────────────────────────────
    public List<OpenDataRecord> getOpenData() { return new ArrayList<>(openDataRecords); }

    public OpenDataRecord addOpenData(String title, String category, String description) {
        OpenDataRecord r = new OpenDataRecord(title, category, description, now());
        openDataRecords.add(r);
        audit("ADMIN", "OPENDATA_ADD", "Open data added: " + title);
        return r;
    }

    public boolean deleteOpenData(int index) {
        if (index >= 0 && index < openDataRecords.size()) {
            String title = openDataRecords.get(index).title;
            openDataRecords.remove(index);
            audit("ADMIN", "OPENDATA_DELETE", "Open data deleted: " + title);
            return true;
        }
        return false;
    }

    // ── Audit Log ops ──────────────────────────────────────────────────────
    public List<AuditLog> getAuditLogs() { return new ArrayList<>(auditLogs); }

    private void audit(String actor, String action, String details) {
        auditLogs.add(0, new AuditLog(actor, action, details, now()));
    }

    // =======================================================================
    // Inner model classes
    // =======================================================================

    public static class User {
        public String username, password, fullName, email, role, section;
        public boolean active = true;
        public User(String u, String p, String fn, String e, String r, String s) {
            username = u; password = p; fullName = fn; email = e; role = r; section = s;
        }
    }

    public static class Report {
        public String id, category, subject, details, priority, submitter, date, remarks = "";
        public String status = "Pending";
        public Report(String id, String cat, String sub, String det,
                      String pri, String sub2, String d) {
            this.id = id; category = cat; subject = sub; details = det;
            priority = pri; submitter = sub2; date = d;
        }
    }

    public static class DocumentRequest {
        public String id, docType, purpose, copies, requester, date, remarks = "";
        public String status = "Pending";
        public DocumentRequest(String id, String dt, String p, String c, String r, String d) {
            this.id = id; docType = dt; purpose = p; copies = c; requester = r; date = d;
        }
    }

    public static class Appointment {
        public String id, office, date, time, purpose, student, submittedAt;
        public String status = "Confirmed";
        public Appointment(String id, String o, String d, String t,
                           String p, String s, String sa) {
            this.id = id; office = o; date = d; time = t;
            purpose = p; student = s; submittedAt = sa;
        }
    }

    public static class Notification {
        public String source, message, date;
        public boolean read = false;
        public Notification(String s, String m, String d) { source = s; message = m; date = d; }
    }

    public static class InfoRequest {
        public String id, topic, details, contactEmail, requester, date, adminResponse = "";
        public String status = "Pending";
        public InfoRequest(String id, String t, String d, String ce, String r, String da) {
            this.id = id; topic = t; details = d; contactEmail = ce; requester = r; date = da;
        }
    }

    public static class OpenDataRecord {
        public String title, category, description, date;
        public OpenDataRecord(String t, String c, String d, String da) {
            title = t; category = c; description = d; date = da;
        }
    }

    public static class ServiceRequest {
        public String id, category, serviceType, subject, details, priority,
                      requester, date, adminRemarks = "";
        public String status = "Pending";
        public ServiceRequest(String id, String cat, String svcType, String sub,
                              String det, String pri, String req, String d) {
            this.id = id; category = cat; serviceType = svcType; subject = sub;
            details = det; priority = pri; requester = req; date = d;
        }
    }

    public static class AuditLog {
        public String actor, action, details, date;
        public AuditLog(String a, String ac, String d, String da) {
            actor = a; action = ac; details = d; date = da;
        }
    }
}
