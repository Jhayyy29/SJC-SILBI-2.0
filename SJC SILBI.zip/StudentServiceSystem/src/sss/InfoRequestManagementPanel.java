package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.LayoutManager;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class InfoRequestManagementPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTable table;
    private JComboBox<String> filterStatus;

    // Detail
    private JLabel detId, detTopic, detRequester, detEmail, detDate;
    private JTextArea detQuestion, responseArea;
    private JComboBox<String> statusBox;

    public InfoRequestManagementPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 246, 250));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppColors.DARK_GREEN);
        hdr.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel t = new JLabel("ℹ️  Information Request Management");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        hdr.add(t, BorderLayout.WEST);
        JButton back = UIUtils.secondaryButton("← Dashboard");
        back.addActionListener(e -> mainFrame.showPanel("admin_dashboard"));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(AppColors.DARK_GREEN);
        right.add(back);
        hdr.add(right, BorderLayout.EAST);
        return hdr;
    }

    private JPanel buildBody() {
        JPanel body = new JPanel(new GridLayout(1, 2, 16, 0));
        body.setBackground(new Color(245, 246, 250));
        body.setBorder(new EmptyBorder(16, 20, 16, 20));
        body.add(buildTablePanel());
        body.add(buildDetailPanel());
        return body;
    }

    private JPanel buildTablePanel() {
        JPanel card = whiteCard(new BorderLayout(0, 8));
        JLabel t = new JLabel("All Information Requests");
        t.setFont(new Font("Segoe UI", Font.BOLD, 16));
        t.setForeground(AppColors.DARK_GREEN);
        card.add(t, BorderLayout.NORTH);

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filters.setBackground(Color.WHITE);
        filterStatus = UIUtils.styledCombo(new String[]{"All","Pending","Processing","Resolved"});
        JButton applyBtn = UIUtils.primaryButton("Filter");
        applyBtn.setPreferredSize(new Dimension(80, 28));
        applyBtn.addActionListener(e -> loadTable());
        filters.add(new JLabel("Status:")); filters.add(filterStatus); filters.add(applyBtn);
        card.add(filters, BorderLayout.SOUTH);

        String[] cols = {"ID","Topic","Requester","Contact Email","Status","Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel) {
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (col == 4) {
                    JLabel lbl = UIUtils.statusBadge((String) getValueAt(row, col));
                    lbl.setHorizontalAlignment(SwingConstants.CENTER);
                    return lbl;
                }
                if (!isRowSelected(row))
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(110);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadDetail();
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);
        loadTable();
        return card;
    }

    private JPanel buildDetailPanel() {
        JPanel card = whiteCard(new BorderLayout(0, 10));
        JLabel title = new JLabel("Request Detail & Response");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(AppColors.DARK_GREEN);
        card.add(title, BorderLayout.NORTH);

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(Color.WHITE);

        detId        = info("—"); detTopic     = info("—");
        detRequester = info("—"); detEmail     = info("—");
        detDate      = info("—");

        fields.add(row2("Request ID",  detId));        fields.add(gap());
        fields.add(row2("Topic",       detTopic));     fields.add(gap());
        fields.add(row2("From",        detRequester)); fields.add(gap());
        fields.add(row2("Contact",     detEmail));     fields.add(gap());
        fields.add(row2("Date",        detDate));      fields.add(Box.createVerticalStrut(10));

        JLabel ql = new JLabel("Student's Question:");
        ql.setFont(new Font("Segoe UI", Font.BOLD, 13)); ql.setForeground(AppColors.TEXT_DARK);
        fields.add(ql);
        fields.add(Box.createVerticalStrut(4));
        detQuestion = UIUtils.styledArea(4, 30);
        detQuestion.setEditable(false);
        detQuestion.setBackground(new Color(248, 250, 252));
        JScrollPane qs = new JScrollPane(detQuestion);
        qs.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(qs);
        fields.add(Box.createVerticalStrut(12));

        statusBox = UIUtils.styledCombo(new String[]{"Pending","Processing","Resolved"});
        fields.add(row2("Set Status", statusBox)); fields.add(gap());
        fields.add(Box.createVerticalStrut(8));

        JLabel rl = new JLabel("Admin Response:");
        rl.setFont(new Font("Segoe UI", Font.BOLD, 13)); rl.setForeground(AppColors.TEXT_DARK);
        fields.add(rl);
        fields.add(Box.createVerticalStrut(4));
        responseArea = UIUtils.styledArea(5, 30);
        JScrollPane rs = new JScrollPane(responseArea);
        rs.setBorder(new LineBorder(AppColors.BORDER));
        fields.add(rs);
        fields.add(Box.createVerticalStrut(12));

        // Quick respond buttons
        JPanel quick = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        quick.setBackground(Color.WHITE);
        JButton resolveBtn = UIUtils.primaryButton("Mark Resolved");
        resolveBtn.addActionListener(e -> quickResolve());
        quick.add(resolveBtn);
        fields.add(quick);
        fields.add(Box.createVerticalStrut(8));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(Color.WHITE);
        JButton saveBtn = UIUtils.primaryButton("Save Response");
        saveBtn.addActionListener(e -> saveResponse());
        btns.add(saveBtn);
        fields.add(btns);

        // Email status indicator
        emailStatusLabel = new JLabel(" ");
        emailStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        emailStatusLabel.setForeground(AppColors.TEXT_GRAY);
        fields.add(Box.createVerticalStrut(4));
        fields.add(emailStatusLabel);

        JScrollPane outer = new JScrollPane(fields);
        outer.setBorder(null);
        card.add(outer, BorderLayout.CENTER);
        return card;
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        String fs = (String) filterStatus.getSelectedItem();
        for (DataStore.InfoRequest ir : DataStore.getInstance().getInfoRequests()) {
            if (!"All".equals(fs) && !ir.status.equals(fs)) continue;
            tableModel.addRow(new Object[]{ir.id, ir.topic, ir.requester, ir.contactEmail, ir.status, ir.date});
        }
    }

    private void loadDetail() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String id = (String) tableModel.getValueAt(row, 0);
        for (DataStore.InfoRequest ir : DataStore.getInstance().getInfoRequests()) {
            if (ir.id.equals(id)) {
                detId.setText(ir.id);        detTopic.setText(ir.topic);
                detRequester.setText(ir.requester); detEmail.setText(ir.contactEmail);
                detDate.setText(ir.date);    detQuestion.setText(ir.details);
                responseArea.setText(ir.adminResponse);
                for (int i = 0; i < statusBox.getItemCount(); i++) {
                    if (statusBox.getItemAt(i).equals(ir.status)) { statusBox.setSelectedIndex(i); break; }
                }
                return;
            }
        }
    }

    private JLabel emailStatusLabel;

    private void quickResolve() {
        if (detId.getText().equals("—")) { UIUtils.showError(this, "Select a request first."); return; }
        String response = responseArea.getText().trim();
        if (response.isEmpty()) { UIUtils.showError(this, "Please write a response before resolving."); return; }
        String id        = detId.getText();
        String topic     = detTopic.getText();
        String requester = detRequester.getText();
        String email     = detEmail.getText();
        DataStore ds     = DataStore.getInstance();
        ds.updateInfoStatus(id, "Resolved");
        ds.updateInfoResponse(id, response);

        // ── Email notification ─────────────────────────────────────────
        String studentEmail = email.isBlank() ? findStudentEmail(requester) : email;
        EmailService.notifyInfoResponse(studentEmail, requester, id, topic, "Resolved", response,
            err -> javax.swing.SwingUtilities.invokeLater(() -> {
                if (err == null) showEmailBadge("✅ Resolved. Response emailed to " + studentEmail, false);
                else             showEmailBadge("⚠️ Resolved but email failed: " + err, true);
            })
        );
        UIUtils.showSuccess(this, "Request #" + id + " resolved.\nResponse emailed to " + studentEmail);
        loadTable();
    }

    private void saveResponse() {
        if (detId.getText().equals("—")) { UIUtils.showError(this, "Select a request first."); return; }
        String id        = detId.getText();
        String status    = (String) statusBox.getSelectedItem();
        String topic     = detTopic.getText();
        String requester = detRequester.getText();
        String email     = detEmail.getText();
        String response  = responseArea.getText().trim();
        DataStore ds     = DataStore.getInstance();
        ds.updateInfoStatus(id, status);
        ds.updateInfoResponse(id, response);

        // ── Email notification ─────────────────────────────────────────
        String studentEmail = email.isBlank() ? findStudentEmail(requester) : email;
        EmailService.notifyInfoResponse(studentEmail, requester, id, topic, status, response,
            err -> javax.swing.SwingUtilities.invokeLater(() -> {
                if (err == null) showEmailBadge("✅ Request #" + id + " updated. Email sent to " + studentEmail, false);
                else             showEmailBadge("⚠️ Updated but email failed: " + err, true);
            })
        );
        UIUtils.showSuccess(this, "Request #" + id + " updated to: " + status +
            "\nEmail notification is being sent.");
        loadTable();
    }

    private JLabel info(String t) { JLabel l = new JLabel(t); l.setFont(AppColors.BODY_FONT); l.setForeground(Color.BLACK); return l; }
    private Box.Filler gap() { return (Box.Filler) Box.createVerticalStrut(6); }
    private JPanel row2(String label, JComponent value) {
        JPanel row = new JPanel(new BorderLayout(8, 0)); row.setBackground(Color.WHITE);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel lbl = new JLabel(label + ":"); lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(Color.BLACK); lbl.setPreferredSize(new Dimension(110, 24));
        row.add(lbl, BorderLayout.WEST); row.add(value, BorderLayout.CENTER);
        return row;
    }
    private void styleTable(JTable t) {
        t.setFont(AppColors.BODY_FONT); t.setRowHeight(30);
        t.setGridColor(new Color(235, 235, 240));
        t.setSelectionBackground(new Color(200, 235, 215));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.getTableHeader().setBackground(AppColors.DARK_GREEN);
        t.getTableHeader().setForeground(Color.BLACK);
    }
    private JPanel whiteCard(LayoutManager lm) {
        JPanel p = new JPanel(lm); p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(new LineBorder(new Color(220, 220, 230), 1, true), new EmptyBorder(20, 20, 20, 20)));
        return p;
    }

    // ── Email helpers ──────────────────────────────────────────────────────

    private String findStudentEmail(String fullName) {
        for (DataStore.User u : DataStore.getInstance().getAllUsers()) {
            if (u.fullName.equalsIgnoreCase(fullName)) return u.email;
        }
        return EmailConfig.FALLBACK_STUDENT_EMAIL;
    }

    private void showEmailBadge(String msg, boolean warn) {
        if (emailStatusLabel != null) {
            emailStatusLabel.setText(msg);
            emailStatusLabel.setForeground(warn ? new Color(180, 90, 0) : new Color(22, 130, 70));
        }
    }
}
