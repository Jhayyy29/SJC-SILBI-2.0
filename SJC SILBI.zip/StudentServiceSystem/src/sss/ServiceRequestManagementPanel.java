package sss;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ServiceRequestManagementPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;
    private JTable requestTable;
    private JLabel statusLabel;
    private Timer statusTimer;

    public ServiceRequestManagementPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);
        add(buildTopPanel(), BorderLayout.NORTH);
        add(buildMainContent(), BorderLayout.CENTER);
        refreshTable();
    }

    // ── Top panel ─────────────────────────────────────────────────────────
    private JPanel buildTopPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(AppColors.CREAM);
        panel.setBorder(new EmptyBorder(20, 25, 15, 25));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(AppColors.CREAM);

        JLabel title = new JLabel("Service Request Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(AppColors.DARK_GREEN);

        JButton backBtn = UIUtils.secondaryButton("<- Dashboard");
        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainFrame.showPanel("admin_dashboard");
            }
        });

        header.add(title, BorderLayout.WEST);
        header.add(backBtn, BorderLayout.EAST);
        panel.add(header, BorderLayout.NORTH);
        panel.add(buildStatsRow(), BorderLayout.SOUTH);
        return panel;
    }

    private JPanel buildStatsRow() {
        JPanel row = new JPanel(new GridLayout(1, 5, 12, 0));
        row.setBackground(AppColors.CREAM);
        row.setBorder(new EmptyBorder(15, 0, 0, 0));

        List<DataStore.ServiceRequest> all = DataStore.getInstance().getServiceRequests();
        int pending = 0, approved = 0, inProgress = 0, completed = 0, rejected = 0;
        for (DataStore.ServiceRequest r : all) {
            String s = r.status;
            if ("Pending".equals(s))       pending++;
            else if ("Approved".equals(s))     approved++;
            else if ("In Progress".equals(s))  inProgress++;
            else if ("Completed".equals(s))    completed++;
            else if ("Rejected".equals(s))     rejected++;
        }

        row.add(statCard(pending,    "Pending",    new Color(230, 126, 34)));
        row.add(statCard(approved,   "Approved",   new Color(39, 174, 96)));
        row.add(statCard(inProgress, "In Progress",new Color(41, 128, 185)));
        row.add(statCard(completed,  "Completed",  new Color(22, 160, 133)));
        row.add(statCard(rejected,   "Rejected",   new Color(231, 76, 60)));
        return row;
    }

    private JPanel statCard(int value, String label, Color accent) {
        JPanel card = new JPanel(new BorderLayout(6, 2));
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 220, 230), 1, true),
            new EmptyBorder(10, 14, 10, 14)));

        JLabel numLabel = new JLabel(String.valueOf(value));
        numLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        numLabel.setForeground(accent);

        JLabel txtLabel = new JLabel(label);
        txtLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        txtLabel.setForeground(new Color(90, 90, 90));

        card.add(numLabel, BorderLayout.CENTER);
        card.add(txtLabel, BorderLayout.SOUTH);
        return card;
    }

    // ── Main content ──────────────────────────────────────────────────────
    private JPanel buildMainContent() {
        JPanel main = new JPanel(new BorderLayout(0, 12));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(0, 25, 25, 25));
        main.add(buildControlsPanel(), BorderLayout.NORTH);
        main.add(buildTablePanel(),    BorderLayout.CENTER);
        return main;
    }

    private JPanel buildControlsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 0));
        panel.setBackground(AppColors.CREAM);

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setBackground(AppColors.CREAM);
        left.add(new JLabel("Filter:"));

        final JComboBox<String> statusFilter = new JComboBox<String>(
            new String[]{"All","Pending","Approved","In Progress","Completed","Rejected","Cancelled"});
        statusFilter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                filterTable((String) statusFilter.getSelectedItem());
            }
        });
        left.add(statusFilter);

        JButton refreshBtn = UIUtils.secondaryButton("Refresh");
        refreshBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { refreshTable(); }
        });
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setBackground(AppColors.CREAM);
        right.add(refreshBtn);

        panel.add(left,  BorderLayout.WEST);
        panel.add(right, BorderLayout.EAST);
        return panel;
    }

    private JPanel buildTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new LineBorder(new Color(220, 220, 230), 1, true));

        String[] cols = {"ID","Category","Service Type","Subject",
                         "Priority","Student","Date","Status","Actions"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 8; }
        };

        requestTable = new JTable(tableModel);
        requestTable.setRowHeight(38);
        requestTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        requestTable.getColumnModel().getColumn(0).setPreferredWidth(55);
        requestTable.getColumnModel().getColumn(1).setPreferredWidth(115);
        requestTable.getColumnModel().getColumn(2).setPreferredWidth(135);
        requestTable.getColumnModel().getColumn(3).setPreferredWidth(200);
        requestTable.getColumnModel().getColumn(4).setPreferredWidth(70);
        requestTable.getColumnModel().getColumn(5).setPreferredWidth(100);
        requestTable.getColumnModel().getColumn(6).setPreferredWidth(85);
        requestTable.getColumnModel().getColumn(7).setPreferredWidth(90);
        requestTable.getColumnModel().getColumn(8).setPreferredWidth(210);

        // Colour-code status column
        requestTable.getColumnModel().getColumn(7).setCellRenderer(
            new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(
                        JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                    Component c = super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                    if (!sel) {
                        String s = val == null ? "" : val.toString();
                        if      ("Pending".equals(s))      c.setBackground(new Color(255, 249, 196));
                        else if ("Approved".equals(s))     c.setBackground(new Color(212, 237, 218));
                        else if ("In Progress".equals(s))  c.setBackground(new Color(217, 237, 247));
                        else if ("Completed".equals(s))    c.setBackground(new Color(209, 231, 221));
                        else if ("Rejected".equals(s))     c.setBackground(new Color(248, 215, 218));
                        else if ("Cancelled".equals(s))    c.setBackground(new Color(248, 215, 218));
                        else                               c.setBackground(Color.WHITE);
                    }
                    return c;
                }
            });

        requestTable.getColumnModel().getColumn(8).setCellRenderer(new ActionRenderer());
        requestTable.getColumnModel().getColumn(8).setCellEditor(new ActionEditor());

        JScrollPane sp = new JScrollPane(requestTable);
        sp.setBorder(null);
        sp.getViewport().setBackground(Color.WHITE);
        panel.add(sp, BorderLayout.CENTER);

        statusLabel = new JLabel(" ");
        statusLabel.setBorder(new EmptyBorder(7, 12, 7, 12));
        statusLabel.setBackground(new Color(248, 249, 250));
        statusLabel.setOpaque(true);
        panel.add(statusLabel, BorderLayout.SOUTH);

        return panel;
    }

    // ── Table helpers ─────────────────────────────────────────────────────
    private void refreshTable() {
        if (tableModel == null) return;
        tableModel.setRowCount(0);
        List<DataStore.ServiceRequest> list = DataStore.getInstance().getServiceRequests();
        for (DataStore.ServiceRequest r : list) {
            String d = (r.date != null && r.date.length() >= 10) ? r.date.substring(0, 10) : r.date;
            tableModel.addRow(new Object[]{
                r.id, r.category, r.serviceType, r.subject,
                r.priority, r.requester, d, r.status, "Actions"
            });
        }
        showMsg("Loaded " + list.size() + " requests", false);
    }

    private void filterTable(String filter) {
        if ("All".equals(filter)) { refreshTable(); return; }
        tableModel.setRowCount(0);
        int count = 0;
        for (DataStore.ServiceRequest r : DataStore.getInstance().getServiceRequests()) {
            if (filter.equals(r.status)) {
                String d = (r.date != null && r.date.length() >= 10) ? r.date.substring(0, 10) : r.date;
                tableModel.addRow(new Object[]{
                    r.id, r.category, r.serviceType, r.subject,
                    r.priority, r.requester, d, r.status, "Actions"
                });
                count++;
            }
        }
        showMsg("Showing " + count + " — " + filter, false);
    }

    private void rebuildTopPanel() {
        remove(getComponent(0));
        add(buildTopPanel(), BorderLayout.NORTH, 0);
        revalidate();
        repaint();
    }

    private DataStore.ServiceRequest findById(String id) {
        for (DataStore.ServiceRequest r : DataStore.getInstance().getServiceRequests())
            if (r.id.equals(id)) return r;
        return null;
    }

    private void showMsg(String msg, boolean err) {
        if (statusLabel == null) return;
        statusLabel.setText(msg);
        statusLabel.setForeground(err ? Color.RED : new Color(0, 120, 0));
        if (statusTimer != null) statusTimer.stop();
        statusTimer = new Timer(4000, new ActionListener() {
            public void actionPerformed(ActionEvent e) { statusLabel.setText(" "); }
        });
        statusTimer.setRepeats(false);
        statusTimer.start();
    }

    // ═════════════════════════════════════════════════════════════════════
    // Renderer
    // ═════════════════════════════════════════════════════════════════════
    private class ActionRenderer extends JPanel implements TableCellRenderer {
        private final JButton approveBtn = new JButton("Approve");
        private final JButton rejectBtn  = new JButton("Reject");
        private final JButton viewBtn    = new JButton("View");

        ActionRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 2, 3));
            setOpaque(true);
            style(approveBtn, new Color(40, 167, 69),  70);
            style(rejectBtn,  new Color(220, 53, 69),  65);
            style(viewBtn,    new Color(108, 117, 125), 58);
            add(approveBtn); add(rejectBtn); add(viewBtn);
        }

        private void style(JButton b, Color bg, int w) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 10));
            b.setPreferredSize(new Dimension(w, 24));
            b.setBackground(bg);
            b.setForeground(Color.WHITE);
            b.setOpaque(true);
            b.setBorderPainted(false);
            b.setFocusPainted(false);
        }

        public Component getTableCellRendererComponent(
                JTable t, Object v, boolean sel, boolean foc, int row, int col) {
            setBackground(sel ? t.getSelectionBackground() : Color.WHITE);
            boolean pending = "Pending".equals(t.getValueAt(row, 7));
            approveBtn.setVisible(pending);
            rejectBtn.setVisible(pending);
            return this;
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // Editor
    // ═════════════════════════════════════════════════════════════════════
    private class ActionEditor extends DefaultCellEditor {
        private final JPanel panel   = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 3));
        private final JButton appBtn = new JButton("Approve");
        private final JButton rejBtn = new JButton("Reject");
        private final JButton vwBtn  = new JButton("View");
        private int editRow;

        ActionEditor() {
            super(new JCheckBox());
            setClickCountToStart(1);
            panel.setOpaque(true);

            styleBtn(appBtn, new Color(40, 167, 69),  70);
            styleBtn(rejBtn, new Color(220, 53, 69),  65);
            styleBtn(vwBtn,  new Color(108, 117, 125), 58);

            appBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { doApprove(); }
            });
            rejBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { doReject(); }
            });
            vwBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { doView(); }
            });

            panel.add(appBtn); panel.add(rejBtn); panel.add(vwBtn);
        }

        private void styleBtn(JButton b, Color bg, int w) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 10));
            b.setPreferredSize(new Dimension(w, 24));
            b.setBackground(bg);
            b.setForeground(Color.WHITE);
            b.setOpaque(true);
            b.setBorderPainted(false);
            b.setFocusPainted(false);
        }

        public Component getTableCellEditorComponent(
                JTable t, Object v, boolean sel, int row, int col) {
            editRow = row;
            panel.setBackground(t.getSelectionBackground());
            boolean pending = "Pending".equals(t.getValueAt(row, 7));
            appBtn.setVisible(pending);
            rejBtn.setVisible(pending);
            return panel;
        }

        public Object getCellEditorValue() { return "Actions"; }

        // ── Approve ───────────────────────────────────────────────────
        private void doApprove() {
            final String id  = (String) tableModel.getValueAt(editRow, 0);
            String student   = (String) tableModel.getValueAt(editRow, 5);
            String subject   = (String) tableModel.getValueAt(editRow, 3);
            String category  = (String) tableModel.getValueAt(editRow, 1);

            int ok = JOptionPane.showConfirmDialog(
                ServiceRequestManagementPanel.this,
                "Approve this request?\n\n"
                + "ID       : " + id + "\n"
                + "Student  : " + student + "\n"
                + "Category : " + category + "\n"
                + "Subject  : " + subject,
                "Approve Request",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

            if (ok == JOptionPane.YES_OPTION) {
                DataStore.getInstance().updateServiceRequestStatus(id, "Approved", "");
                tableModel.setValueAt("Approved", editRow, 7);
                showMsg("Request #" + id + " approved.", false);

                DataStore.ServiceRequest req = findById(id);
                if (req != null) {
                    String body = "Dear " + req.requester + ",\n\n"
                        + "Your service request #" + req.id + " has been APPROVED.\n"
                        + "Category : " + req.category + "\n"
                        + "Subject  : " + req.subject  + "\n\n"
                        + "We will begin processing it shortly.\n\n"
                        + "Student Services Team";
                    EmailService.sendAsync(req.requester, req.requester,
                        "Service Request Approved - #" + id, body, null);
                }
                rebuildTopPanel();
            }
            fireEditingStopped();
        }

        // ── Reject ────────────────────────────────────────────────────
        private void doReject() {
            final String id = (String) tableModel.getValueAt(editRow, 0);
            String student  = (String) tableModel.getValueAt(editRow, 5);
            String subject  = (String) tableModel.getValueAt(editRow, 3);
            String category = (String) tableModel.getValueAt(editRow, 1);

            String reason = (String) JOptionPane.showInputDialog(
                ServiceRequestManagementPanel.this,
                "Rejecting #" + id + " for " + student
                + "\nCategory : " + category
                + "\nSubject  : " + subject
                + "\n\nEnter reason for rejection:",
                "Reject Request",
                JOptionPane.WARNING_MESSAGE,
                null, null, "");

            if (reason != null && !reason.trim().isEmpty()) {
                DataStore.getInstance().updateServiceRequestStatus(id, "Rejected", reason.trim());
                tableModel.setValueAt("Rejected", editRow, 7);
                showMsg("Request #" + id + " rejected.", false);

                DataStore.ServiceRequest req = findById(id);
                if (req != null) {
                    String body = "Dear " + req.requester + ",\n\n"
                        + "Your service request #" + req.id + " has been REJECTED.\n"
                        + "Category : " + req.category + "\n"
                        + "Subject  : " + req.subject  + "\n\n"
                        + "Reason   : " + reason.trim() + "\n\n"
                        + "Please contact Student Services if you have questions.\n\n"
                        + "Student Services Team";
                    EmailService.sendAsync(req.requester, req.requester,
                        "Service Request Rejected - #" + id, body, null);
                }
                rebuildTopPanel();
            }
            fireEditingStopped();
        }

        // ── View ──────────────────────────────────────────────────────
        private void doView() {
            String id = (String) tableModel.getValueAt(editRow, 0);
            DataStore.ServiceRequest r = findById(id);
            if (r != null) {
                JOptionPane.showMessageDialog(
                    ServiceRequestManagementPanel.this,
                    "Request ID   : " + r.id          + "\n"
                    + "Category     : " + r.category    + "\n"
                    + "Service Type : " + r.serviceType + "\n"
                    + "Subject      : " + r.subject     + "\n\n"
                    + "Details:\n"      + r.details     + "\n\n"
                    + "Priority     : " + r.priority    + "\n"
                    + "Submitted by : " + r.requester   + "\n"
                    + "Date         : " + r.date        + "\n"
                    + "Status       : " + r.status      + "\n"
                    + "Remarks      : " + r.adminRemarks,
                    "Request Details",
                    JOptionPane.INFORMATION_MESSAGE);
            }
            fireEditingStopped();
        }
    }
}
