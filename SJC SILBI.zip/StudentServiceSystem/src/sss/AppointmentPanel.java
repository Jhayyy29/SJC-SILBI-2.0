package sss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class AppointmentPanel extends JPanel {

    private final MainFrame mainFrame;
    private DefaultTableModel tableModel;

    private JComboBox<String> officeBox, timeBox;
    private JTextField dateField, purposeField;

    public AppointmentPanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("📅  Appointment Booking",
            "Schedule a meeting with school offices and departments."), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);
    }

    private JPanel buildContent() {
        JPanel main = new JPanel(new GridLayout(1, 2, 16, 0));
        main.setBackground(AppColors.CREAM);
        main.setBorder(new EmptyBorder(16, 20, 16, 20));
        main.add(buildForm());
        main.add(buildHistory());
        return main;
    }

    private JPanel buildForm() {
        JPanel card = UIUtils.createCard("Book an Appointment");

        JPanel fields = new JPanel();
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));
        fields.setBackground(AppColors.CARD_BG);

        officeBox = UIUtils.styledCombo(new String[]{
            "Registrar's Office",
            "Guidance & Counseling",
            "Dean's Office",
            "Library",
            "Finance / Cashier",
            "IT Department",
            "Health / Clinic",
            "Student Affairs"
        });

        timeBox = UIUtils.styledCombo(new String[]{
            "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM",
            "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM"
        });

        String defaultDate = LocalDate.now().plusDays(1)
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        dateField    = UIUtils.styledField("YYYY-MM-DD");
        dateField.setText(defaultDate);
        purposeField = UIUtils.styledField("e.g. Academic advising, enrollment concern...");

        fields.add(UIUtils.formRow("Office", officeBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Date (YYYY-MM-DD)", dateField));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Preferred Time", timeBox));
        fields.add(Box.createVerticalStrut(10));
        fields.add(UIUtils.formRow("Purpose", purposeField));
        fields.add(Box.createVerticalStrut(16));

        JLabel note = new JLabel("<html><i>Note: Appointments subject to office availability.<br>" +
            "You will be notified of confirmation.</i></html>");
        note.setFont(AppColors.SMALL_FONT);
        note.setForeground(AppColors.TEXT_GRAY);
        fields.add(note);
        fields.add(Box.createVerticalStrut(12));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(AppColors.CARD_BG);
        JButton clearBtn  = UIUtils.secondaryButton("Clear");
        JButton submitBtn = UIUtils.primaryButton("Book Appointment");
        clearBtn.addActionListener(e -> clearForm(defaultDate));
        submitBtn.addActionListener(e -> bookAppointment());
        btns.add(clearBtn);
        btns.add(submitBtn);
        fields.add(btns);

        card.add(fields, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildHistory() {
        JPanel card = UIUtils.createCard("My Appointments");

        String[] cols = {"ID", "Office", "Date", "Time", "Purpose", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel) {
            @Override public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
                Component c = super.prepareRenderer(renderer, row, col);
                if (col == 5) {
                    JLabel badge = UIUtils.statusBadge((String) getValueAt(row, col));
                    badge.setHorizontalAlignment(SwingConstants.CENTER);
                    return badge;
                }
                return c;
            }
        };
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(90);
        table.getColumnModel().getColumn(3).setPreferredWidth(80);
        table.getColumnModel().getColumn(4).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);

        // Right-click cancel
        JPopupMenu popup = new JPopupMenu();
        JMenuItem cancelItem = new JMenuItem("Cancel Appointment");
        cancelItem.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { UIUtils.showError(this, "Select an appointment first."); return; }
            String id = (String) tableModel.getValueAt(row, 0);
            int confirm = JOptionPane.showConfirmDialog(this,
                "Cancel appointment #" + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DataStore.getInstance().cancelAppointment(id);
                loadAppointments();
            }
        });
        popup.add(cancelItem);
        table.setComponentPopupMenu(popup);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new LineBorder(AppColors.BORDER));
        card.add(sp, BorderLayout.CENTER);

        JButton refreshBtn = UIUtils.secondaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadAppointments());
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(AppColors.CARD_BG);
        JLabel hint = new JLabel("Right-click to cancel  ");
        hint.setFont(AppColors.SMALL_FONT);
        hint.setForeground(AppColors.TEXT_GRAY);
        btnRow.add(hint);
        btnRow.add(refreshBtn);
        card.add(btnRow, BorderLayout.SOUTH);

        loadAppointments();
        return card;
    }

    private void loadAppointments() {
        tableModel.setRowCount(0);
        for (DataStore.Appointment a : DataStore.getInstance().getAppointments()) {
            tableModel.addRow(new Object[]{
                a.id, a.office, a.date, a.time, a.purpose, a.status
            });
        }
    }

    private void bookAppointment() {
        String office  = (String) officeBox.getSelectedItem();
        String date    = dateField.getText().trim();
        String time    = (String) timeBox.getSelectedItem();
        String purpose = purposeField.getText().trim();

        if (date.isEmpty()) { UIUtils.showError(this, "Please enter a date."); return; }
        if (purpose.isEmpty()) { UIUtils.showError(this, "Please enter the purpose."); return; }

        // Basic date validation
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            UIUtils.showError(this, "Date must be in YYYY-MM-DD format.");
            return;
        }

        DataStore.Appointment a = DataStore.getInstance().bookAppointment(office, date, time, purpose);
        UIUtils.showSuccess(this, "Appointment #" + a.id + " booked!\n" +
            "Office: " + office + "\nDate: " + date + "  Time: " + time);
        clearForm(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        loadAppointments();
    }

    private void clearForm(String defaultDate) {
        officeBox.setSelectedIndex(0);
        dateField.setText(defaultDate);
        timeBox.setSelectedIndex(0);
        purposeField.setText("");
    }

    private void styleTable(JTable table) {
        table.setFont(AppColors.BODY_FONT);
        table.setRowHeight(30);
        table.setGridColor(new Color(220, 215, 200));
        table.setSelectionBackground(new Color(200, 235, 215));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(AppColors.DARK_GREEN);
        table.getTableHeader().setForeground(Color.BLACK);
    }

    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("← Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }
}
