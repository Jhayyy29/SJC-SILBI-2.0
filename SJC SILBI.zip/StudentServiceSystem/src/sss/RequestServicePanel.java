package sss;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * "Request a Service" panel.
 * Left side  — submission form (category → service type → subject/details/priority).
 * Right side — history table of the logged-in student's service requests.
 */
public class RequestServicePanel extends JPanel {

    private final MainFrame mainFrame;

    // ── Service catalogue ──────────────────────────────────────────────────
    private static final String[][] CATALOGUE = {
        { "Facilities",      "Room/Venue Reservation",    "Air-Conditioning Repair",
                             "Lighting / Electrical Issue","Plumbing / Water Issue",
                             "Furniture Request",         "Cleaning Request" },
        { "IT & Technology", "Wi-Fi / Internet Issue",    "Computer Lab Support",
                             "Projector / AV Equipment",  "Software Installation",
                             "Account / Password Reset" },
        { "Administrative",  "Certificate Request",       "ID Replacement",
                             "Lost & Found",              "Permit / Clearance",
                             "Enrollment Concern" },
        { "Health & Safety", "First Aid / Medical Assist","Safety Hazard Report",
                             "Fire / Emergency Concern",  "Mental Health Support" },
        { "Library",         "Book Reservation",          "Library Card Issue",
                             "Reference Material Request","Overdue Fine Concern" },
        { "Finance",         "Payment Concern",           "Scholarship Inquiry",
                             "Refund Request",            "Receipt / OR Issue" },
    };

    // ── Form fields ────────────────────────────────────────────────────────
    private JComboBox<String> categoryCombo;
    private JComboBox<String> serviceTypeCombo;
    private JTextField        subjectField;
    private JTextArea         detailsArea;
    private JComboBox<String> priorityCombo;
    private JLabel            statusMsg;

    // ── History table ──────────────────────────────────────────────────────
    private DefaultTableModel tableModel;
    private JTable            table;

    public RequestServicePanel(MainFrame frame) {
        this.mainFrame = frame;
        setLayout(new BorderLayout());
        setBackground(AppColors.CREAM);

        add(UIUtils.pageHeader("\uD83D\uDEE0\uFE0F  Request a Service",
                "Submit service requests for facilities, IT, admin, and more."),
            BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildFormPanel(), buildHistoryPanel());
        split.setDividerLocation(480);
        split.setResizeWeight(0.42);
        split.setBorder(null);
        split.setBackground(AppColors.CREAM);
        add(split, BorderLayout.CENTER);

        add(buildBottomBar(), BorderLayout.SOUTH);

        refreshTable();
    }

    // ======================================================================
    //  FORM  (left)
    // ======================================================================
    private JPanel buildFormPanel() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(AppColors.CREAM);
        wrap.setBorder(new EmptyBorder(16, 16, 16, 8));

        JPanel card = UIUtils.createCard("New Service Request");
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new CompoundBorder(
                new LineBorder(AppColors.BORDER, 1, true),
                new EmptyBorder(18, 18, 18, 18)));

        // Category
        card.add(formLabel("Category *"));
        card.add(Box.createVerticalStrut(4));
        String[] categories = new String[CATALOGUE.length + 1];
        categories[0] = "-- Select Category --";
        for (int i = 0; i < CATALOGUE.length; i++) categories[i + 1] = CATALOGUE[i][0];
        categoryCombo = new JComboBox<>(categories);
        styleCombo(categoryCombo);
        categoryCombo.addActionListener(e -> onCategoryChanged());
        card.add(categoryCombo);
        card.add(Box.createVerticalStrut(12));

        // Service Type
        card.add(formLabel("Service Type *"));
        card.add(Box.createVerticalStrut(4));
        serviceTypeCombo = new JComboBox<>(new String[]{"-- Select Category First --"});
        styleCombo(serviceTypeCombo);
        card.add(serviceTypeCombo);
        card.add(Box.createVerticalStrut(12));

        // Subject
        card.add(formLabel("Subject *"));
        card.add(Box.createVerticalStrut(4));
        subjectField = new JTextField();
        subjectField.setFont(AppColors.BODY_FONT);
        subjectField.setBorder(new CompoundBorder(
                new LineBorder(AppColors.BORDER, 1, true),
                new EmptyBorder(6, 8, 6, 8)));
        subjectField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        card.add(subjectField);
        card.add(Box.createVerticalStrut(12));

        // Details
        card.add(formLabel("Details / Description *"));
        card.add(Box.createVerticalStrut(4));
        detailsArea = new JTextArea(5, 20);
        detailsArea.setFont(AppColors.BODY_FONT);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);
        detailsArea.setBorder(new CompoundBorder(
                new LineBorder(AppColors.BORDER, 1, true),
                new EmptyBorder(6, 8, 6, 8)));
        JScrollPane detailsScroll = new JScrollPane(detailsArea);
        detailsScroll.setBorder(null);
        detailsScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        card.add(detailsScroll);
        card.add(Box.createVerticalStrut(12));

        // Priority
        card.add(formLabel("Priority *"));
        card.add(Box.createVerticalStrut(4));
        priorityCombo = new JComboBox<>(new String[]{"Low", "Medium", "High", "Urgent"});
        styleCombo(priorityCombo);
        priorityCombo.setSelectedItem("Medium");
        card.add(priorityCombo);
        card.add(Box.createVerticalStrut(16));

        // Status message
        statusMsg = new JLabel(" ");
        statusMsg.setFont(AppColors.SMALL_FONT);
        statusMsg.setAlignmentX(LEFT_ALIGNMENT);
        card.add(statusMsg);
        card.add(Box.createVerticalStrut(8));

        // Submit button
        JButton submitBtn = UIUtils.primaryButton("Submit Request");
        submitBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        submitBtn.setAlignmentX(LEFT_ALIGNMENT);
        submitBtn.addActionListener(e -> doSubmit());
        card.add(submitBtn);

        wrap.add(card, BorderLayout.CENTER);
        return wrap;
    }

    // ======================================================================
    //  HISTORY TABLE  (right)
    // ======================================================================
    private JPanel buildHistoryPanel() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(AppColors.CREAM);
        wrap.setBorder(new EmptyBorder(16, 8, 16, 16));

        // Title
        JLabel title = new JLabel("My Service Requests");
        title.setFont(AppColors.HEADER_FONT);
        title.setForeground(AppColors.DARK_GREEN);
        title.setBorder(new EmptyBorder(0, 0, 10, 0));
        wrap.add(title, BorderLayout.NORTH);

        // Table
        String[] cols = {"ID", "Category", "Service Type", "Subject", "Priority", "Status", "Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel) {
            @Override public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (!isRowSelected(row)) {
                    String status = (String) getModel().getValueAt(row, 5);
                    c.setBackground(switch (status) {
                        case "Completed"   -> new Color(212, 237, 218);
                        case "In Progress" -> new Color(209, 236, 241);
                        case "Cancelled"   -> new Color(248, 215, 218);
                        default            -> Color.WHITE;
                    });
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        };
        styleTable(table);

        // Cancel button under table
        JButton cancelBtn = UIUtils.secondaryButton("Cancel Selected");
        cancelBtn.addActionListener(e -> doCancelSelected());

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 6));
        btnRow.setBackground(AppColors.CREAM);
        btnRow.add(cancelBtn);

        wrap.add(new JScrollPane(table), BorderLayout.CENTER);
        wrap.add(btnRow, BorderLayout.SOUTH);
        return wrap;
    }

    // ======================================================================
    //  BOTTOM BAR
    // ======================================================================
    private JPanel buildBottomBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        bar.setBackground(AppColors.CREAM);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, AppColors.BORDER));
        JButton back = UIUtils.secondaryButton("\u2190 Back to Dashboard");
        back.addActionListener(e -> mainFrame.showDashboard());
        bar.add(back);
        return bar;
    }

    // ======================================================================
    //  LOGIC
    // ======================================================================
    private void onCategoryChanged() {
        int idx = categoryCombo.getSelectedIndex();
        serviceTypeCombo.removeAllItems();
        if (idx <= 0) {
            serviceTypeCombo.addItem("-- Select Category First --");
            return;
        }
        String[] row = CATALOGUE[idx - 1];
        serviceTypeCombo.addItem("-- Select Service Type --");
        for (int i = 1; i < row.length; i++) serviceTypeCombo.addItem(row[i]);
    }

    private void doSubmit() {
        String category    = categoryCombo.getSelectedIndex() <= 0 ? "" :
                             (String) categoryCombo.getSelectedItem();
        String serviceType = serviceTypeCombo.getSelectedIndex() <= 0 ? "" :
                             (String) serviceTypeCombo.getSelectedItem();
        String subject     = subjectField.getText().trim();
        String details     = detailsArea.getText().trim();
        String priority    = (String) priorityCombo.getSelectedItem();

        if (category.isEmpty()) {
            showStatus("Please select a category.", false); return;
        }
        if (serviceType.isEmpty() || serviceType.startsWith("--")) {
            showStatus("Please select a service type.", false); return;
        }
        if (subject.isEmpty()) {
            showStatus("Subject cannot be empty.", false); return;
        }
        if (details.isEmpty()) {
            showStatus("Please provide details.", false); return;
        }

        DataStore.getInstance().submitServiceRequest(
                category, serviceType, subject, details, priority);

        showStatus("\u2705 Request submitted successfully!", true);
        subjectField.setText("");
        detailsArea.setText("");
        categoryCombo.setSelectedIndex(0);
        priorityCombo.setSelectedItem("Medium");
        refreshTable();
    }

    private void doCancelSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtils.showError(this, "Please select a request to cancel.");
            return;
        }
        String id     = (String) tableModel.getValueAt(row, 0);
        String status = (String) tableModel.getValueAt(row, 5);
        if ("Cancelled".equals(status) || "Completed".equals(status)) {
            UIUtils.showError(this, "Cannot cancel a " + status.toLowerCase() + " request.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Cancel service request #" + id + "?",
                "Confirm Cancel", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        DataStore.getInstance().updateServiceRequestStatus(id, "Cancelled", "");
        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        DataStore ds = DataStore.getInstance();
        String currentUser = ds.isLoggedIn() ? ds.getCurrentUser().fullName : "";
        List<DataStore.ServiceRequest> all = ds.getServiceRequests();
        for (DataStore.ServiceRequest sr : all) {
            if (!ds.isAdmin() && !sr.requester.equals(currentUser)) continue;
            tableModel.addRow(new Object[]{
                sr.id, sr.category, sr.serviceType, sr.subject,
                sr.priority, sr.status, sr.date
            });
        }
    }

    private void showStatus(String msg, boolean success) {
        statusMsg.setText(msg);
        statusMsg.setForeground(success ? new Color(21, 128, 61) : new Color(180, 30, 30));
    }

    // ======================================================================
    //  HELPERS
    // ======================================================================
    private JLabel formLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(AppColors.BODY_FONT);
        lbl.setForeground(AppColors.TEXT_DARK);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        return lbl;
    }

    private void styleCombo(JComboBox<?> c) {
        c.setFont(AppColors.BODY_FONT);
        c.setBackground(Color.WHITE);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        c.setAlignmentX(LEFT_ALIGNMENT);
    }

    private void styleTable(JTable t) {
        t.setFont(AppColors.BODY_FONT);
        t.setRowHeight(30);
        t.setGridColor(new Color(220, 215, 200));
        t.setSelectionBackground(new Color(200, 235, 215));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.getTableHeader().setBackground(AppColors.DARK_GREEN);
        t.getTableHeader().setForeground(Color.BLACK);
        t.setShowGrid(true);

        // Column widths
        int[] widths = {55, 100, 140, 160, 70, 90, 120};
        for (int i = 0; i < widths.length; i++)
            t.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
    }
}
