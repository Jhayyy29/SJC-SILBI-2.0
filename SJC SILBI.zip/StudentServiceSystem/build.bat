@echo off
if not exist out mkdir out
javac -encoding UTF-8 -d out -sourcepath src ^
  src\sss\AppColors.java ^
  src\sss\DataStore.java ^
  src\sss\UIUtils.java ^
  src\sss\EmailConfig.java ^
  src\sss\EmailService.java ^
  src\sss\LoginPanel.java ^
  src\sss\DashboardPanel.java ^
  src\sss\AccessOpenDataPanel.java ^
  src\sss\FileReportPanel.java ^
  src\sss\DocumentRequestPanel.java ^
  src\sss\NotificationsPanel.java ^
  src\sss\AppointmentPanel.java ^
  src\sss\ViewServicesPanel.java ^
  src\sss\StudentProfilePanel.java ^
  src\sss\InfoRequestPanel.java ^
  src\sss\RequestServicePanel.java ^
  src\sss\AdminDashboardPanel.java ^
  src\sss\UserManagementPanel.java ^
  src\sss\ReportManagementPanel.java ^
  src\sss\DocumentManagementPanel.java ^
  src\sss\AppointmentManagementPanel.java ^
  src\sss\NotificationManagementPanel.java ^
  src\sss\ServiceRequestManagementPanel.java ^
  src\sss\InfoRequestManagementPanel.java ^
  src\sss\AuditLogPanel.java ^
  src\sss\MainFrame.java ^
  src\sss\Main.java
if %ERRORLEVEL% EQU 0 (
    echo BUILD SUCCESSFUL
) else (
    echo BUILD FAILED
)
