@echo off
java -cp out sss.Main
